
'''
Created on Apr 2, 2021

@author: apschmidt
'''


import os, csv
from numpy import random
from math import sqrt
###############
############### Input information

data_folder = "Data/Test2"
n_voterLocs = 1000
n_dropBoxes_existing = 20
n_dropBoxes_potential = 100

# Might be used in functions
coords = {} # We can generate coordinates for the location of all objects


##############
############## Useful functions

def w(location):
    # Generates the importance of the locations
    return random.uniform()

def p(location):
    # Generates the population at each location
    return random.randint(5,15)

def subset_Ni(location, dropBoxes):
    # Selects a subset of the locations that are reachable for location i
    return [db for db in dropBoxes if distance(coords[db],coords[location]) < 0.15]

def subset_Nprime(location, dropBoxes,Ni):
    # Selects a subset of the locations that provide base coverage for Ni
    return [db for db in dropBoxes if distance(coords[db],coords[location]) < 0.5] #dropBoxes

def generateCoords(obj):
    # Generates the location of the obj
    return random.uniform(),random.uniform()

def distance(loc1,loc2):
    
    return sqrt((loc1[0]-loc2[0])**2+(loc1[1]-loc2[1])**2)


#############
############# Generating the values


######## Drop box ID info 
V = [] # IDs of existing drop box locations
P = [] # IDs of potential drop box locations
s = "OFFICE"
coords[s] = generateCoords(s) # randomizing location for s
N = [s] # will hold all drop box locations

d = 0
for d in range(n_dropBoxes_existing):
    V.append(f"DB{d}")
    coords[f"DB{d}"] = generateCoords(f"DB{d}") # randomizing location
    
for d in range(n_dropBoxes_existing,n_dropBoxes_potential):
    P.append(f"DB{d}")
    coords[f"DB{d}"] = generateCoords(f"DB{d}") # randomizing location

N += V 
N += P


# Drop box travel cost info
c = {} # [key] tuple (ID 1, ID2) [value] cost of traveling between drop box 
    # (and cc office) locations; we assume a value for each pair in N
for i in N:
    for j in N:
        if i == j:
            c[i,j] = 99999
        else:
            c[i,j] = distance(coords[i],coords[j])

########## Coverage Info
# Voter info
W = {} # [key] voter location ID [value] tuple (importance, population)
Ni = {} # [key] ID in W [value] iterable of location in N that cover ID
Nprime = {} # [key] ID in W [value] iterable of location in N that base-cover ID 

for i in range(n_voterLocs):
    W[f"voter{i}"] = w(f"voter{i}"), p(f"voter{i}")
    coords[f"voter{i}"] = generateCoords(f"voter{i}")
    Ni[f"voter{i}"] = subset_Ni(f"voter{i}", V+P)
    Nprime[f"voter{i}"] = subset_Nprime(f"voter{i}", V+P, Ni[f"voter{i}"])
    
    
    
    
##################################
################################## WRITING THE DATA

def list_to_string(l):
    # creates a list with dashes
    return str(list(l))[1:-1].replace("'","").replace(" ","").replace(",","-")

if not os.path.exists(data_folder):
    os.makedirs(data_folder)
    
    
### WRITING DB locations
with open(os.path.join(data_folder, "data_N.csv"), 'w',newline = "") as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(["ID","GROUP"])
    csvwriter.writerow([s,"s"])
    for db in V:
        csvwriter.writerow([db,"V"])
    for db in P:
        csvwriter.writerow([db,"P"])
        
### Writing voter info
with open(os.path.join(data_folder, "data_W.csv"), 'w',newline = "") as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(["ID","w","p","Ni","Nprime"])
    for i in W:
        csvwriter.writerow([i,W[i][0],W[i][1],list_to_string(Ni[i]),list_to_string(Nprime[i])])

#### Cost matrix
with open(os.path.join(data_folder, "data_C.csv"), 'w',newline = "") as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(["ID/ID"]+N)
    for n in N:
        row = [n]
        for j in N:
            row += [c[n,j]]
        csvwriter.writerow(row)
    
    
