'''
This file is used to implement a solution algorithm for the covering tour 
problem using the Steiner tree problem and the TSP problem.
@author: Adam Schmidt
'''

from Classes import CTPGraph, AuxiliaryGraph, Algorithm
import os, csv
import networkx as nx
import numpy as np
from timeit import default_timer as timer
from collections import Counter
from heapq import heappush, heappop

class SchmidtAlgorithm(Algorithm):
    def __init__(self, Steiner = 'approx', TSP = 'exact'):
        super().__init__()
        self.aux_graph = AuxiliaryGraph()
        self.name = f'SchmidtAlgorithm(ST{Steiner}|TSP{TSP})'
        self.steiner_method = Steiner
        self.TSP_method = TSP
        
        
    def load(self, data_folder):
        '''
        This will take a folderpath and create a graph given the data
        '''
        super().load(data_folder)
        
        # Loading the auxiliary graph based on general graph
        self.aux_graph.load(self.graph)
    
    def remove_redundant(self, nodes):
        '''
        This will take in a set of nodes and remove nodes that are unnecessary
        due to redundant coverage.
        '''
        # First, we count the coverage of everything
        c = Counter() # Stores the counts of the coverage
        h = [] # Stores the nodes in the order of the number of nodes it covers (lowest first)
        for v in nodes:
            cov = self.graph.get_coverage(v)
            c.update(cov)
            if v not in self.graph.T: # Can only consider removing if not required
                heappush(h, (len(cov), v))
        
        retained_nodes = set()
        while len(h) > 0 and c.most_common(1)[0][1] > 2: # While nodes to possibly remove
            hc, v = heappop(h)
            cov = self.graph.get_coverage(v)
            # Check if we can safely remove v
            safely_remove = True
            for w in cov:
                if c[w] <= 2:
                    safely_remove = False
                    break
            # If so, remove from nodes considered
            if safely_remove:
                # And update the coverage counts
                c.subtract(cov)    
            else:
                retained_nodes.add(v)
        return retained_nodes.union(self.graph.T).union([i[1] for i in h])
    
    def checkT(self):
        '''
        This will check if T covers all W twice!
        '''
        for w in self.graph.W:
            # Checks node w is covered twice
            if len(self.graph.T.intersection(self.graph.get_coverage(w)))<2:
                return False
        
        return True
        
    def findWDoubleCovered(self,N):
        '''
        Given the set N, finds the nodes of W that are covered twice
        '''
        w_cov = set()
        for w in self.graph.W:
            if len(set(N).intersection(self.graph.get_coverage(w)))>=2:
                w_cov.add(w)
        return w_cov
        
    def solve(self):
        '''
        This is the main function that will take in the input data and construct
        a feasible solution to the covering tour problem.
        '''
        
        if not self.data_loaded:
            raise Exception("Data must be loaded before running solve.")
        
        
        '''
        This will solve the CTPish subproblem. We must find a tour on a 
        subset of nodes (that includes T) such that each W is covered *twice*.
        
        Our approach: 
        1) Find a Steiner tree on auxiliary graph
        2) Add nodes of V spanned by the ST to the set T
        2) For each node of W that is covered twice by nodes of N spanned by
           the tree, remove it from the Steiner Tree
        3) Remove edges between the nodes of V spanned by the ST and the remaining
           nodes of W
        4) Resolve the Steiner tree problem
        5) Remove Redundant nodes
        6) Find TSP on these nodes
        
        This is implemented in a different class
        ''' 
        
        # Step 0: check if the nodes of T cover all nodes
        Tcover = self.checkT() # Returns a boolean
        
        # First, we want to find a feasible steiner tree on the auxillary graph
        if not Tcover:
            steiner_tree_nodes = self.aux_graph.get_steiner_nodes(flag = self.steiner_method)
            
            # Finding the subset of tree corresponding to V
            vprime = set(steiner_tree_nodes).difference(self.graph.W)
            
            # Step 1.5 - if the problem is metric, we want to remove any nodes that 
            # don't cover any nodes of W (or that are overcovered) - nontrivial
            vprime = self.remove_redundant(vprime)

            # Now that we have our first iteration, we run it again to ensure
            # Double coverage
            
            #######
            # Updating the auxiliary graph
            #######
#             
            # Removing any w covered twice
            w_double = self.findWDoubleCovered(vprime)
            self.aux_graph.removeNodes(w_double)
             
            # Removing all arcs between vprime and W
            self.aux_graph.removeEdgesToW(vprime)
             
            # Adding vprime to R
            self.aux_graph.addNtoR(vprime)
             
            ######
            # Now, re-finding an auxiliary graph
            ######
            steiner_tree_nodes = self.aux_graph.get_steiner_nodes(flag = self.steiner_method)
             
            # Finding the subset of tree corresponding to V
            vprime = set(steiner_tree_nodes).difference(self.graph.W)
             
            # Step 1.5 - if the problem is metric, we want to remove any nodes that 
            # don't cover any nodes of W (or that are overcovered) - nontrivial
            vprime = self.remove_redundant(vprime)
             
        else:
            vprime = self.graph.T
        
        # Second, we want to find a feasible tour over the nodes defined by the 
        # steiner tree (vprime)
        self.tour, self.tour_cost = self.graph.get_TSP(vprime,flag = self.TSP_method)

        if len(self.tour) != len(vprime)+1:
            print(self.tour)
            print(vprime)
            raise Exception(f'Error finding tour, nodes {set(vprime).difference(self.tour)} not included')
#         print(self.tour, self.tour_cost)
#         print(self.solution_time)
#         print()
#         if not super().check_feasibility():
#             raise Exception('Error with algorithm. Solution not feasible.')
        return self.tour


class SchmidtAlgorithm1(SchmidtAlgorithm):
    def __init__(self):
        super().__init__(Steiner = 'approx', TSP = 'christofides')

class SchmidtAlgorithm2(SchmidtAlgorithm):
    def __init__(self):
        super().__init__(Steiner = 'approx', TSP = 'exact')

class SchmidtAlgorithm3(SchmidtAlgorithm):
    def __init__(self):
        super().__init__(Steiner = 'sketch_heuristic', TSP = 'exact')

class SchmidtAlgorithm4(SchmidtAlgorithm):
    def __init__(self):
        super().__init__(Steiner = 'sketchls_heuristic', TSP = 'exact')
class SchmidtAlgorithm5(SchmidtAlgorithm):
    def __init__(self):
        super().__init__(Steiner = 'sketchls_pq_heuristic', TSP = 'exact')
        
class SchmidtAlgorithm6(SchmidtAlgorithm):
    def __init__(self):
        super().__init__(Steiner = 'exact', TSP = 'exact')
# SA= SchmidtAlgorithm()
# SA.load('Test Sets/Test-100-1-100')
# SA.solve()
# print(SA.aux_graph.steiner.nodes)