'''
Created on Apr 2, 2021

@author: apschmidt
'''
####
# Input - reading from data file
####
import os,csv
import numpy as np
from collections import defaultdict
####
# Input - variable
####
class DropboxInstance:
    '''
    This holds the data for the dropbox problem
    '''
    def __init__(self,folder):
        self.data_folder = folder
        self.V = set() # IDs of existing drop box locations 
        self.P = set() # IDs of potential drop box locations
        self.T = set() # ID's of locations that must be located
        self.N = set() # all ID's of drop boxes and county clerk office
        self.Ni = {} # [key] ID in self.W [value] iterable of location in self.N that cover ID
        self.Nprime = {} # [key] ID in self.W [value] iterable of location in self.N that base-cover ID 
        self.W = {} # [key] voter location ID [value] tuple (importance, population)
        self.c = {} # [key] tuple (ID 1, ID2) [value] cost of traveling between drop box 
            # (and cc office) locations; we assume a value for each pair in self.N
            # (ignoring cost of traveling to same location)
        self.fixedcost = {} # will store the fixed cost of each location
        self.variablecost = {} # will store the fixed cost of each location
        self.Wi = defaultdict(set) #  # [key] ID in N [value] iterable of location in W that are covered by ID
        self.Wiprime = defaultdict(set) #  # [key] ID in N [value] iterable of location in W that are covered by ID at base level
        self.participation = defaultdict(dict) # This will store the participation choice model parameters
        self.arcs = set()
        self.arcsj = defaultdict(set)
        self.load_data()
        
    def load_data(self):
        '''
        Reads in the data from the folder
        '''
        # Drop box ID info 
        print(os.path.join(self.data_folder,"data_N.csv"))
        with open(os.path.join(self.data_folder,"data_N.csv"), "r") as csvfile:
            reader = csv.reader(csvfile)
            count = 0
            for row in reader:
                if count == 0: # header row
                    count = 1
                else:
                    self.fixedcost['v'+row[0]] = float(row[2])
                    if row[1] == "s":
                        s = 'v'+row[0] # ID of the county clerk office
                        office = s
                    elif row[1] == "P": # Potential drop boxes
                        self.P.add('v'+row[0])
                    elif row[1] == "V": # Existing drop boxes
                        self.V.add('v'+row[0])
                    else:
                        raise Exception(f"Unknown location type in self.N: {row[1]}")

        self.T = self.V.union([s]) # ID's of locations that must be located
        self.N = self.P.union(self.T) # all ID's of drop boxes and county clerk office

        # Drop box travel cost info
        with open(os.path.join(self.data_folder,"data_C.csv"), "r") as csvfile:
            reader = csv.reader(csvfile)
            count = 0
            for row in reader:
                if count == 0: # header row
                    row_keys = row[1:]
                    count = 1
                else:
                    for col in range(len(row)-1):
                        if float(row[col+1]) < 0: # We couldn't get a distance/duration
                            self.c['v'+row[0],'v'+row_keys[col]] = np.inf # Want the cost to be really high
                            self.variablecost['v'+row[0],'v'+row_keys[col]] = np.inf
                        else:
                            self.c['v'+row[0],'v'+row_keys[col]] =  float(row[col+1])+ self.fixedcost['v'+row[0]]/2 + self.fixedcost['v'+row_keys[col]]/2
                            self.variablecost['v'+row[0],'v'+row_keys[col]] =  float(row[col+1])
                            
        # Coverage Info
        # Voter info
        with open(os.path.join(self.data_folder,"data_W.csv"), "r") as csvfile:
            reader = csv.reader(csvfile)
            count = 0
            for row in reader:
                if count == 0: # header row
                    count = 1
                else:
                    self.W['w'+row[0]] = (float(row[1]),float(row[2]))
                    if len(row[3]) > 0: # This is the desired coverage
                        self.Ni['w'+row[0]] = ['v'+i for i in row[3].split("-")]
                        for n in self.Ni['w'+row[0]]:
                            self.Wi[n].add('w'+row[0])            
                    else: # Nothing covers it 
                        self.Ni['w'+row[0]] = []
                    if len(row[4]) > 0:
                        self.Nprime['w'+row[0]] = ['v'+i for i in row[4].split("-")]
                        for n in self.Nprime['w'+row[0]]:
                            self.Wiprime[n].add('w'+row[0])   
                    else:
                        self.Nprime['w'+row[0]] = []

        # Participation information
        with open(os.path.join(self.data_folder,"data_participation.csv"), "r") as csvfile:
            reader = csv.reader(csvfile)
            count = 0
            headers = []
            for row in reader:
                if count == 0: # header row
                    count = 1
                    headers = row
                else:
                    for n in range(1,len(headers)):
                        self.participation['w'+row[0]]['v'+headers[n]] = float(row[n])
                        if self.participation['w'+row[0]]['v'+headers[n]] <= 0:
                            raise Exception('Participation for','w'+row[0], 'v'+headers[n], 'is less than zero',  self.participation['w'+row[0]]['v'+headers[n]])
        self.Wpart = list(self.participation.keys())
        # Storing the arcs
        for i in self.N:
            for j in self.N:
                if i < j:
                    self.arcs.add((i,j))
                    self.arcsj[i].add((i,j)) 
                elif j < i:
                    self.arcsj[j].add((j,i)) 
                    
    def get_arcs(self,j = None):
        ''' Returns the neighbors if j passed'''
        if j is None:
            return self.arcs
        return self.arcsj[j]
    def get_N(self):
        return self.N
    def get_T(self):
        return self.T
    
    def get_baseCoverage(self,k):
        if k is None:
            return set()
        # If node of v, we return subset of W
        if k[0] == 'v':
            return self.Wiprime[k]
        #else, we return nodes of v
        return self.Nprime[k]
    
    def get_coverage(self,k):
        print('We should not be using this coverage function (get_coverage)')
        
        if k is None:
            return set()
        # If node of v, we return subset of W
        if k[0] == 'v':
            return self.Wi[k]
        #else, we return nodes of v
        return self.Ni[k]
    
    def get_W(self):
        return list(self.W.keys())
    def get_Wpart(self):
        return self.Wpart
    def get_participationComponent(self,w,n):
        return self.participation[w][n]
    
    def get_cost(self,i,j):
        return self.c[self.get_edge(i,j)]
    def get_fixedcost(self,j):
        return self.fixedcost[j]
    def get_edge(self,i,j): 
        if i<j:
            return i,j
        return j,i
    
#     def determine_dominating(self):
#         doms = []
#         for i,j in self.get_arcs():
#             if i not in self.get_T() and j not in self.get_T():
#                 # First checking i dom j
#                 
#                 inter = self.get_baseCoverage(i).intersection(self.get_baseCoverage(j))
#                 
#                 # This checks if j is subset of i
#                 if len(inter) == len(self.get_baseCoverage(i)):
#                     
#                     
#                     doms.append((i,j))
#                 elif len(self.get_baseCoverage(j).intersection(self.get_baseCoverage(j))) == len(self.get_baseCoverage(i)):
#                 self.get_baseCoverage(i).
            
            
