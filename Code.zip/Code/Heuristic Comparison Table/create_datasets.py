import random
import csv 
import os
import numpy


def distance(c1, c2):
    '''
    Computes manhattan distances between c1 and c2
    '''
    return abs(c2[1]-c1[1]) + abs(c2[0]-c1[0])


for N in [75]: # Different sizes for N
    for W in [100,500,1000] : #[100,500,1000,2000]: # Different sizes for W
        data_folder = f'Data/Random{W}-{N}'
        ##
        # Generate data for Ws
        ##
        coordinatesW = {}
        for w in range(W):
            coordinatesW[w] = random.uniform(0, 100), random.uniform(0, 100)
        
        ##
        # Generate data for Ns
        ##
        
        # Coordinates
        coordinatesN = {}
        for n in range(N):
            coordinatesN[n] = random.uniform(0, 100), random.uniform(0, 100)
        
        ## 
        # Compute distances
        ## 
        distancesNs = {} # Distances between drop boxes
        for n in range(N):
            distancesNs[n,n] = 0
            for np in range(n):
               distancesNs[n,np] = distancesNs[np,n] =  distance(coordinatesN[n],coordinatesN[np])
        
        distancesWN = {} # Distance from W to drop box
        for w in range(W):
            for n in range(N):
                distancesWN[w,n] =  distance(coordinatesW[w],coordinatesN[n])
        
        # Selecting the set T
        T = list(range(0,random.randint(1,round(N*0.25,0))))
        
        
             
        ##
        # Generating coverage sets
        ##
        radius_size = random.uniform(15,50)
        min_distance = -99
        for w in range(W): # Finding the minimum allowable radius
            distances = [distancesWN[w,n] for n in range(N)]
            distances.sort()
            if distances[1] > min_distance:
                min_distance = distances[1]
        
        radius_size = max(radius_size, min_distance)
        
        Nw = {}
        for w in range(W):
            Nw[w] = [n for n in range(N) if distancesWN[w,n] <= radius_size]
            if len(Nw[w] ) < 2:
                print("issue")
            
        ##
        # Generating participation values
        ##
        V0 = {}
        V1 = {}
        Vn = {}
        
        for w in range(W):
            V1[w] = random.uniform(50,95)
            V0[w] = 100-V1[w]
            for n in range(N):
                Vn[w,n] = numpy.exp(2.5-distancesWN[w,n]/30) #20*random.uniform(2,5)/distancesWN[w,n]**2
        
        ##
        # Computing tour costs
        ##
        est_scale = 50*2*40*(1.02**15)/60
        random_c_scale = random.uniform(est_scale*0.5,3*est_scale/2 )
        c_values = {}
        for n in range(N):
            c_values[n,n] = 0
            for np in range(n):
                c_values[n,np] = c_values[np,n] = distancesNs[n,np]*random_c_scale
        
        ##
        # Computing fixed costs
        ##
        f_values = {}
        for n in range(N):
            f_values[n] = random.uniform(5000/15,12000/15)
        
        ###########################
        # Writing the values to the files
        ###########################
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
            
        # Drop box info
        with open(os.path.join(data_folder, "data_N.csv"), 'w',newline = "") as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(["ID","GROUP",'FixedCost'])
            csvwriter.writerow([0,'s',f_values[0]])
            for n in range(1,N):
                if n in T:
                    csvwriter.writerow([n,'V',f_values[n]])
                else:
                    csvwriter.writerow([n,'P',f_values[n]])
            
        ### Writing voter info
        with open(os.path.join(data_folder, "data_W.csv"), 'w',newline = "") as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(["ID","w","p","Ni","Nprime"])
            for w in range(W):
                csvwriter.writerow([w,1,1,"","-".join([str(n) for n in Nw[w]])])
        
        #### Cost matrix
        with open(os.path.join(data_folder, "data_C.csv"), 'w',newline = "") as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(["ID/ID"]+list(range(N)))
            for n in range(N):
                row = [n]
                for j in range(N):
                    row += [c_values[n,j]]
                csvwriter.writerow(row)
            
        ### participation matrix
        with open(os.path.join(data_folder, "data_participation.csv"), 'w',newline = "") as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(["ID","None","Other"]+list(range(N)))
            for w in range(W):
                row = [w,V0[w],V1[w]]
                for n in range(N):
                    row += [Vn[w,n]]
                csvwriter.writerow(row)

