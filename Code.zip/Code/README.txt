To create access data sets, use Code/Make Case Study/createTablePart_casestudy1.
To make the equity data sets, use Code/Make Case Study/createTableW_casestudy1. You must manually transfer the participation file from the Milwaukee folder

The RPCTP stores the exact algorithm for solving the problem.

Run the algorithms using RPCTP_run.py