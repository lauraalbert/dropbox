'''
This implements the robus participation covering tour problem 
formulation of the dropbox problem (exact solution method)

@author: Adam Schmidt, apschmidt2@wisc.edu
'''

import numpy as np
from timeit import default_timer as timer
from gurobipy import *
from collections import defaultdict
from itertools import combinations
import csv


class SetCover:
    def __init__(self,instance):
        self.instance = instance # The data instance
        self.solution_time = np.inf
        self.optimal_tour = None
        self.optimal_cost = np.inf
     
    def set_cover(self,rprime):
        '''
        This finds the minimum cost set cover without considering the 
        tour costs
        '''
        if self.instance is None:
            raise Exception('The RPCTP instance is not loaded')
    
        model = Model()
        
        ######## DECISION VARIABLES #############
        Y = model.addVars(self.instance.get_N(), name="y", vtype = GRB.BINARY) # Coverage Variables
        model._Yvars = Y
        
        ######## CONSTRAINTS #############
        # Must visit nodes in T
        for i in self.instance.get_T():
            model.addConstr(Y[i] == 1)
        
        for k in self.instance.get_W():
            # Base coverage constraint
            if len(self.instance.get_baseCoverage(k)) < 2:
                print('issue', k)
            model.addConstr(quicksum(Y[i] for i in self.instance.get_baseCoverage(k)) >= 2)
            
        # Robust constraint from epsilon constraint method
        # (objective two)
        for k in self.instance.get_Wpart():
            model.addConstr(self.instance.get_participationComponent(k,'vNone') <= 
                            rprime*(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    quicksum(self.instance.get_participationComponent(k,n)*Y[n] for n in self.instance.get_N())))
        
        
        ######## OBJECTIVE #############
        # TSP Tour length
        model.setObjective(quicksum(Y[j]*self.instance.get_fixedcost(j) for j in Y))
        
        model.Params.OutputFlag = 0
        model.Params.lazyConstraints = 1
        model.Params.TimeLimit = 3600
        model.update()
        model.optimize() # Solving the optimization model
        
        if model.status != GRB.OPTIMAL:
            return set()
        selected = set()
        solution_y = model.getAttr('x', model._Yvars)
        for j in solution_y:
            if solution_y[j] > 0.5:
                selected.add(j)
        return selected
        
    def TSP(self,nodes):
        '''
        '''
        
        #           https://www.gurobi.com/documentation/9.1/examples/tsp_py.html
        if len(nodes) == 1:
            n = nodes.pop()
            return [n,n]
        if len(nodes) == 2:
            tmp = list(nodes)
            t = tmp + [tmp[0]]
            return t
        
        # Callback - use lazy constraints to eliminate sub-tours
        def subtourelim(model, where):
            if where == GRB.Callback.MIPSOL:
                # make a list of edges selected in the solution
                vals = model.cbGetSolution(model._vars)
                selected = tuplelist((i, j) for i, j in model._vars.keys()
                                        if vals[i, j] > 0.5)
                # find the shortest cycle in the selected edge list
                tours = subtour(selected)
                for tour in tours:
                    if len(tour) < len(nodes):
                        # add subtour elimination constr. for every pair of cities in tour
                        model.cbLazy(quicksum(model._vars[i, j]
                                                 for i, j in combinations(tour, 2))
                                     <= len(tour)-1)
        
        
        # Given a tuplelist of edges, find the shortest subtour
        def subtour(edges):
            cycles = []
            unvisited = set(nodes)
            while unvisited:  # true if list is non-empty
                thiscycle = []
                neighbors = list(unvisited)
                while neighbors:
                    current = neighbors[0]
                    thiscycle.append(current)
                    unvisited.remove(current)
                    neighbors = [j for i,j in edges if i == current and j in unvisited]
                cycles.append(thiscycle)
            return cycles

        m = Model()
        m.Params.OutputFlag = 0
        # Create variables
        vars = {}
        for i in nodes:
            for j in nodes:
                if j in nodes and i < j:
                    vars[i,j] = vars[j,i]= m.addVar(obj=self.instance.get_cost(i,j)-self.instance.get_fixedcost(i)/2-self.instance.get_fixedcost(j)/2, vtype=GRB.BINARY, name='x')
        
        # Add degree-2 constraint
        for i in nodes:
            m.addConstr(sum(vars[i,j] for j in nodes if i != j) == 2)

        # Solving 
        m._vars = vars
        m.Params.lazyConstraints = 1
        m.update()
        m.optimize(subtourelim) #
        vals = m.getAttr('x', vars)
        selected = tuplelist((i, j) for i, j in m._vars if vals[i, j] > 0.5)
        tour = subtour(selected)[0]
        tour += [tour[0]]
#         print()
#         print('Solution found',tour)
        if len(tour) != len(nodes)+1:
            print(nodes)
            print(tour)
            print(subtour(selected))
            print(selected)
            raise Exception(f'Error finding tour, nodes {set(nodes).difference(tour)} not included')
        
        return tour
        
    def subtour(self,arcs):
        '''
        This function will find subtours within the given arcs. Will return the 
        nodes in the order in which they are visited within the subtour (ignoring 
        return to starting node).
        '''
        visited = {}
        visited_nodes = list(set([i for i,j in arcs]).union(set([j for i,j in arcs])))
        openset = set()
        for i in self.instance.get_N():
            visited[i]=False
            if i in visited_nodes: # Need this as we may not visit all
                openset.add(i)
        cycles = []
        lengths = []
        neighbors = defaultdict(lambda: [])
        for a,b in arcs:
            neighbors[a].append(b)
            neighbors[b].append(a)
        while True:
            current = openset.pop()
            # start BFS for a cycle at the node current
            thiscycle = [current]
            while True:
                visited[current] = True
                curneighbors = [a for a in neighbors[current] if not visited[a]]
                if len(curneighbors) == 0:
                    break
                current = curneighbors[0]
                openset.remove(current)
                thiscycle.append(current)
            cycles.append(thiscycle)
            lengths.append(len(thiscycle))
            if len(openset) < 1:
                break
        return cycles
           
    
    def get_participation(self,selected,type = 'worstcase'):
        '''
        Calculates the estimated participation of each node W
        
        type:
           a) 'worstcase' find the worst case participation
           b) 'all' find the participation of each node W
        '''
        selected = set(selected) # Making sure no duplicates
        if type == 'worstcase':
            p = 0
            for k in self.instance.get_Wpart():
                phat = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
                if phat > p:
                    p= phat
        elif type == 'all':
            p = {}
            for k in self.instance.get_Wpart():
                p[k] = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
        return p
    
    def print_solution(self,rprime,tour):
        print(rprime,self.get_participation(tour[:-1]), self.tour_cost(tour),len(tour)-1,tour)
        
        
    def solve(self,method = 'exact',pareto = 'complete', parteo_param = -1):
        '''
        [method] Expects one of the following methods:
        1) exact: use lazy constraint implementation of the 
                problem where lazy constraints are only for SEC
        2) exact_extralazy: like exact, but also use lazy constraints
                for the coverage constraints
        
        [pareto] Expects one of the following:
        1) complete: will attempt to approximate the complete pareto frontier
        2) one: will attempt to find a single solution to the problem
        
        [parteo_param] Expects depends on [pareto]
        1) if [pareto] == 'complete', then [parteo_param] represents the jump 
           size between solution for the worst case participation
        2) if [pareto] == 'one', then [pareto] represents the bound on the 
           worst case participation for the desired solution
           
        [parteo_param] can have size 1 or 2. If size 2, the first index indicates
         the starting value for the complete frontier 
        '''
        solutions = {}
        timer_start = timer()
        if method == 'exact':
            if pareto == 'complete':
                start = 1
                if len(parteo_param) > 1:
                    start = parteo_param[0]
                    parteo_param = parteo_param[1]
                rprime = start
                while rprime > 0:
                    nodes = self.set_cover(rprime)
                    if len(nodes) < 1:
                        rprime = -1
                        
                    else:
                        tour = self.TSP(nodes)
                        self.print_solution(rprime,tour)
                        part = self.get_participation(set(tour))
                        rprime = part - parteo_param
                        solutions[part, self.tour_cost(tour)] = tour
                        
            elif pareto == 'one':
                nodes = self.set_cover(rprime)
                tour = self.TSP(nodes)
                part = self.get_participation(set(tour))
                rprime = part - parteo_param
                solutions[part, self.tour_cost(tour)] = tour
                
            
            else:
                raise Exception(f'Pareto parameter {pareto} unknown')
        timer_end = timer()
        print('Solution Time', timer_end - timer_start)
        with open(os.path.join(self.instance.data_folder,"set_cover_results.csv"), "w",newline = '') as f:
            writer = csv.writer(f)
            pairs = list(solutions.keys())
            writer.writerow(['Max Non-Participation','Tour Cost','Number DBs','Fixed Cost','Tour'])
            for k,l in solutions:
                writer.writerow([k,l, len(solutions[k,l])-1, self.get_fixedcost(set(solutions[k,l])), "-".join(solutions[k,l])])
    
    
    
    def tour_cost(self,tour):
        if len(tour) == 0:
            return 0
        if len(tour) <= 2:
            return self.instance.get_fixedcost(tour[0])
        cost = 0
        for i in range(1,len(tour)):
            cost +=  self.instance.get_cost(tour[i-1],tour[i])
        
        return cost
    
    
    def get_fixedcost(self,nodes):
        '''
        Given the tour nodes, calculated the fixed cost of the nodes
        '''
        c = 0
        for n in nodes:
            c += self.instance.get_fixedcost(n)
        return c    