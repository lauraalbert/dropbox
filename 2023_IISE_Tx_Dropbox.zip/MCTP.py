'''
Created on Mar 19, 2021

@author: apschmidt
'''

from timeit import default_timer as timer

from gurobipy import *

from read_data import *

####
##### Decision info
n = 1 # number of new drop boxes to locate
e = 300000 # number of uncovered population
####


###
###
### OPTIMIZATION MODEL
###
###
model = Model()

######## DECISION VARIABLES #############
X = model.addVars(c, name="x", vtype = GRB.BINARY) # Tour variables
Y = model.addVars(W, name="y", vtype = GRB.BINARY) # Coverage Variables
U = model.addVars(N, name='u', vtype = GRB.INTEGER, ub = (len(T)+n-1)-1) # SEC variables
model.update()


######## CONSTRAINTS #############


# Must visit nodes
for i in T:
    model.addConstr(quicksum(X[i,j] for j in N) == 1)

# Place n new drop boxes
model.addConstr(quicksum(X[i,j] for i in P for j in N) == n)

# Flow in = Flow out
for j in N:
    model.addConstr(quicksum(X[i,j] for i in N) == quicksum(X[j,k] for k in N))

# Subtour elimination constraints
for i,j in c:
    if i != s and j != s:
        model.addConstr(U[i] - U[j] + 1 <= (len(T)+n-1)*(1-X[i,j]))

# # This forces the U values to be meaningful but unneccesary
# for i in N:
#     model.addConstr(U[i] <= (len(T)+n-1)*quicksum(X[i,j] for j in N))
#     model.addConstr(U[i] >= quicksum(X[i,j] for j in N))

# Coverage indicator constraint
for k in W:
    model.addConstr(1-Y[k] <= quicksum(X[i,j] for i in Ni[k] for j in N))
    
# Base coverage constraint
for k in W:
    model.addConstr(2 <= quicksum(X[i,j] for i in Nprime[k] for j in N))


# Coverage (objective one)
model.addConstr(quicksum(W[i][0]*W[i][1]*Y[i] for i in W) <= e)


######## OBJECTIVE #############
# TSP Tour length
model.setObjective(quicksum(c[i,j]*X[i,j] for i in N  for j in N))

######## SOLUTIUON #############
start = timer()
model.optimize()
end = timer()


if model.status == GRB.OPTIMAL:
    solution_x = model.getAttr('x', X)
    solution_y = model.getAttr('x', Y)
    solution_u = model.getAttr('x', U)
  
    last = None
    tour = [office]
    while last != office:
        for j in N:
            if solution_x[tour[-1],j] >= 0.5:
                tour.append(j)
                break
        last = tour[-1]
    
    print("Optimal tour:", tour)
    
    print()
    print("Optimal Tour Length:", sum([c[tour[i],tour[i+1]] for i in range(len(tour)-1)]))
    
    print("Optimal Coverage:", sum(W[i][1] for i in W if len(list(set(Ni[i]) & set(tour)))> 0) )
# for i in U:
#     if i in tour:
#         print(i, solution_u[i])
# for i in X:
#     if solution_x[i] > 0:
#         print(i,solution_x[i])
     
print()
print("Solution Time",end - start)