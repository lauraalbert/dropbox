'''
This implements the robus participation covering tour problem 
formulation of the dropbox problem (heuristic formulation)

@author: Adam Schmidt, apschmidt2@wisc.edu
'''
from itertools import combinations
import numpy as np
from timeit import default_timer as timer
from gurobipy import *
from collections import defaultdict
import heapq
from CTPish import SchmidtAlgorithm1 as SchmidtAlgorithm4
import csv

class RPCTP_heuristic2:
    def __init__(self,instance,data):
        self.folder = data
        self.instance = instance
        self.solution_time = np.inf
        self.optimal_tour = None


    def solveCTPish(self): 
        '''
        This will solve the CTPish subproblem. We must find a tour on a 
        subset of nodes (that includes T) such that each W is covered *twice*.
        
        Our approach: 
        1) Find a Steiner tree on auxiliary graph
        2) Add nodes of V spanned by the ST to the set T
        2) For each node of W that is covered twice by nodes of N spanned by
           the tree, remove it from the Steiner Tree
        3) Remove edges between the nodes of V spanned by the ST and the remaining
           nodes of W
        4) Resolve the Steiner tree problem
        5) Remove Redundant nodes
        6) Find TSP on these nodes
        
        This is implemented in a different class
        ''' 
        
        a = SchmidtAlgorithm4()
        a.load(self.folder)
#         test = np.zeros(len(self.instance.get_N()), dtype=int)
#         test[1] = 1
#         n = list(self.instance.get_N())
#         self.optimal_tour = n + [n[0]]
#         n = list(self.instance.get_T())
#         a = n[0]
        self.optimal_tour = a.solve()
#         return test
    
    def get_tour_length(self):
        '''
        Expects an ordered list where the final element is the first element
        '''
        tour = self.optimal_tour
        if len(tour) == 0:
            return 0
        if len(tour) <= 2:
            return self.instance.get_fixedcost(tour[0])
        cost = 0
        for i in range(1,len(tour)):
            cost +=  self.instance.get_cost(tour[i-1],tour[i])
        
        return cost
        
    def get_participation(self,type = 'worstcase'):
        '''
        Calculates the estimated participation of each node W
        
        type:
           a) 'worstcase' find the worst case participation
           b) 'all' find the participation of each node W
        '''
        selected = set(self.optimal_tour) # Making sure no duplicates
        if type == 'worstcase':
            p = 0
            for k in self.instance.get_Wpart():
                phat = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
                if phat > p:
                    p= phat
        elif type == 'all':
            p = {}
            for k in self.instance.get_Wpart():
                p[k] = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
        return p
        
        
    
    def estimateInsertionCost(self,tour,node):
        '''
        This method looks at the tour passed as an argument and finds the 
        cheapest insertion to the tour
        '''
        if len(tour) == 0:
            return self.instance.get_fixedcost(node)
        cost_increase = np.inf
        for i in range(1,len(tour)):
            added_cost = self.instance.get_cost(tour[i-1],node)+self.instance.get_cost(tour[i],node)-self.instance.get_cost(tour[i-1],tour[i])
            if added_cost < cost_increase:
                cost_increase = added_cost
        return cost_increase
    
    def removeFromTour(self,tour,node):
        '''
        This method will remove a node from [tour] and return the new tour
        and the reduced cost be removing the node
        '''
        if node is None:
            return tour[:],0
        if len(tour) == 2:
            if tour[0] == node:
                return [],0
            else:
                f = f'Node {node} not in tour {tour}'
                raise Exception(f)
        
        tour = tour[:]
        if tour[0] == node:
            tour = tour[1:-1]
            tour.append(tour[0])
#             print(tour)
            return tour, self.instance.get_cost(tour[1],node)+self.instance.get_cost(tour[-2],node)
        i = tour.index(node)
        rc = self.instance.get_cost(tour[i-1],tour[i+1]) - self.instance.get_cost(tour[i-1],node)-self.instance.get_cost(tour[i+1],node)
        tour.remove(node)
        return tour, rc
    
    def swapNodes(self,tour,n1,n2):
        '''
        Removes n1 from the tour and adds n2.
        '''
        if n1 not in tour and (n1 is not None):
            s = f"Node {n1} not in tour {tour}"
            raise Exception(s)
        if n2 in tour:
            s = f'Node {n2} already in tour {tour}'
            raise Exception(s)
        tour_nodes = set(tour)
        if n2 is not None:
            tour_nodes = tour_nodes.union([n2])
        tour_nodes =tour_nodes.difference([n1])
        best_tour = self.get_optimal_tour(tour_nodes)
#         
#         tour,reduced_cost = self.removeFromTour(tour,n1)
#         if n2 is None:
#             return tour 
#         
#         if len(tour) == 0:
#             return [n2,n2]
        
        
#         cost_increase = np.inf
#         best_tour = None
#         for i in range(1,len(tour)):
#             added_cost = self.instance.get_cost(tour[i-1],n2)+self.instance.get_cost(tour[i],n2)
#             if added_cost < cost_increase:
#                 cost_increase = added_cost
#                 best_tour = tour[:i] + [n2] + tour[i:]
        
        return best_tour
    
    def get_optimal_tour(self,nodes):
#           https://www.gurobi.com/documentation/9.1/examples/tsp_py.html
        if len(nodes) == 1:
            n = nodes.pop()
            return [n,n]
        if len(nodes) == 2:
            tmp = list(nodes)
            t = tmp + [tmp[0]]
            return t
        
        # Callback - use lazy constraints to eliminate sub-tours
        def subtourelim(model, where):
            if where == GRB.Callback.MIPSOL:
                # make a list of edges selected in the solution
                vals = model.cbGetSolution(model._vars)
                selected = tuplelist((i, j) for i, j in model._vars.keys()
                                        if vals[i, j] > 0.5)
                # find the shortest cycle in the selected edge list
                tours = subtour(selected)
                for tour in tours:
                    if len(tour) < len(nodes):
                        # add subtour elimination constr. for every pair of cities in tour
                        model.cbLazy(quicksum(model._vars[i, j]
                                                 for i, j in combinations(tour, 2))
                                     <= len(tour)-1)
        
        
        # Given a tuplelist of edges, find the shortest subtour
        def subtour(edges):
            cycles = []
            unvisited = set(nodes)
            while unvisited:  # true if list is non-empty
                thiscycle = []
                neighbors = list(unvisited)
                while neighbors:
                    current = neighbors[0]
                    thiscycle.append(current)
                    unvisited.remove(current)
                    neighbors = [j for i,j in edges if i == current and j in unvisited]
                cycles.append(thiscycle)
            return cycles

        m = Model()
        m.Params.OutputFlag = 0
        # Create variables
        vars = {}
        for i in nodes:
            for j in nodes:
                if j in nodes and i < j:
                    vars[i,j] = vars[j,i]= m.addVar(obj=self.instance.get_cost(i,j)-self.instance.get_fixedcost(i)/2-self.instance.get_fixedcost(j)/2, vtype=GRB.BINARY, name='x')
        
        # Add degree-2 constraint
        for i in nodes:
            m.addConstr(sum(vars[i,j] for j in nodes if i != j) == 2)

        # Solving 
        m._vars = vars
        m.Params.lazyConstraints = 1
        m.update()
        m.optimize(subtourelim) #
        vals = m.getAttr('x', vars)
        selected = tuplelist((i, j) for i, j in m._vars if vals[i, j] > 0.5)
        tour = subtour(selected)[0]
        tour += [tour[0]]
#         print()
#         print('Solution found',tour)
        if len(tour) != len(nodes)+1:
            print(nodes)
            print(tour)
            print(subtour(selected))
            print(selected)
            raise Exception(f'Error finding tour, nodes {set(nodes).difference(tour)} not included')
        
        return tour
#     def reorderTour(self,tour):
#         '''
#         This reorders the tour to hopefully improve tour cost
#         '''
#         for i in tour:
#             for j in tour:
    
    def computeDeltaI(self,n1,n2,wcov_index,wcov):
        '''
        This takes in n1 and n2 and computes the change in the coverage that
        occurs.
        
        wcov are the nodes to cover
        wcov_index tells us the index to place the value in the vector
        '''
        deltaI = np.zeros(len(wcov))
        n1cov = set()
        if n1 is not None:
            n1cov = set(self.instance.get_baseCoverage(n1))
        n2cov = set()
        if n2 is not None:
            n2cov = set(self.instance.get_baseCoverage(n2))
        n1diffn2 = n1cov.difference(n2cov)
        n2diffn1 = n2cov.difference(n1cov)
        for k in wcov:
            if k in n1diffn2:
                deltaI[wcov_index[k]] = -1
            elif k in n2diffn1:
                deltaI[wcov_index[k]] = 1
        return deltaI
      
    def solve(self,pareto = 'complete', parteo_param = -1):
        '''
        [pareto] Expects one of the following:
        1) complete: will attempt to approximate the complete pareto frontier
        2) one: will attempt to find a single solution to the problem
        
        [parteo_param] Expects depends on [pareto]
        1) if [pareto] == 'complete', then [parteo_param] represents the jump 
           size between solution for the worst case participation
        2) if [pareto] == 'one', then [pareto] represents the bound on the 
           worst case participation for the desired solution
        '''
        timer_start = timer()
        solutions = {}
        
        stop = 0
        start = 1
        epsilon = parteo_param
            
        if pareto == 'one':
            stop = parteo_param
            epsilon = 0.01
        
        #####
        # We use vector/matrix representation to do the computation
        #####
        # Storing the row of each w and n
        wpart = self.instance.get_Wpart()
        wcov = self.instance.get_W()
        n = list(self.instance.get_N())
        wpart_index = {}
        for i in range(len(wpart)):
            wpart_index[wpart[i]] = i
            
        wcov_index = {}
        for i in range(len(wcov)):
            wcov_index[wcov[i]] = i
        
        n_index = {}
        for i in range(len(n)):
            n_index[n[i]] = i
            
        # Getting the participation matrices
        V0 = np.array([self.instance.get_participationComponent(k,'vNone') for k in wpart])
        V0.shape = (len(wpart),1)
        V1 = np.array([self.instance.get_participationComponent(k,'vOther') for k in wpart])
        V1.shape = (len(wpart),1)
        Vn = np.matrix([[self.instance.get_participationComponent(k,j) for j in n] for k in wpart])
        
        #########
        # Finding the first tour ('shortest')
        #########
        self.solveCTPish()
        selected = np.zeros(len(n))
        for j in self.optimal_tour:
            selected[n_index[j]] = 1
        selected.shape = (len(selected),1)
        
        # This represents the initial participation rate among W
        denom_last = V0 + V1 + np.dot(Vn,selected)
        P = np.divide(V0,denom_last)
        
        # Now storing the initial coverage
        I = np.zeros(len(wcov),dtype = int)
        for k in wcov:
            I[wcov_index[k]] = len(set(self.instance.get_baseCoverage(k)).intersection(self.optimal_tour))
        
        rprime = self.get_participation()
        solutions[self.get_participation(), self.get_tour_length()] = self.optimal_tour
        self.print_solution(rprime)
        
        # This is the best possible participation we can achieve
        # Well, actually it isn't as there may be coverage limitations
        stop = max(np.divide(V0,V0+V1+np.dot(Vn,np.ones((len(n),1)))))[0,0]
        
        # This finds the multiple soltions
        part_last = rprime
        seen = set() # Stores the tours we have seen to avoid cycling
        
        
        r_backwards_next = rprime-(rprime-stop)/20
        r_backwards_last = rprime
        rprime += (rprime-stop)/3
        final_backward = False
        while rprime > stop:
            # Initializing key parameters 
            current_nodes = set(self.optimal_tour)
            
            if part_last < rprime: # Then we can consider the no remove, no add option
#                 print('Running IF')
                #####
                # These are the params for the next iteration
                #####
                min_cost = 0
                denom_new = denom_last.copy()
                swap = (None,None)
                new_P = P.copy()
                new_rprime = rprime
                              
            else: # We must find a swap or addition
                # We look through all of the pure additions. This is guaranteed
                # To improve the worst case participation when v0 is strictly 
                # positive (assume it is)
#                 print('Running Else')
                min_cost = np.inf
                add_n = None
                # Finding the minimum cost node to add
                for n2 in self.instance.get_N().difference(current_nodes):
                    cost_change = self.estimateInsertionCost(self.optimal_tour.copy(),n2)
                    if cost_change < min_cost:
                        min_cost = cost_change
                        add_n = n2
                        
                # Updating the parameters
                change_participation = np.multiply(V0,np.zeros((len(wpart),1))-Vn[:,n_index[add_n]])
                denom_new = denom_last + Vn[:,n_index[add_n]]
                deltaP = np.divide(change_participation,np.multiply(denom_new,denom_last))
                new_P = P+deltaP
                new_rprime = max(P+deltaP)[0,0]
                swap = (None,add_n)
               
            ####
            # We consider swaps now
            ####
#             print('Searching n1')
            for n1 in current_nodes.difference(self.instance.get_T()): # This is the remove node
                
                # First, we want to check if we can simply remove any nodes
                # without adding any back in. If so, we don't need to consider
                # any n2 paired with n1 as this will strictly increase the cost
                new_tour, reducedcost = self.removeFromTour(self.optimal_tour,n1)
                valid_removal = False
                if reducedcost < min_cost:
                    # We check feasibility 
                    # 1) Make sure coverage stays feasible
                    delta_n1 = set([k for k in self.instance.get_baseCoverage(n1) if abs(I[wcov_index[k]]-2)<0.5]) # Number of w that n1 covers and has exactly 2 DB's covering it
                    if len(delta_n1) == 0:
                        # 2) Check the participation
                        tmp_change_participation = np.multiply(V0,Vn[:,n_index[n1]])
                        tmp_denom_new = denom_last - Vn[:,n_index[n1]]
                        tmp_deltaP = np.divide(tmp_change_participation,np.multiply(tmp_denom_new,denom_last))
                        tmp_P = P+tmp_deltaP
                        tmp_rprime = max(tmp_P)
                        if tmp_rprime < rprime: # This is a feasible removal
                            new_P = tmp_P
                            swap = (n1,None)
                            min_cost = reducedcost
#                             valid_removal = True
                            new_rprime = tmp_rprime[0,0]
                            denom_new = tmp_denom_new
                
                # Right now this doesn't do anything. This can be changed to 
                # Skip the below procedure if a node is removed above without
                # A replacement
                if not valid_removal:
            
                    # We now consider swaps
                    # Finding the updated participation for each swap
                    # At the same time, determining the change in the cost to 
                    # Remove n1 and add n2
                    # And also determining which swaps are feasbile from a coverage constraint
                    
                    # We want to start with the lowest cost swap to see 
                    # if that is feasible. If so, then we don't need to consider
                    # any others. 
                    n2_nodes = self.instance.get_N().difference(current_nodes) # Can add a node not currently in the tour
                    pq = []
                    for n2 in n2_nodes:
                        heapq.heappush(pq,(self.estimateInsertionCost(new_tour,n2)+reducedcost,n1,n2))
#             print(pq)     
            if pq[0][0] < min_cost: # None of the swaps are cheaper than our cheapest
#                 print('Made PQ')
                while pq:
                    cost, n1, n2 = heapq.heappop(pq) 
                    # We first check to make sure the cost is less than our min cost
    #                         cost = self.estimateInsertionCost(new_tour,n2)+reducedcost
                    if cost < min_cost:
                        # We now check feasibility
                        # 1) Check coverage feasibility
                        delta_n1 = set([k for k in self.instance.get_baseCoverage(n1) if abs(I[wcov_index[k]]-2)<0.5])
                        if len(delta_n1.intersection(self.instance.get_baseCoverage(n2))) == len(delta_n1):
                            # 2) The participation must improve
                            tmp_change_participation = np.multiply(V0,Vn[:,n_index[n1]]-Vn[:,n_index[n2]])
                            tmp_denom_new = denom_last + Vn[:,n_index[n2]] - Vn[:,n_index[n1]]
                            tmp_deltaP = np.divide(tmp_change_participation,np.multiply(tmp_denom_new,denom_last))
                            tmp_P = P+tmp_deltaP
                            tmp_rprime = max(tmp_P)
                            if tmp_rprime < rprime: # This is a feasible removal
                                new_P = tmp_P
                                swap = (n1,n2)
                                min_cost = cost
                                new_rprime = tmp_rprime[0,0]
                                denom_new = tmp_denom_new
                                break # We don't need to consider any others
#             print('Searched PQ')           
            if min_cost < np.inf: # We have found a valid solution
                #####
                # We now update all of our parameters
                #####
                rprime_last = rprime
                if min_cost == 0 and part_last < rprime: # There is no beneficial change (we have a (None, None) swap)
                    rprime = max(new_P)[0,0]
                else: # There was some beneficial change
                    rprime = max(new_rprime,rprime - epsilon)
                part_last = new_rprime
                denom_last = denom_new
                P = new_P
                I = I +  self.computeDeltaI(swap[0],swap[1],wcov_index,wcov)
#                 print('Updated Params')
                self.optimal_tour = self.swapNodes(self.optimal_tour,swap[0],swap[1])
#                 print('Updated Tour')
                current_nodes = set(self.optimal_tour)
                solutions[self.get_participation(), self.get_tour_length()] = self.optimal_tour
                a = list(set(self.optimal_tour))
                a.sort() 
                a = '-'.join(a)
                if a in seen: # We skip the cycle
                    rprime = max(new_P)[0,0]
                else:    
                    seen.add(a)
                self.print_solution(rprime)
                if len(self.optimal_tour)-1 == len(self.instance.get_N()):
                    break
                
                if rprime <= r_backwards_next:
                    difference_rprime = r_backwards_last - rprime
                    rprime = rprime + 0.5*difference_rprime
                    r_backwards_last = rprime
                    r_backwards_next = rprime - difference_rprime
                    if r_backwards_next <= stop and not final_backward:
                        final_backward = True
                        r_backwards_next = stop + 0.001
                        
                
            else:
                break
            
                
        timer_end = timer()
        print('Solution Time', timer_end - timer_start)
        with open(os.path.join(self.instance.data_folder,"heuristic2_results.csv"), "w",newline = '') as f:
            writer = csv.writer(f)
            pairs = list(solutions.keys())
            writer.writerow(['Max Non-Participation','Tour Cost','Number DBs','Fixed Cost','Tour'])
            for k,l in solutions:
                pareto = True
                for i,j in pairs:
                    if k > i and l > j:
    #                     print('NOT PARETO',(k,l),(i,j))
                        pareto = False
                        break
                if pareto:
                    writer.writerow([k,l, len(solutions[k,l])-1, self.get_fixedcost(set(solutions[k,l])), "-".join(solutions[k,l])])
    
           
    def feasible(self,rprime):
        # Check if participation feasible
        if self.get_participation()> rprime  and abs(self.get_participation()-rprime) > 0.00001:
            print(f"Participation of {self.get_participation()} is not smaller than {rprime}")
            return False
            
        # Check if double coverage feasbile
        nodes = set(self.optimal_tour)
        for k in self.instance.get_W():
            if len(nodes.intersection(self.instance.get_baseCoverage(k)))<2:
                print(f"Node {k} not double covered for rprime {rprime}")
                print(nodes)
                print(self.instance.get_baseCoverage(k))
                print(nodes.intersection(self.instance.get_baseCoverage(k)))
                return False
        
        return True
    
    def get_fixedcost(self,nodes):
        '''
        Given the tour nodes, calculated the fixed cost of the nodes
        '''
        c = 0
        for n in nodes:
            c += self.instance.get_fixedcost(n)
        return c
    
    def print_solution(self,rprime):
        if not self.feasible(rprime):
            raise Exception(f"Found solution that is not feasible")
        
        
        print(rprime,self.get_participation(), self.get_tour_length(),len(self.optimal_tour)-1,self.get_fixedcost(set(self.optimal_tour)),self.optimal_tour)



