from os.path import expanduser
import os
import csv
from _collections import defaultdict
home = expanduser("~")

# tour = '-'.join(['vFire4', 'vFire8', 'vFire39', 'vFire38', 'vFire29', 'vFire10', 'vPolice6', 'vWalgreens12', 'vFire14', 'vPolice1', 'vElect1', 'vFire1', 'vCVS5', 'vFire27', 'vFire30', 'vFire34', 'vLibrary3', 'vFire4'])

tour = 'vFire8-vLibrary10-vWalgreens28-vLibrary7-vWalgreens29-vFire16-vFire10-vWalgreens20-vLibrary14-vPolice6-vFire12-vWalgreens12-vFire14-vWalgreens10-vWalgreens4-vFire1-vElect1-vLibrary8-vFire30-vFire13-vFire34-vLibrary3-vPolice4-vFire8'

####
# We get the elements for the tour
####
tour = tour.split("-")
####
# We read in the location data
####
d = {}
with open(os.path.join(home,'Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data','potential_db_locations.csv'), newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=',', quotechar='|')
    count = 0
    for row in reader:
        if count < 1:
            count += 1
        else:
            d['v'+row[0]] = row[1],row[2]

####
# We build the new data set
####
import csv
with open(os.path.join(home,'Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/Results','selected_locations_test.csv'), 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    
    spamwriter.writerow(['From Latitude','From Longitude','To Latitude','To Longitude', 'Dummy','Name'])
    for i in range(1,len(tour)):
        d_from = d[tour[i-1]]
        d_to = d[tour[i]]
        spamwriter.writerow([d_from[0],d_from[1],d_to[0],d_to[1],i*-1,tour[i-1]])
    
    # Loop back
    d_from = d[tour[-1]]
    d_to = d[tour[0]]
    spamwriter.writerow([d_from[0],d_from[1],d_to[0],d_to[1],(i+1)*-1,tour[-1]])

####
# Writing a supporting file to store the (worst-case) participation in each area
####

# Read in Participation information
part = defaultdict(dict)
with open(os.path.join(home,'Box/Research/Elections/Dropbox/Code/MCTP/Data/Milwaukee/data_participation.csv'), "r") as csvfile:
    reader = csv.reader(csvfile)
    count = 0
    headers = []
    for row in reader:
        if count == 0: # header row
            count = 1
            headers = row
        else:
            for n in range(1,len(headers)):
                part[row[0]]['v'+headers[n]] = float(row[n])

# Now for each Block group, we store the worst case participation
worst_part = defaultdict(lambda: (None,None,100))

print(len(part))
for i in part:
#     bg,vehicle,work = i.split('-')
    bg = i
    vehicle,work = None, None
    participation = 100*( 1-part[i]['vNone']/sum([part[i]['vNone'], part[i]['vOther']]+[part[i][j] for j in set(tour)]) )
    if participation < worst_part[bg][-1]:
        worst_part[bg] = (vehicle, work, participation)


with open(os.path.join(home,'Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/Results','selected_locations_vr_test.csv'), 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    
    spamwriter.writerow(['FIPS','Car Avail','Work Location','Worst-Case Participation'])
    for i in worst_part:
        spamwriter.writerow([i,worst_part[i][0],worst_part[i][1],worst_part[i][2] ])
