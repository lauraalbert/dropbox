'''
This implements the robust participation covering tour problem 
formulation of the dropbox problem (heuristic formulation)

This differs from Heuristic 1 in the following ways:
1) Instead of adding least cost sway, we add the one with the least cost/value

@author: Adam Schmidt, apschmidt2@wisc.edu
'''
from itertools import combinations
import numpy as np
from timeit import default_timer as timer
from gurobipy import *
from collections import defaultdict
import heapq
from CTPish import SchmidtAlgorithm1 as SchmidtAlgorithm4
import csv
from test.test_iterlen import NoneLengthHint

class RPCTP_heuristic_value2:
    def __init__(self,instance,data):
        self.folder = data
        self.instance = instance
        self.solution_time = np.inf
        self.optimal_tour = None


    def solveCTPish(self): 
        '''
        This will solve the CTPish subproblem. We must find a tour on a 
        subset of nodes (that includes T) such that each W is covered *twice*.
        
        Our approach: 
        1) Find a Steiner tree on auxiliary graph
        2) Add nodes of V spanned by the ST to the set T
        2) For each node of W that is covered twice by nodes of N spanned by
           the tree, remove it from the Steiner Tree
        3) Remove edges between the nodes of V spanned by the ST and the remaining
           nodes of W
        4) Resolve the Steiner tree problem
        5) Remove Redundant nodes
        6) Find TSP on these nodes
        
        This is implemented in a different class
        ''' 
        
        a = SchmidtAlgorithm4()
        a.load(self.folder)
        self.optimal_tour = a.solve()
    
    def get_tour_length(self):
        '''
        Expects an ordered list where the final element is the first element
        '''
        tour = self.optimal_tour
        if len(tour) == 0:
            return 0
        if len(tour) <= 2:
            return self.instance.get_fixedcost(tour[0])
        cost = 0
        for i in range(1,len(tour)):
            cost +=  self.instance.get_cost(tour[i-1],tour[i])
        
        return cost
        
    def get_participation(self,type = 'worstcase'):
        '''
        Calculates the estimated participation of each node W
        
        type:
           a) 'worstcase' find the worst case participation
           b) 'all' find the participation of each node W
        '''
        selected = set(self.optimal_tour) # Making sure no duplicates
        if type == 'worstcase':
            p = 1
            for k in self.instance.get_Wpart():
                phat = self.compute_participation(k,selected)
                if phat < p:
                    p= phat
        elif type == 'all':
            p = {}
            for k in self.instance.get_Wpart():
                p[k] = self.compute_participation(k,selected)
        return p
        
        
    
    def estimateInsertionCost(self,tour,node):
        '''
        This method looks at the tour passed as an argument and finds the 
        cheapest insertion to the tour
        '''
        if node is None:
            return 0
        if len(tour) == 0:
            return self.instance.get_fixedcost(node)
        cost_increase = np.inf
        for i in range(1,len(tour)):
            added_cost = self.instance.get_cost(tour[i-1],node)+self.instance.get_cost(tour[i],node)-self.instance.get_cost(tour[i-1],tour[i])
            if added_cost < cost_increase:
                cost_increase = added_cost
        return cost_increase
    
    def removeFromTour(self,tour,node):
        '''
        This method will remove a node from [tour] and return the new tour
        and the reduced cost be removing the node
        '''
        if node is None:
            return tour[:],0
        if len(tour) == 2:
            if tour[0] == node:
                return [],self.instance.get_fixedcost(node)
            else:
                f = f'Node {node} not in tour {tour}'
                raise Exception(f)
        
        tour = tour[:]
        if tour[0] == node:
            tour = tour[1:-1]
            tour.append(tour[0])
            return tour, self.instance.get_cost(node,tour[1])+self.instance.get_cost(tour[-2],node)
        i = tour.index(node)
        rc = self.instance.get_cost(tour[i-1],tour[i+1]) - self.instance.get_cost(tour[i-1],node)-self.instance.get_cost(tour[i+1],node)
        tour.remove(node)
        return tour, rc
    
    def findTour(self,nodes):
        return self.get_optimal_tour(nodes)
    
    def get_optimal_tour(self,nodes):
#           https://www.gurobi.com/documentation/9.1/examples/tsp_py.html
        if len(nodes) == 1:
            n = nodes.pop()
            return [n,n]
        if len(nodes) == 2:
            tmp = list(nodes)
            t = tmp + [tmp[0]]
            return t
        
        # Callback - use lazy constraints to eliminate sub-tours
        def subtourelim(model, where):
            if where == GRB.Callback.MIPSOL:
                # make a list of edges selected in the solution
                vals = model.cbGetSolution(model._vars)
                selected = tuplelist((i, j) for i, j in model._vars.keys()
                                        if vals[i, j] > 0.5)
                # find the shortest cycle in the selected edge list
                tours = subtour(selected)
                for tour in tours:
                    if len(tour) < len(nodes):
                        # add subtour elimination constr. for every pair of cities in tour
                        model.cbLazy(quicksum(model._vars[i, j]
                                                 for i, j in combinations(tour, 2))
                                     <= len(tour)-1)
        
        
        # Given a tuplelist of edges, find the shortest subtour
        def subtour(edges):
            cycles = []
            unvisited = set(nodes)
            while unvisited:  # true if list is non-empty
                thiscycle = []
                neighbors = list(unvisited)
                while neighbors:
                    current = neighbors[0]
                    thiscycle.append(current)
                    unvisited.remove(current)
                    neighbors = [j for i,j in edges if i == current and j in unvisited]
                cycles.append(thiscycle)
            return cycles

        m = Model()
        m.Params.OutputFlag = 0
        # Create variables
        vars = {}
        for i in nodes:
            for j in nodes:
                if j in nodes and i < j:
                    vars[i,j] = vars[j,i]= m.addVar(obj=self.instance.get_cost(i,j)-self.instance.get_fixedcost(i)/2-self.instance.get_fixedcost(j)/2, vtype=GRB.BINARY, name='x')
        
        # Add degree-2 constraint
        for i in nodes:
            m.addConstr(sum(vars[i,j] for j in nodes if i != j) == 2)

        # Solving 
        m._vars = vars
        m.Params.lazyConstraints = 1
        m.update()
        m.optimize(subtourelim) #
        vals = m.getAttr('x', vars)
        selected = tuplelist((i, j) for i, j in m._vars if vals[i, j] > 0.5)
        tour = subtour(selected)[0]
        tour += [tour[0]]
#         print()
#         print('Solution found',tour)
        if len(tour) != len(nodes)+1:
            print(nodes)
            print(tour)
            print(subtour(selected))
            print(selected)
            raise Exception(f'Error finding tour, nodes {set(nodes).difference(tour)} not included')
        
        return tour
    def check_coverage(self,nodes):
        '''
        This will check if each w is covered at least twice
        '''
        
        for w in self.instance.get_W():
            if len(nodes.intersection(self.instance.get_baseCoverage(w))) < 2:
                return False
        return True
    
    def compute_participation(self,w, nodes):
        '''
        Computes the participation of w given the nodes 
        '''
        return 1-(self.instance.get_participationComponent(w,'vNone')/( self.instance.get_participationComponent(w,'vNone')+self.instance.get_participationComponent(w,'vOther')+sum([self.instance.get_participationComponent(w,i) for i in nodes])))
        
    def min_participation(self,nodes):
        '''
        This will check if each w is covered at least twice
        '''
        minp = np.inf
        for w in self.instance.get_W():
            p = self.compute_participation(w,nodes)
            if p < minp:
                minp = p
        return minp
    
    def check_participation(self,nodes,r):
        '''
        This will check if each w is covered at least twice
        '''
        
        for w in self.instance.get_W():
            if self.compute_participation(w,nodes) <= r:
                return False
        return True
     
    def update_set(self,nodes,n1,n2):
        '''
        Will remove n1 from the set and add n2
        '''
        n = nodes.copy()
        if n1 is None:
            n = n
        else:
            n = n.difference([n1])
    
        if n2 is None:
            return frozenset(n)
        else:
            n.add(n2)
            return frozenset(n)
                
    def compute_swap_value(self,delta_r,delta_c):
        '''
        Computes the 'value' of a feasible swap
        
        Based on 
        
        @article{current_median_1994,
            title = {The median tour and maximal covering tour problems: {Formulations} and heuristics},
            volume = {73},
            issn = {0377-2217},
            shorttitle = {The median tour and maximal covering tour problems},
            url = {http://www.sciencedirect.com/science/article/pii/037722179490149X},
            doi = {10.1016/0377-2217(94)90149-X},
            abstract = {In this paper, the authors introduce two bicriterion routing problems: the median tour problem (MTP) and the maximal covering tour problem (MCTP). In …},
            language = {en},
            number = {1},
            urldate = {2021-03-15},
            journal = {European Journal of Operational Research},
            author = {Current, John R. and Schilling, David A.},
            month = feb,
            year = {1994},
            note = {Publisher: North-Holland},
            pages = {114--126},
            file = {Snapshot:C\:\\Users\\apschmidt\\Zotero\\storage\\VM354SDZ\\037722179490149X.html:text/html},
        }

        '''
        
        # In fourth quadrant, not of interest to us
        if delta_c >= 0 and delta_r < 0:
            return np.inf
        
        # Cost must be negative
        if delta_r == 0:
            if delta_c > 0:
                return 3*np.pi/2
            return np.pi/2
    
        if delta_r <= 0:
            # First quadrant
            if delta_c < 0:
                return np.arctan(delta_c/delta_r)
            # Second quadrant
            else:
                return np.pi + np.arctan(delta_c/delta_r)
        else:
            # Third quadrant
            return np.pi + np.arctan(delta_c/delta_r)
        
        print('ISSUE: got to end and didnt compute value')
               
#         if delta_c > 0:
#             if delta_r <= 0:
#                 return np.inf
#             else:
#                 return delta_c/delta_r
#         elif delta_c == 0:
#             if delta_r > 0:
#                 return -np.inf
#             else:
#                 return 0
#         else:
#             if delta_r < 0:
#                 return delta_c/delta_r # Really want delta_r/dela_c?
#             elif delta_r == 0:
#                 return -np.inf # We will take any negative cost
#             else:
#                 return delta_c/delta_r # Really want delta_c*delta_r
     
     
    def solve(self,pareto = 'complete', parteo_param = -1):
        '''
        [pareto] Expects one of the following:
        1) complete: will attempt to approximate the complete pareto frontier
        2) one: will attempt to find a single solution to the problem
        
        [parteo_param] Expects depends on [pareto]
        1) if [pareto] == 'complete', then [parteo_param] represents the jump 
           size between solution for the worst case participation
        2) if [pareto] == 'one', then [pareto] represents the bound on the 
           worst case participation for the desired solution
        '''
        
        
        timer_start = timer()
        solutions = {}
        
        stop = 1
        epsilon = parteo_param
        N = set(self.instance.get_N())    
        
        if pareto == 'one':
            stop = parteo_param
            epsilon = 0.01
        
        #########
        # Finding the first tour ('shortest')
        #########
        self.solveCTPish()
        rprime = self.get_participation()
        solutions[rprime, self.get_tour_length()] = self.optimal_tour
        self.print_solution(0)
        
        # This finds the multiple solutions
        count_iter = 0 
        last_participation = rprime
        past_node_sets = set() # Used to avoid cycling
        rprime = 0
        while rprime < stop:
            count_iter +=1 
            # Initializing key parameters 
            current_nodes = set(self.optimal_tour)
            Nminus_current = N.difference(current_nodes)
            # Finding all feasible swaps
            P = set()
            for n1 in (current_nodes.difference(self.instance.get_T())).union([None]):
                for n2 in Nminus_current.union([None]):
                    if n1 is not None or n2 is not None:
                        Np = self.update_set(current_nodes,n1,n2)
                        if self.check_coverage(Np):
                            minp = self.min_participation(Np)
                            if minp >= rprime:
                                P.add((n1,n2,Np,minp)) #node to remove, node to add, the updated set, and the new participation
            
            
            # Now finding the one with the minimum value
            min_value = np.inf # Initializing param 
            best_swap = (-1,-1,-1,-1,-1,-1,-1) # Stores (n1, n2, Np,minp,delta_r,delta_c,val)  
            for n1, n2, Np, minp in P:
                # Estimating the cost change
                new_tour, reducedcost = self.removeFromTour(self.optimal_tour,n1)    
                cost_change = self.estimateInsertionCost(new_tour,n2)+reducedcost
                
                # We only consider cases where change is participation positive
                # or the cost is negative
                delta_r = minp - last_participation
#                 print(n1,n2,delta_r,cost_change,self.compute_swap_value(delta_r,cost_change))
                if delta_r >= 0 or cost_change <= 0:
                    # Checking to see if best value
                    val = self.compute_swap_value(delta_r,cost_change)
#                     print(val, cost_change, delta_r )
                    if val < min_value:
                        min_value = val
                        best_swap = (n1, n2, Np,minp,delta_r,cost_change,val)
            
            ##################################
            ### We have found the 'best' swap
            ##################################
            n1, n2, Np, minp,delta_r, delta_c,val = best_swap
#             print(n1, n2,delta_r, delta_c)
            cost_last = self.get_tour_length()
            self.optimal_tour = self.findTour(Np)
            solutions[minp, self.get_tour_length()] = self.optimal_tour
            self.print_solution(rprime)
            
            if minp - last_participation < 0 and self.get_tour_length() > cost_last:
                print("ISSUE", best_swap,minp - last_participation,self.get_tour_length() - cost_last)
                input()
            # Either no advantageous transition or we have seen solution
            if Np in past_node_sets:
                rprime = minp
            else:
                rprime = min(minp, rprime + epsilon)
            
            last_participation = minp
            past_node_sets.add(Np)
            
        
                
            if len(Np) == len(N):
                rprime = np.inf # We have found the last possible one
            
        timer_end = timer()
        print('Solution Time', timer_end - timer_start)
        with open(os.path.join(self.instance.data_folder,"heuristic_value2_results.csv"), "w",newline = '') as f:
            writer = csv.writer(f)
            pairs = list(solutions.keys())
            writer.writerow(['Min Participation','Tour Cost','Number DBs','Fixed Cost','Tour'])
            for minp,cost in solutions:
                pareto = True
                for refminp,refcost in pairs:
                    if minp < refminp and cost > refcost:
                        pareto = False
                        break
                if pareto:
                    writer.writerow([minp,cost, len(solutions[minp,cost])-1, self.get_fixedcost(set(solutions[minp,cost])), "-".join(solutions[minp,cost])])
    
           
    def feasible(self,rprime):
        # Check if participation feasible
        if self.get_participation()< rprime  and abs(self.get_participation()-rprime) > 0.00001:
            print(f"Participation of {self.get_participation()} is not larger than {rprime}")
            return False
            
        # Check if double coverage feasbile
        nodes = set(self.optimal_tour)
        for k in self.instance.get_W():
            if len(nodes.intersection(self.instance.get_baseCoverage(k)))<2:
                print(f"Node {k} not double covered for rprime {rprime}")
                print(nodes)
                print(self.instance.get_baseCoverage(k))
                print(nodes.intersection(self.instance.get_baseCoverage(k)))
                return False
        
        return True
    
    def get_fixedcost(self,nodes):
        '''
        Given the tour nodes, calculated the fixed cost of the nodes
        '''
        c = 0
        for n in nodes:
            c += self.instance.get_fixedcost(n)
        return c
    
    def print_solution(self,rprime):
        if not self.feasible(rprime):
            raise Exception(f"Found solution that is not feasible")
        
        
        print(rprime,self.get_participation(), self.get_tour_length(),len(self.optimal_tour)-1,self.get_fixedcost(set(self.optimal_tour)),self.optimal_tour)


