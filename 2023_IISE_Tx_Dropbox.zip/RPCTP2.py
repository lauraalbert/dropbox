'''
This implements the robus participation covering tour problem 
formulation of the dropbox problem (exact solution method)

@author: Adam Schmidt, apschmidt2@wisc.edu
'''

import numpy as np
from timeit import default_timer as timer
from gurobipy import *
from collections import defaultdict
import csv
class RPCTP2:
    def __init__(self,instance):
        self.instance = instance # The data instance
        self.z1 = np.inf
        self.z2 = np.inf
        self.solution_time = np.inf
        self.optimal_tour = None
        self.model = None
        self.solutions = {}
        
    def build_model(self,rprime):
        '''
        This builds the optimization model to find a solution such that
        the worst case participation is no more than rprime
        '''
        self.rprime = rprime
        if self.instance is None:
            raise Exception('The RPCTP instance is not loaded')

        self.model = Model()
        
        ######## DECISION VARIABLES #############
        X = {}
        for i,j in self.instance.get_arcs():
            X[i,j] = X[j,i]= self.model.addVar(obj=self.instance.get_cost(i,j), vtype=GRB.BINARY, name='x')# Tour variables
        
#         X = self.model.addVars(self.instance.get_arcs(), name="x", vtype = GRB.BINARY) # Tour variables
        Y = self.model.addVars(self.instance.get_N(), name="y", vtype = GRB.BINARY) # Coverage Variables
        self.model._Xvars = X
        self.model._Yvars = Y
        
        ######## CONSTRAINTS #############
        # Must visit nodes in T
        for i in self.instance.get_T():
            self.model.addConstr(Y[i] == 1)
        
        # Flow in = Flow out
        for j in self.instance.get_N():
            # Note that instance.get_arcs(j) returns all edges (i,k) such that 
            # either i = j or k = j (this avoids double counting)
#             self.model.addConstr(quicksum(X[i,k] for i,k in self.instance.get_arcs(j)) == 2*Y[j])
            self.model.addConstr(quicksum(X[i,j] for i in self.instance.get_N() if i != j) == 2*Y[j])
        
        # Subtour elimination constraints
        # Added with lazy constraints
        
        for k in self.instance.get_W():
            # Base coverage constraint
            if len(self.instance.get_baseCoverage(k)) < 2:
                print('issue', k)
            self.model.addConstr(quicksum(Y[i] for i in self.instance.get_baseCoverage(k)) >= 2)
            
        # Robust constraint from epsilon constraint method
        # (objective two)
        for k in self.instance.get_Wpart():
            self.model.addConstr(self.instance.get_participationComponent(k,'vNone') <= 
                            self.rprime*(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    quicksum(self.instance.get_participationComponent(k,n)*Y[n] for n in self.instance.get_N())))
        
        
        ######## OBJECTIVE #############
        # TSP Tour length
        self.model.setObjective(quicksum(self.instance.get_cost(i,j)*X[i,j] for i,j in X))
        
        self.model.Params.OutputFlag = 0
        self.model.Params.lazyConstraints = 1
        self.model.Params.TimeLimit = 3600
        self.model.update()
    
    def solve_optimization(self,start,stop,increment): 
        '''
        This will solve the optimization problem for rprime
        '''
        self.rprime = start
        # Implement the callback routine here
        self.count = 0
        def mycallback(model, where):
            if where == GRB.callback.SIMPLEX:
                # maybe query something
                pass
            if where == GRB.callback.MIP:
                # maybe query something
                pass
            if where == GRB.callback.MIPNODE:
                # maybe add user cuts, or set a heuristic solution
                pass
            if where == GRB.callback.MIPSOL:
                print(self.count)
                self.count += 1
                # ADDING LAZY CUTS
                
                # We are finding subtours and removing all combinations of that subset
                # https://www.math.unipd.it/~luigi/courses/metmodoc1819/m08.01.TSPexact.en.pdf
                
                # make a list of edges selected in the solution
                vals = model.cbGetSolution(model._Xvars)
                selected = tuplelist((i, j) for i, j in model._Xvars.keys() # These are the arcs
                                        if vals[i, j] > 0.5)
                # find a cycle in the selected edge list
                tours = self.subtour(selected)
                
                l = 0
                finished = True
                added_constraints = 0
                for tour in tours:
                    # First we must check if the tour contains all nodes of T
                    if len(tour) > 1 and len(self.instance.get_T().difference(tour)) > 0:
                        VminusS = self.instance.get_N().difference(tour)
                        
                        # This is the first formulation for the constraints
                        expr = 0 # Adds the variables
                        solution_x = self.model.cbGetSolution(self.model._Xvars)
                        solution_y = self.model.cbGetSolution(self.model._Yvars)
                        lhs = 0
                        for vi in tour:
                            for vj in VminusS:
                                expr += model._Xvars[self.instance.get_edge(vi,vj)]
                                lhs += solution_x[self.instance.get_edge(vi,vj)]
                        for vt in tour:
                            model.cbLazy(expr >= 2*model._Yvars[vt]) # Adding the cut
                            added_constraints += 1
                            print(vt, lhs, 2*solution_y[vt])
                            if lhs < 2*solution_y[vt]+0.00001:
                                finished = False
                print("AC",added_constraints)
                print(finished)    
                print(self.model.status)        
                if False: #finished and len(tours) == 1:
                    '''
                    We have found the optimal tour, saving the solution
                    '''
                    tour = tours[0] + [tours[0][0]]
                    current_par = self.get_participation(tours[0])
                    print(self.rprime, current_par, self.tour_cost(tour), tour)
                    self.solutions[current_par, self.tour_cost(tour)] = tour
                    if abs(current_par-0.24133214771503095) < 0.0001:
    #                     self.print_solution(self.rprime,z[0])
                        if current_par - increment < stop:
                            pass
                        else:
                            # Adding lazy constraints
                            self.rprime = current_par- increment
                            for k in self.instance.get_Wpart():
                                # (objective two)
                                self.model.addConstr(self.instance.get_participationComponent(k,'vNone') <= 
                                                self.rprime*(self.instance.get_participationComponent(k,'vNone') + 
                                                        self.instance.get_participationComponent(k,'vOther')+
                                                        quicksum(self.instance.get_participationComponent(k,n)*self.model._Yvars[n] for n in self.instance.get_N())))
            
        self.model.update()
        start = timer()
        self.model.optimize(mycallback) # Solving the optimization model
        end = timer()
        self.solution_time = start - end
        self.optimal_tour,self.z1 = self.get_tour()
    
    def subtour(self,arcs):
        '''
        This function will find subtours within the given arcs. Will return the 
        nodes in the order in which they are visited within the subtour (ignoring 
        return to starting node).
        '''
        visited = {}
        visited_nodes = list(set([i for i,j in arcs]).union(set([j for i,j in arcs])))
        openset = set()
        for i in self.instance.get_N():
            visited[i]=False
            if i in visited_nodes: # Need this as we may not visit all
                openset.add(i)
        cycles = []
        lengths = []
        neighbors = defaultdict(lambda: [])
        for a,b in arcs:
            neighbors[a].append(b)
            neighbors[b].append(a)
        while True:
            current = openset.pop()
            # start BFS for a cycle at the node current
            thiscycle = [current]
            while True:
                visited[current] = True
                curneighbors = [a for a in neighbors[current] if not visited[a]]
                if len(curneighbors) == 0:
                    break
                current = curneighbors[0]
                openset.remove(current)
                thiscycle.append(current)
            cycles.append(thiscycle)
            lengths.append(len(thiscycle))
            if len(openset) < 1:
                break
        return cycles
           
    def get_tour(self):
        '''
        This will take a solved model and find the solution. Will check to 
        ensure that an optimal solution have been found. If not, returns best
        incumbent solution
        '''
        try:
            solution_x = self.model.getAttr('x', self.model._Xvars)
        except:
            self.optimal = False
            return [], np.inf
        
        selected = [(i,j) for (i,j) in self.model._Xvars if solution_x[i,j] > 0.5]      
        sol = self.subtour(selected)[0]
        sol+=[sol[0]]
        
        if self.model.status == GRB.OPTIMAL:
            self.optimal = True
            return sol, self.model.ObjVal/2
        
        self.optimal = False
        return sol, self.model.ObjVal/2
    
    
    def get_participation(self,selected,type = 'worstcase'):
        '''
        Calculates the estimated participation of each node W
        
        type:
           a) 'worstcase' find the worst case participation
           b) 'all' find the participation of each node W
        '''
        selected = set(selected) # Making sure no duplicates
        if type == 'worstcase':
            p = 0
            for k in self.instance.get_Wpart():
                phat = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
                if phat > p:
                    p= phat
        elif type == 'all':
            p = {}
            for k in self.instance.get_Wpart():
                p[k] = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
        return p
    
    def print_solution(self,rprime,tour):
        print(rprime,self.get_participation(tour[:-1]), self.model.ObjVal/2,tour,len(tour)-1)
        
        
    def solve(self,method = 'exact',pareto = 'complete', parteo_param = -1):
        '''
        [method] Expects one of the following methods:
        1) exact: use lazy constraint implementation of the 
                problem where lazy constraints are only for SEC
        2) exact_extralazy: like exact, but also use lazy constraints
                for the coverage constraints
        
        [pareto] Expects one of the following:
        1) complete: will attempt to approximate the complete pareto frontier
        2) one: will attempt to find a single solution to the problem
        
        [parteo_param] Expects depends on [pareto]
        1) if [pareto] == 'complete', then [parteo_param] represents the jump 
           size between solution for the worst case participation
        2) if [pareto] == 'one', then [pareto] represents the bound on the 
           worst case participation for the desired solution
           
        [parteo_param] can have size 1 or 2. If size 2, the first index indicates
         the starting value for the complete frontier 
        '''
        timer_start = timer()
        if pareto == 'complete':
            start = 1
            if len(parteo_param) > 1:
                start = parteo_param[0]
                parteo_param = parteo_param[1]
            rprime = start
            end = self.get_participation(self.instance.get_N())
        elif pareto == 'one':
            self.solve_optimization(parteo_param)
            z = self.get_tour()
            self.print_solution(rprime,z[0])
            start = pareto_param
            end = start
        else:
            raise Exception(f'Pareto parameter {pareto} unknown')
        
        self.build_model(start)
        print(parteo_param)
        self.solve_optimization(start, end, parteo_param)
        self.print_solution(rprime, self.optimal_tour)   
        timer_end = timer()
        print('Solution Time', timer_end - timer_start)
        print(self.solutions)
        with open(os.path.join(self.instance.data_folder,"exact2_results.csv"), "w",newline = '') as f:
            writer = csv.writer(f)
            pairs = list(self.solutions.keys())
            writer.writerow(['Max Non-Participation','Tour Cost','Number DBs','Fixed Cost','Tour'])
            for k,l in self.solutions:
                writer.writerow([k,l, len(self.solutions[k,l])-1, self.get_fixedcost(set(self.solutions[k,l])), "-".join(self.solutions[k,l])])
    
        return self.get_tour()
    
    def tour_cost(self,tour):
        if len(tour) == 0:
            return 0
        if len(tour) <= 2:
            return self.instance.get_fixedcost(tour[0])
        cost = 0
        for i in range(1,len(tour)):
            cost +=  self.instance.get_cost(tour[i-1],tour[i])
        
        return cost
    def get_fixedcost(self,nodes):
        '''
        Given the tour nodes, calculated the fixed cost of the nodes
        '''
        c = 0
        for n in nodes:
            c += self.instance.get_fixedcost(n)
        return c    