'''
This implements the robus participation covering tour problem 
formulation of the dropbox problem (exact solution method)

@author: Adam Schmidt, apschmidt2@wisc.edu
'''

import numpy as np
from timeit import default_timer as timer
from gurobipy import *
from collections import defaultdict
import csv
import itertools

class RPCTP:

    def __init__(self, instance):
        self.instance = instance  # The data instance
        self.z1 = np.inf
        self.z2 = np.inf
        self.solution_time = np.inf
        self.optimal_tour = None
        self.model = None
        self.optimal_cost = np.inf
        
    def build_model(self, rprime):
        '''
        This builds the optimization model to find a solution such that
        the worst case participation is no more than rprime
        '''
        if self.instance is None:
            raise Exception('The RPCTP instance is not loaded')

        self.model = Model()
        
        ######## DECISION VARIABLES #############
        X = {}
        for i, j in self.instance.get_arcs():
            X[i, j] = X[j, i] = self.model.addVar(vtype=GRB.BINARY, name='x')  # Tour variables
        
#         X = self.model.addVars(self.instance.get_arcs(), name="x", vtype = GRB.BINARY) # Tour variables
        Y = self.model.addVars(self.instance.get_N(), name="y", vtype=GRB.BINARY)  # Coverage Variables
        self.model._Xvars = X
        self.model._Yvars = Y
        
        ######## CONSTRAINTS #############
        # Must visit nodes in T
        for i in self.instance.get_T():
            self.model.addConstr(Y[i] == 1)
        
        # Flow in = Flow out
        for j in self.instance.get_N():
            # Note that instance.get_arcs(j) returns all edges (i,k) such that 
            # either i = j or k = j (this avoids double counting)
#             self.model.addConstr(quicksum(X[i,k] for i,k in self.instance.get_arcs(j)) == 2*Y[j])
            self.model.addConstr(quicksum(X[i, j] for i in self.instance.get_N() if i != j) == 2 * Y[j])
        
        # Subtour elimination constraints
        # Added with lazy constraints
        
        for k in self.instance.get_W():
            # Base coverage constraint
            if len(self.instance.get_baseCoverage(k)) < 2:
                print('issue', k)
            self.model.addConstr(quicksum(Y[i] for i in self.instance.get_baseCoverage(k)) >= 2)
            
        # Robust constraint from epsilon constraint method
        # (objective two)
        for k in self.instance.get_Wpart():
            self.model.addConstr(self.instance.get_participationComponent(k, 'vNone') <= 
                            rprime * (self.instance.get_participationComponent(k, 'vNone') + 
                                    self.instance.get_participationComponent(k, 'vOther') + 
                                    quicksum(self.instance.get_participationComponent(k, n) * Y[n] for n in self.instance.get_N())))
        
        ######## OBJECTIVE #############
        # TSP Tour length
        self.model.setObjective(quicksum(self.instance.get_cost(i, j) * X[i, j] for i, j in X))
        
        self.model.Params.OutputFlag = 0
        self.model.Params.lazyConstraints = 1
#         self.model.Params.PreCrush = 1
#         self.model.Params.TimeLimit = 3600
        self.model.update()
    
    def solve_optimization(self, rprime): 
        '''
        This will solve the optimization problem for rprime
        '''

        # Implement the callback routine here
        def mycallback(model, where):
            if where == GRB.callback.SIMPLEX:
                # maybe query something
                pass
                                
            if where == GRB.callback.MIP:
                # maybe query something
                pass
            if where == GRB.callback.MIPNODE:
                
#                 print('Starting here')
                pass
            
                # maybe add user cuts, or set a heuristic solution
                # Adding cuts for 8, 9', and 9'' from 'The Covering Tour Problem'
                # by Gendreau et al.
                if False: #self.model._cbCuts < 10000: # Not running
                    x_vals = model.cbGetNodeRel(model._Xvars)
                    y_vals = model.cbGetNodeRel(model._Yvars)
                    
                    cons_added = 0
                    
                    # (8)
                    for i, j in self.instance.get_arcs():
                        if i not in self.instance.get_T() and j not in self.instance.get_T():
                            if x_vals[i, j] > y_vals[i]:
                                model.cbCut(model._Xvars[i, j] <= model._Yvars[i])
                                cons_added += 1
    #                             print(cons_added, "A", i, j, i )
                            elif x_vals[i, j] > y_vals[j]:
                                model.cbCut(model._Xvars[i, j] <= model._Yvars[j])
                                cons_added += 1
    #                             print(cons_added, "B",i, j, j )
                            if cons_added > 29:
                                break
                    # (9')
                    # NOT VALID INEQUALITIES
                    
                    # (9'')
                    # NOT VALID INEQUALITIES
                    
                    # (10)
    #                 Finding the nodes w \in W not covered at least once
                    if False: #cons_added <= 30:
                        
                        # Finding the w's not covered twice
#                         ws = []
#                         for w in self.instance.get_W():
#                             if sum([y_vals[n] for n in self.instance.get_baseCoverage(w)]) < 1:
#                                 ws.append(w)
                        for i,j,k in itertools.combinations(self.instance.get_W(), 3):    #itertools.combinations(ws, 3):    
                            add = True
                            nodes = set([i,j,k])
                            expr = 0
                            s = 0
                            count = 0
                            for n in self.instance.get_N():
                                a = nodes.intersection(self.instance.get_baseCoverage(n))
                                if len(a) == 3:
                                    expr += 2 * model._Yvars[n]
                                    if y_vals[n] >= 1:
                                        add = False
                                        break
                                elif len(a) > 0:
                                    expr += model._Yvars[n]
                                    if y_vals[n] >= 1:
                                        add = False
                                        break
                            if add: #s <= count:
                                model.cbCut(expr >= 2)
                                cons_added += 1
#                                             print(cons_added, "C", i,j,k, cons_added > 29)
                                if cons_added > 29:
                                    break
#                 print('Ending here')
            if where == GRB.callback.MIPSOL:
                self.model._cbCuts = 0
                # ADDING LAZY CUTS
                
                # We are finding subtours and removing all combinations of that subset
                # https://www.math.unipd.it/~luigi/courses/metmodoc1819/m08.01.TSPexact.en.pdf
                
                # make a list of edges selected in the solution
                vals = model.cbGetSolution(model._Xvars)
                selected = tuplelist((i, j) for i, j in model._Xvars.keys()  # These are the arcs
                                        if vals[i, j] > 0.5)
                # find a cycle in the selected edge list
                tours = self.subtour(selected)
                l = 0
                for tour in tours:
                    # First we must check if the tour contains all nodes of T
                    if len(tour) > 1 and len(self.instance.get_T().difference(tour)) > 0:
                        VminusS = self.instance.get_N().difference(tour)
                        
                        # This is the first formulation for the constraints
                        expr = 0  # Adds the variables
                        for vi in tour:
                            for vj in VminusS:
                                expr += model._Xvars[self.instance.get_edge(vi, vj)]
                                
                        for vt in tour:
                            model.cbLazy(expr >= 2 * model._Yvars[vt])  # Adding the cut
                            break
        
        ######## SOLUTIUON #############
        # Robust constraint from epsilon constraint method
        r = {}
        for k in self.instance.get_Wpart():
            # (objective two)
            r[k] = self.model.addConstr(self.instance.get_participationComponent(k, 'vNone') <= 
                            rprime * (self.instance.get_participationComponent(k, 'vNone') + 
                                    self.instance.get_participationComponent(k, 'vOther') + 
                                    quicksum(self.instance.get_participationComponent(k, n) * self.model._Yvars[n] for n in self.instance.get_N())))
        
        self.model._cbCuts = 0
        self.model.update()
        self.model.optimize(mycallback)  # Solving the optimization model
        end = timer()
        self.optimal_tour, self.z1 = self.get_tour()
        return r
    
    def remove_constraints(self, constraints):
        for c in constraints:
            self.model.remove(constraints[c])
        self.model.update()
    
    def subtour(self, arcs):
        '''
        This function will find subtours within the given arcs. Will return the 
        nodes in the order in which they are visited within the subtour (ignoring 
        return to starting node).
        '''
        visited = {}
        visited_nodes = list(set([i for i, j in arcs]).union(set([j for i, j in arcs])))
        openset = set()
        for i in self.instance.get_N():
            visited[i] = False
            if i in visited_nodes:  # Need this as we may not visit all
                openset.add(i)
        cycles = []
        lengths = []
        neighbors = defaultdict(lambda: [])
        for a, b in arcs:
            neighbors[a].append(b)
            neighbors[b].append(a)
        while True:
            current = openset.pop()
            # start BFS for a cycle at the node current
            thiscycle = [current]
            while True:
                visited[current] = True
                curneighbors = [a for a in neighbors[current] if not visited[a]]
                if len(curneighbors) == 0:
                    break
                current = curneighbors[0]
                openset.remove(current)
                thiscycle.append(current)
            cycles.append(thiscycle)
            lengths.append(len(thiscycle))
            if len(openset) < 1:
                break
        return cycles
           
    def get_tour(self):
        '''
        This will take a solved model and find the solution. Will check to 
        ensure that an optimal solution have been found. If not, returns best
        incumbent solution
        '''
        try:
            solution_x = self.model.getAttr('x', self.model._Xvars)
        except:
            self.optimal = False
            return [], np.inf
        
        selected = [(i, j) for (i, j) in self.model._Xvars if solution_x[i, j] > 0.5]      
        
        sol = self.subtour(selected)[0]
        sol += [sol[0]]
        self.optimal_cost = self.tour_cost(sol)
        if self.model.status == GRB.OPTIMAL:
            self.optimal = True
            return sol, self.optimal_cost
        print('Optimal solution not found', self.model.status)
        self.optimal = False
    
        return sol, self.optimal_cost
    
    def get_participation(self, selected, type='worstcase'):
        '''
        Calculates the estimated participation of each node W
        
        type:
           a) 'worstcase' find the worst case participation
           b) 'all' find the participation of each node W
        '''
        selected = set(selected)  # Making sure no duplicates
        if type == 'worstcase':
            p = 0
            for k in self.instance.get_Wpart():
                phat = self.instance.get_participationComponent(k, 'vNone') / (self.instance.get_participationComponent(k, 'vNone') + 
                                    self.instance.get_participationComponent(k, 'vOther') + 
                                    sum(self.instance.get_participationComponent(k, n) for n in selected))
                if phat > p:
                    p = phat
        elif type == 'all':
            p = {}
            for k in self.instance.get_Wpart():
                p[k] = self.instance.get_participationComponent(k, 'vNone') / (self.instance.get_participationComponent(k, 'vNone') + 
                                    self.instance.get_participationComponent(k, 'vOther') + 
                                    sum(self.instance.get_participationComponent(k, n) for n in selected))
        return p
    
    def print_solution(self, rprime, tour):
        print(rprime, self.get_participation(tour[:-1]), self.optimal_cost, tour, len(tour) - 1)
        
    def solve(self, method='exact', pareto='complete', parteo_param=-1):
        '''
        [method] Expects one of the following methods:
        1) exact: use lazy constraint implementation of the 
                problem where lazy constraints are only for SEC
        2) exact_extralazy: like exact, but also use lazy constraints
                for the coverage constraints
        
        [pareto] Expects one of the following:
        1) complete: will attempt to approximate the complete pareto frontier
        2) one: will attempt to find a single solution to the problem
        
        [parteo_param] Expects depends on [pareto]
        1) if [pareto] == 'complete', then [parteo_param] represents the jump 
           size between solution for the worst case participation
        2) if [pareto] == 'one', then [pareto] represents the bound on the 
           worst case participation for the desired solution
           
        [parteo_param] can have size 1 or 2. If size 2, the first index indicates
         the starting value for the complete frontier 
        '''
        solutions = {}
        timer_start = timer()
        if method == 'exact':
            if pareto == 'complete':
                start = 1
                if len(parteo_param) > 1:
                    start = parteo_param[0]
                    parteo_param = parteo_param[1]
                rprime = start
                self.build_model(rprime)
                last_cost = 0
                while rprime > 0:
                    s = timer()
                    constraints = self.solve_optimization(rprime)
                    z = self.get_tour()
                    if self.optimal:
                        self.print_solution(rprime, z[0])
                        rprime = self.get_participation(z[0][:-1]) - parteo_param
                        solutions[self.get_participation(z[0][:-1]), z[1]] = z[0]
                        self.remove_constraints(constraints)
                        
                    else:
                        rprime = -1
                # Solving the final 
            
            elif pareto == 'one':
                self.solve_optimization(parteo_param)
                z = self.get_tour()
                self.print_solution(rprime, z[0])
            
            else:
                raise Exception(f'Pareto parameter {pareto} unknown')
        timer_end = timer()
        print('Solution Time', timer_end - timer_start)
        with open(os.path.join(self.instance.data_folder, "exact_results.csv"), "w", newline='') as f:
            writer = csv.writer(f)
            pairs = list(solutions.keys())
            writer.writerow(['Max Non-Participation', 'Tour Cost', 'Number DBs', 'Fixed Cost', 'Tour'])
            for k, l in solutions:
                writer.writerow([k, l, len(solutions[k, l]) - 1, self.get_fixedcost(set(solutions[k, l])), "-".join(solutions[k, l])])
    
        return self.get_tour()
    
    def tour_cost(self, tour):
        if len(tour) == 0:
            return 0
        if len(tour) <= 2:
            return self.instance.get_fixedcost(tour[0])
        cost = 0
        for i in range(1, len(tour)):
            cost += self.instance.get_cost(tour[i - 1], tour[i])
        
        return cost
    
    def get_fixedcost(self, nodes):
        '''
        Given the tour nodes, calculated the fixed cost of the nodes
        '''
        c = 0
        for n in nodes:
            c += self.instance.get_fixedcost(n)
        return c    
