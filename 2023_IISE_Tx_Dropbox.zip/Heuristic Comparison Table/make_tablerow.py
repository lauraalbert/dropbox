'''
In this file we do the following:

1) Read in the appropriate instance
2) Run the heuristic
3) For each heuritistc policy, run the optimal for same r
4) Store the results and runtime
'''
from read_data import DropboxInstance
import pandas as pd
import csv,os
from RPCTP import RPCTP
from RPCTP_heuristic_value import RPCTP_heuristic_value
import numpy as np
import datetime

print('Be sure to update the RPCTP, RPCTP_heuristic_value, read_data import DropboxInstance, Classes, and CTPish  if it has changed')


for N in [100]: # Different sizes for N
    for W in [1000,500] : #[100,500,1000,2000]: # Different sizes for W
        ###
        # 1) Read in appropriate instance
        ###
        # file_path = f'Data/Test1'
        file_path = f'Data/Random{W}-{N}'
        x = DropboxInstance(file_path)
        
        ###
        # 2) Run the heuristic
        ###
        y = RPCTP_heuristic_value(x,outputflag = False) 
        hueristic_soln_time = y.solve(pareto = 'complete', parteo_param =  0.001)
        
        ###
        # 3) For each heuristic policy, run the optimal for same r
        ###
        df = pd.read_csv(os.path.join(file_path,'heuristic_value_results.csv')).sort_values('Max Non-Participation')
        df = df.drop_duplicates('Max Non-Participation')
        r_dict = dict(zip(df['Max Non-Participation'], df['Tour Cost']))
        
        exact_soln_time = 0
        solns = {}
        ratios = []
        costs = set()
        last_cost = 0
        last_soln = None
        found_r = 0
        exact_times = {}
        last_time = -1
        for r in r_dict:
            if r <= found_r: # This solution is dominated by the previous optimal solution
                ratios.append(r_dict[r]/last_cost)
                solns[r] = last_soln
                exact_times[r] = last_time
            else:
                y = RPCTP(x,outputflag = False) 
                st, soln,found_r = y.solve(pareto = 'one', parteo_param = 1-r)
                solns[r] = soln
                if soln[1] not in costs: # Dont what to count finding the same solution twice
                    exact_soln_time += st
                exact_times[r] = st
                ratios.append(r_dict[r]/soln[1])
                last_cost = soln[1]
                last_soln = soln
                last_time = st
            
            print(r,soln[1],found_r, st)
        
        
        ###
        # 4) Saving the results
        
        with open('Data/results.csv','a') as fd:
            results = [file_path, len(solns), hueristic_soln_time, exact_soln_time, np.average(ratios),datetime.datetime.now()]
            fd.write(','.join([str(i) for i in results])+'\n')
        
        
        df['exact cost']  = df['Max Non-Participation'].apply(lambda x: solns[x][1])  
        df['exact tour']  = df['Max Non-Participation'].apply(lambda x: solns[x][0])  
        df['cost ratio']  = df['Max Non-Participation'].apply(lambda x: r_dict[x] / solns[x][1])  
        df['exact time']  = df['Max Non-Participation'].apply(lambda x: exact_times[x])  
        df.to_csv(os.path.join(file_path,'heuristic_value_results.csv'))
         
        ###
        # Printing the results
        ###
        print(solns)
        print('Heuristic Soln Time',hueristic_soln_time)
        print('Exact Soln Time',exact_soln_time)
        print('Average Gap',np.average(ratios))
            
            
            
            
