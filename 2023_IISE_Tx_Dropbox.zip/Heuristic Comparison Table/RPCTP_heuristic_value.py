'''
This implements the robust participation covering tour problem 
formulation of the dropbox problem (heuristic formulation)

This differs from Heuristic 1 in the following ways:
1) Instead of adding least cost sway, we add the one with the least cost/value

@author: Adam Schmidt, apschmidt2@wisc.edu
'''
from itertools import combinations
import numpy as np
from timeit import default_timer as timer
from gurobipy import *
from collections import defaultdict
import heapq
from CTPish import SchmidtAlgorithm1 as SchmidtAlgorithm4
import csv

class RPCTP_heuristic_value:
    def __init__(self,instance,outputflag = True):
        self.instance = instance
        self.folder = self.instance.data_folder
        self.solution_time = np.inf
        self.optimal_tour = None
        self.outputflag = outputflag


    def solveCTPish(self): 
        '''
        This will solve the CTPish subproblem. We must find a tour on a 
        subset of nodes (that includes T) such that each W is covered *twice*.
        
        Our approach: 
        1) Find a Steiner tree on auxiliary graph
        2) Add nodes of V spanned by the ST to the set T
        2) For each node of W that is covered twice by nodes of N spanned by
           the tree, remove it from the Steiner Tree
        3) Remove edges between the nodes of V spanned by the ST and the remaining
           nodes of W
        4) Resolve the Steiner tree problem
        5) Remove Redundant nodes
        6) Find TSP on these nodes
        
        This is implemented in a different class
        ''' 
        
        a = SchmidtAlgorithm4()
        a.load(self.folder)
#         test = np.zeros(len(self.instance.get_N()), dtype=int)
#         test[1] = 1
#         n = list(self.instance.get_N())
#         self.optimal_tour = n + [n[0]]
#         n = list(self.instance.get_T())
#         a = n[0]
        self.optimal_tour = a.solve()
#         return test
    
    def get_tour_length(self):
        '''
        Expects an ordered list where the final element is the first element
        '''
        tour = self.optimal_tour
        if len(tour) == 0:
            return 0
        if len(tour) <= 2:
            return self.instance.get_fixedcost(tour[0])
        cost = 0
        for i in range(1,len(tour)):
            cost +=  self.instance.get_cost(tour[i-1],tour[i])
        
        return cost
        
    def get_participation(self,type = 'worstcase'):
        '''
        Calculates the estimated participation of each node W
        
        type:
           a) 'worstcase' find the worst case participation
           b) 'all' find the participation of each node W
        '''
        selected = set(self.optimal_tour) # Making sure no duplicates
        if type == 'worstcase':
            p = 1
            for k in self.instance.get_Wpart():
                phat = 1-self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
                if phat < p:
                    p= phat
        elif type == 'all':
            p = {}
            for k in self.instance.get_Wpart():
                p[k] = 1-self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
        return p
        
        
    
    def estimateInsertionCost(self,tour,node):
        '''
        This method looks at the tour passed as an argument and finds the 
        cheapest insertion to the tour
        '''
        if node is None:
            return 0
        if len(tour) == 0:
            return self.instance.get_fixedcost(node)
        cost_increase = np.inf
        for i in range(1,len(tour)):
            added_cost = self.instance.get_cost(tour[i-1],node)+self.instance.get_cost(tour[i],node)-self.instance.get_cost(tour[i-1],tour[i])
            if added_cost < cost_increase:
                cost_increase = added_cost
        return cost_increase
    
    def removeFromTour(self,tour,node):
        '''
        This method will remove a node from [tour] and return the new tour
        and the reduced cost be removing the node
        '''
        if node is None:
            return tour[:],0
        if len(tour) == 2:
            if tour[0] == node:
                return [],0
            else:
                f = f'Node {node} not in tour {tour}'
                raise Exception(f)
        
        tour = tour[:]
        if tour[0] == node:
            tour = tour[1:-1]
            tour.append(tour[0])
#             print(tour)
            return tour, self.instance.get_cost(tour[1],node)+self.instance.get_cost(tour[-2],node)
        i = tour.index(node)
        rc = self.instance.get_cost(tour[i-1],tour[i+1]) - self.instance.get_cost(tour[i-1],node)-self.instance.get_cost(tour[i+1],node)
        tour.remove(node)
        return tour, rc
    
    def swapNodes(self,tour,n1,n2):
        '''
        Removes n1 from the tour and adds n2.
        '''
        if n1 not in tour and (n1 is not None):
            s = f"Node {n1} not in tour {tour}"
            raise Exception(s)
        if n2 in tour:
            s = f'Node {n2} already in tour {tour}'
            raise Exception(s)
        tour_nodes = set(tour)
        if n2 is not None:
            tour_nodes = tour_nodes.union([n2])
        tour_nodes =tour_nodes.difference([n1])
        best_tour = self.get_optimal_tour(tour_nodes)
        
        return best_tour
    
    def get_optimal_tour(self,nodes):
#           https://www.gurobi.com/documentation/9.1/examples/tsp_py.html
        if len(nodes) == 1:
            n = nodes.pop()
            return [n,n]
        if len(nodes) == 2:
            tmp = list(nodes)
            t = tmp + [tmp[0]]
            return t
        
        # Callback - use lazy constraints to eliminate sub-tours
        def subtourelim(model, where):
            if where == GRB.Callback.MIPSOL:
                # make a list of edges selected in the solution
                vals = model.cbGetSolution(model._vars)
                selected = tuplelist((i, j) for i, j in model._vars.keys()
                                        if vals[i, j] > 0.5)
                # find the shortest cycle in the selected edge list
                tours = subtour(selected)
                for tour in tours:
                    if len(tour) < len(nodes):
                        # add subtour elimination constr. for every pair of cities in tour
                        model.cbLazy(quicksum(model._vars[i, j]
                                                 for i, j in combinations(tour, 2))
                                     <= len(tour)-1)
        
        
        # Given a tuplelist of edges, find the shortest subtour
        def subtour(edges):
            cycles = []
            unvisited = set(nodes)
            while unvisited:  # true if list is non-empty
                thiscycle = []
                neighbors = list(unvisited)
                while neighbors:
                    current = neighbors[0]
                    thiscycle.append(current)
                    unvisited.remove(current)
                    neighbors = [j for i,j in edges if i == current and j in unvisited]
                cycles.append(thiscycle)
            return cycles

        m = Model()
        m.Params.OutputFlag = 0
        # Create variables
        vars = {}
        for i in nodes:
            for j in nodes:
                if j in nodes and i < j:
                    vars[i,j] = vars[j,i]= m.addVar(obj=self.instance.get_cost(i,j)-self.instance.get_fixedcost(i)/2-self.instance.get_fixedcost(j)/2, vtype=GRB.BINARY, name='x')
        
        # Add degree-2 constraint
        for i in nodes:
            m.addConstr(sum(vars[i,j] for j in nodes if i != j) == 2)

        # Solving 
        m._vars = vars
        m.Params.lazyConstraints = 1
        m.update()
        m.optimize(subtourelim) #
        vals = m.getAttr('x', vars)
        selected = tuplelist((i, j) for i, j in m._vars if vals[i, j] > 0.5)
        tour = subtour(selected)[0]
        tour += [tour[0]]
#         print()
#         print('Solution found',tour)
        if len(tour) != len(nodes)+1:
            print(nodes)
            print(tour)
            print(subtour(selected))
            print(selected)
            raise Exception(f'Error finding tour, nodes {set(nodes).difference(tour)} not included')
        
        return tour
#     def reorderTour(self,tour):
#         '''
#         This reorders the tour to hopefully improve tour cost
#         '''
#         for i in tour:
#             for j in tour:
    
    def computeDeltaI(self,n1,n2,wcov_index,wcov):
        '''
        This takes in n1 and n2 and computes the change in the coverage that
        occurs.
        
        wcov are the nodes to cover
        wcov_index tells us the index to place the value in the vector
        '''
        deltaI = np.zeros(len(wcov))
        n1cov = set()
        if n1 is not None:
            n1cov = set(self.instance.get_baseCoverage(n1))
        n2cov = set()
        if n2 is not None:
            n2cov = set(self.instance.get_baseCoverage(n2))
        n1diffn2 = n1cov.difference(n2cov)
        n2diffn1 = n2cov.difference(n1cov)
        for k in wcov:
            if k in n1diffn2:
                deltaI[wcov_index[k]] = -1
            elif k in n2diffn1:
                deltaI[wcov_index[k]] = 1
        return deltaI
    
    
    def compute_swap_value(self,delta_r,delta_c):
        '''
        Computes the 'value' of a feasible swap
        
        Based on 
        
        @article{current_median_1994,
            title = {The median tour and maximal covering tour problems: {Formulations} and heuristics},
            volume = {73},
            issn = {0377-2217},
            shorttitle = {The median tour and maximal covering tour problems},
            url = {http://www.sciencedirect.com/science/article/pii/037722179490149X},
            doi = {10.1016/0377-2217(94)90149-X},
            abstract = {In this paper, the authors introduce two bicriterion routing problems: the median tour problem (MTP) and the maximal covering tour problem (MCTP). In …},
            language = {en},
            number = {1},
            urldate = {2021-03-15},
            journal = {European Journal of Operational Research},
            author = {Current, John R. and Schilling, David A.},
            month = feb,
            year = {1994},
            note = {Publisher: North-Holland},
            pages = {114--126},
            file = {Snapshot:C\:\\Users\\apschmidt\\Zotero\\storage\\VM354SDZ\\037722179490149X.html:text/html},
        }

        '''
        
        # In fourth quadrant, not of interest to us
        if delta_c >= 0 and delta_r < 0:
            return np.inf
        
        # Angle from <-1,0>
        if delta_c <= 0:
            return np.arccos(-delta_r/np.sqrt((delta_c**2+delta_r**2)))
        else:
            return 2*np.pi-np.arccos(-delta_r/np.sqrt((delta_c**2+delta_r**2)))
        
        # Angle from <1,-1>
        return np.arccos((delta_r - delta_c)/np.sqrt((delta_c**2+delta_r**2)*2))
        
        # Angle from <0.-1}
        return np.arccos(-1*delta_c/np.sqrt((delta_c**2+delta_r**2)))
        
#         # Cost must be negative
#         theta = 0
#         
#         if delta_r == 0:
#             if delta_c > 0:
#                 theta = 3*np.pi/2
#             theta = np.pi/2
#     
#         elif delta_r <= 0:
#             # First quadrant
#             if delta_c < 0:
#                 theta = np.arctan(delta_c/delta_r)
#             # Second quadrant
#             else:
#                 theta = np.pi + np.arctan(delta_c/delta_r)
#         else:
#             # Third quadrant
#             theta = np.pi + np.arctan(delta_c/delta_r)
#         
# #         if np.pi - theta < 0:
# #             return theta
# #         return np.pi - theta
# #
#         return -1*(np.pi/2-theta)
#         print('ISSUE: got to end and didnt compute value')
               
    def updated_participation(self,V0,Vn,denom_last,n_index, n1,n2):
        '''
        Determines the updated participation resulting from removing n1
        and adding n2
        '''
        if n1 is None:
            if n2 is None:
                print('Issue: both are none')
            else:
                tmp_denom_new = denom_last + Vn[:,n_index[n2]]
        else:
            if n2 is None:
                ## n2 None
                tmp_denom_new = denom_last - Vn[:,n_index[n1]]
            else:
                ## Neither None
                tmp_denom_new = denom_last + Vn[:,n_index[n2]] - Vn[:,n_index[n1]]
        
        tmp_new_P = np.divide(tmp_denom_new-V0,tmp_denom_new)
        min_pointer = np.argmin(tmp_new_P)
        tmp_new_rprime = tmp_new_P[min_pointer][0,0]
        return tmp_new_rprime, tmp_denom_new, min_pointer
                                   
    def check_participation_w(self,w_index,V0,Vn,denom_last,n_index, n1,n2):
        '''
        This will check to see if the swap is feasible for the index that 
        had lowest participation in last iterations.
        
        Used to speed up procedure
        '''
        if n1 is None:
            if n2 is None:
                print('Issue: both are none')
            else:
                tmp_denom_new = denom_last[w_index] + Vn[w_index,n_index[n2]]
        else:
            if n2 is None:
                ## n2 None
                tmp_denom_new = denom_last[w_index] - Vn[w_index,n_index[n1]]
            else:
                ## Neither None
                tmp_denom_new = denom_last[w_index] + Vn[w_index,n_index[n2]] - Vn[w_index,n_index[n1]]

        return (tmp_denom_new-V0[w_index])/tmp_denom_new
    
    def solve(self,pareto = 'complete', parteo_param = -1):
        '''
        [pareto] Expects one of the following:
        1) complete: will attempt to approximate the complete pareto frontier
        2) one: will attempt to find a single solution to the problem
        
        [parteo_param] Expects depends on [pareto]
        1) if [pareto] == 'complete', then [parteo_param] represents the jump 
           size between solution for the worst case participation
        2) if [pareto] == 'one', then [pareto] represents the bound on the 
           worst case participation for the desired solution
        '''
        timer_start = timer()
        solutions = {}
        
        stop = 1
        start = 0
        epsilon = parteo_param
            
        if pareto == 'one':
            stop = parteo_param
            epsilon = 0.01
        
        #####
        # We use vector/matrix representation to do the computation
        #####
        # Storing the row of each w and n
        wpart = self.instance.get_Wpart()
        wcov = self.instance.get_W()
        n = list(self.instance.get_N())
        wpart_index = {}
        for i in range(len(wpart)):
            wpart_index[wpart[i]] = i
            
        wcov_index = {}
        for i in range(len(wcov)):
            wcov_index[wcov[i]] = i
        
        n_index = {}
        for i in range(len(n)):
            n_index[n[i]] = i
            
        # Getting the participation matrices
        V0 = np.array([self.instance.get_participationComponent(k,'vNone') for k in wpart])
        V0.shape = (len(wpart),1)
        V1 = np.array([self.instance.get_participationComponent(k,'vOther') for k in wpart])
        V1.shape = (len(wpart),1)
        Vn = np.matrix([[self.instance.get_participationComponent(k,j) for j in n] for k in wpart])
        
        #########
        # Finding the first tour ('shortest')
        #########
        self.solveCTPish()
        
        selected = np.zeros(len(n))
        for j in self.optimal_tour:
            selected[n_index[j]] = 1
        selected.shape = (len(selected),1)
        
        # This represents the initial participation rate among W
        denom_last = V0 + V1 + np.dot(Vn,selected)
        P = 1-np.divide(V0,denom_last)
        
        
        # Now storing the initial coverage
        I = np.zeros(len(wcov),dtype = int)
        for k in wcov:
            I[wcov_index[k]] = len(set(self.instance.get_baseCoverage(k)).intersection(self.optimal_tour))
        
        minp_pointer = np.argmin(P) # This stores the index of minimum in last solution...
                                    # Speeds up computation
        rprime = P[minp_pointer][0,0]
        part_last = rprime
        solutions[self.get_participation(), self.get_tour_length()] = self.optimal_tour
        if self.outputflag:
            self.print_solution(rprime)
        
        # This is the best possible participation we can achieve
        # Well, actually it isn't as there may be coverage limitations
#         stop = min(1-np.divide(V0,V0+V1+np.dot(Vn,np.ones((len(n),1)))))[0,0]
        
        # This finds the multiple soltions
        seen = set() # Stores the tours we have seen to avoid cycling
        count_iter = 0 
        rprime = 0
        stop = 1
        
        while rprime < stop:
#             print(rprime)
            count_iter +=1 
            # Initializing key parameters 
            current_nodes = set(self.optimal_tour)
            min_value = np.inf
            
            pq = []
            N1 = [None] + list(current_nodes.difference(self.instance.get_T()))
            
            N2 = [None]+list(self.instance.get_N().difference(current_nodes))
            times_ran = 0
            negative_cost_found = False
            reduced_costs = {} # Stores them for each removed node so we dont have
                               # To redo operation
            reduced_costs[None] = self.removeFromTour(self.optimal_tour,None)
            
            count = 0
            for n2 in N2:
                count += 1
                if count == 1:
                    N1p = N1[1:]
                else:
                    N1p = N1
                for n1 in N1p:
                    if count == 1:
                       reduced_costs[n1] =  self.removeFromTour(self.optimal_tour,n1)
                    
                    new_tour, reducedcost = reduced_costs[n1]
                
                    delta_c = self.estimateInsertionCost(new_tour,n2)+reducedcost
                    
                    check = True
                    if negative_cost_found and  delta_c >= 0: # Don't need to consider positive cost
                        check = False
                        
                    if check:
                        # Checking coverage satisfaction
                        delta_n1 = set([k for k in self.instance.get_baseCoverage(n1) if abs(I[wcov_index[k]]-2)<0.5])
                        if delta_n1 <= self.instance.get_baseCoverage(n2):
                        
                            # Estimating the participation change
                            new_minpart, new_denom,min_pointer = self.updated_participation(V0,Vn,denom_last,n_index, n1,n2)
                            
                            # We first check to make sure that the worst w
                            # from last iteration at least meets the bound
                            # If not, then no need to check all others
                            if self.check_participation_w(minp_pointer,V0,Vn,denom_last,n_index, n1,n2) >= rprime:
                            
                                # This checks to make sure we meet the participation bound
                                # For all w
                                if new_minpart > rprime:
                                    delta_c = self.estimateInsertionCost(new_tour,n2)+reducedcost
                                    delta_r = new_minpart - part_last
                                    
                                    value = self.compute_swap_value(delta_r,delta_c)
                                    heapq.heappush(pq,(value,delta_c,delta_r,n1,n2,new_minpart, new_denom,min_pointer))
                                    if delta_c < 0:
                                        negative_cost_found = True
                
            
#             while pq:
#                 value,delta_c,delta_r,n1,n2,new_minpart, new_denom = heapq.heappop(pq) 
#                 # 1) Check coverage feasibility
#                 if n1 is None: # can skip since previous solution was feasible
#                     break
#                 else:
#                     delta_n1 = set([k for k in self.instance.get_baseCoverage(n1) if abs(I[wcov_index[k]]-2)<0.5])
#                  
#                     if delta_n1 <= self.instance.get_baseCoverage(n2):
#                         break # We have found a feasible solution of minimum value
                     
            #####
            # We now update all of our parameters
            #####
#             print("Best",value,n1,n2,delta_c,delta_r,new_minpart)
            if len(pq) < 1:
                print('ISSUE priority queue has length zero')
            value,delta_c,delta_r,n1,n2,new_minpart, new_denom,minp_pointer = heapq.heappop(pq)     
            self.optimal_tour = self.swapNodes(self.optimal_tour.copy(),n1,n2)
            
#             print(new_minpart, self.get_participation())
            
            if self.outputflag:
                self.print_solution(rprime)
            
            rprime_last = rprime
            part_last = new_minpart
            denom_last = new_denom
            I = I +  self.computeDeltaI(n1,n2,wcov_index,wcov)
            
            solutions[self.get_participation(), self.get_tour_length()] = self.optimal_tour
            a = frozenset(self.optimal_tour)
            
            if a in seen: # We skip the cycle
                rprime = new_minpart
            else:    
                seen.add(a)
                rprime = min(new_minpart,rprime + epsilon)
            
            
            if len(a) == len(self.instance.get_N()):
                break
            
                
        timer_end = timer()
        print('Solution Time', timer_end - timer_start)
        with open(os.path.join(self.instance.data_folder,"heuristic_value_results.csv"), "w",newline = '') as f:
            writer = csv.writer(f)
            pairs = list(solutions.keys())
            writer.writerow(['Max Non-Participation','Tour Cost','Number DBs','Fixed Cost','Tour'])
            for k,l in solutions:
                pareto = True
                for i,j in pairs:
                    if i == k and l == j:
                        pass
                    elif k <= i and l >= j:
    #                     print('NOT PARETO',(k,l),(i,j))
                        pareto = False
                        break
                if pareto:
                    writer.writerow([k,l, len(solutions[k,l])-1, self.get_fixedcost(set(solutions[k,l])), "-".join(solutions[k,l])])
        return timer_end - timer_start
        
    def feasible(self,rprime):
        # Check if participation feasible
        if self.get_participation()< rprime  and abs(self.get_participation()-rprime) > 0.00001:
            print(f"Participation of {self.get_participation()} is not larger than {rprime}")
            return False
            
        # Check if double coverage feasbile
        nodes = set(self.optimal_tour)
        for k in self.instance.get_W():
            if len(nodes.intersection(self.instance.get_baseCoverage(k)))<2:
                print(f"Node {k} not double covered for rprime {rprime}")
                print(nodes)
                print(self.instance.get_baseCoverage(k))
                print(nodes.intersection(self.instance.get_baseCoverage(k)))
                return False
        
        return True
    
    def get_fixedcost(self,nodes):
        '''
        Given the tour nodes, calculated the fixed cost of the nodes
        '''
        c = 0
        for n in nodes:
            c += self.instance.get_fixedcost(n)
        return c
    
    def print_solution(self,rprime):
        if not self.feasible(rprime):
            raise Exception(f"Found solution that is not feasible")
        
        
        print(rprime,self.get_participation(), self.get_tour_length(),len(self.optimal_tour)-1,self.get_fixedcost(set(self.optimal_tour)),self.optimal_tour)


