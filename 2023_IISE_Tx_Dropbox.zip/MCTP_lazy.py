'''
Created on Mar 19, 2021

@author: apschmidt
'''
from timeit import default_timer as timer
from gurobipy import *
import gurobipy as gp
from gurobipy import GRB
from itertools import combinations
from read_data import *
from collections import defaultdict
####
##### Decision info
n =5 # number of new drop boxes to locate
e = 50 # number of uncovered population
####


# Implement the callback routine here
def mycallback(model, where):
    if where == GRB.callback.SIMPLEX:
        # maybe query something
        pass
    if where == GRB.callback.MIP:
        # maybe query something
        pass
    if where == GRB.callback.MIPNODE:
        # maybe add user cuts, or set a heuristic solution
        pass
    if where == GRB.callback.MIPSOL:
        # ADDING LAZY CUTS
        
        # We are finding subtours and removing all combinations of that subset
        # https://www.math.unipd.it/~luigi/courses/metmodoc1819/m08.01.TSPexact.en.pdf
        
        # make a list of edges selected in the solution
        vals = model.cbGetSolution(model._arcvars)
        selected = gp.tuplelist((i, j) for i, j in model._arcvars.keys() # These are the arcs
                                if vals[i, j] > 0.5)
        # find a cycle in the selected edge list
        tours = subtour(selected)
        
        l = 0
        for tour in tours:
            l += len(tour)
#             print(l,"Subtour found:", tour, len(tour))
            if len(tour) < n+len(T):
                # add a subtour elimination constraint
                expr = 0 # Adds the variables
                curval = 0.0 # Tracks the solution val of variables
                for (i,j) in model._arcvars.keys(): # We do it this way in case some pairs aren't feasible
                    if i in tour and j in tour:
                        expr += model._arcvars[i,j]
                        curval += vals[i,j]
                if (curval > len(tour)-1+0.0001): # Ensuring the tolerance is violated
                    model.cbLazy(expr <= len(tour)-1) # Adding the cut
        
        
def subtour(arcs):
    '''
    This function will find subtours within the given arcs. Will return the 
    nodes in the order in which they are visited within the subtour (ignoring 
    return to starting node).
    '''
    visited = {}
    visited_nodes = list(set([i for i,j in arcs]))
    openset = set()
    for i in N:
        visited[i]=False
        if i in visited_nodes: # Need this as we may not visit all
            openset.add(i)
    cycles = []
    lengths = []
    neighbors = defaultdict(lambda: [])
    for x,y in arcs:
        neighbors[x].append(y)
    while True:
        current = openset.pop()
        # start BFS for a cycle at the node current
        thiscycle = [current]
        while True:
            visited[current] = True
            curneighbors = [x for x in neighbors[current] if not visited[x]]
            if len(curneighbors) == 0:
                break
            current = curneighbors[0]
            openset.remove(current)
            thiscycle.append(current)
        cycles.append(thiscycle)
        lengths.append(len(thiscycle))
        if sum(lengths) == n+len(V)+1 or len(openset) < 1:
            break
    return cycles
#### End definition of search for subtour function ####



###
###
### OPTIMIZATION MODEL
###
###
model = Model()

######## DECISION VARIABLES #############
X = model.addVars(c, name="x", vtype = GRB.BINARY) # Tour variables
Y = model.addVars(W, name="y", vtype = GRB.BINARY) # Coverage Variables
model.update()

######## CONSTRAINTS #############


# Must visit nodes
for i in T:
    model.addConstr(quicksum(X[i,j] for j in N) == 1)

# Place n new drop boxes
model.addConstr(quicksum(X[i,j] for i in P for j in N) == n)

# Flow in = Flow out
for j in N:
    model.addConstr(quicksum(X[i,j] for i in N) == quicksum(X[j,k] for k in N))

# Subtour elimination constraints
# Added with lazy constraints


# Coverage indicator constraint
for k in W:
    model.addConstr(1-Y[k] <= quicksum(X[i,j] for i in Ni[k] for j in N))
    
# Base coverage constraint
for k in W:
    model.addConstr(2 <= quicksum(X[i,j] for i in Nprime[k] for j in N))


# Coverage (objective one)
model.addConstr(quicksum(W[i][0]*W[i][1]*Y[i] for i in W) <= e)


######## OBJECTIVE #############
# TSP Tour length
model.setObjective(quicksum(c[i,j]*X[i,j] for i in N  for j in N))

######## SOLUTIUON #############
model._arcvars = X
model.Params.lazyConstraints = 1
model.update()
start = timer()
model.optimize(mycallback) #subtourelim) #
end = timer()

if model.status == GRB.OPTIMAL:
    solution_x = model.getAttr('x', X)
    solution_y = model.getAttr('x', Y)
    last = None
    tour = [office]
    while last != office:
        for j in N:
            if solution_x[tour[-1],j] >= 0.5:
               tour.append(j)
               break
        last = tour[-1]
     
    print("Optimal tour:", tour)
    print("Optimal Tour Length:", sum([c[tour[i],tour[i+1]] for i in range(len(tour)-1)]))
     
    print("Optimal Coverage:", sum(W[i][1] for i in W if len(list(set(Ni[i]) & set(tour)))> 0) )

print()
print("Solution Time",end - start)

for i,j in solution_x:
    if solution_x[i,j] > 0.5:
        print(i,j, solution_x[i,j])
selected = [(i,j) for (i,j) in X if solution_x[i,j] > 0.5]      
# print(selected)  
assert len(subtour(selected)[0]) == n+len(V)+1