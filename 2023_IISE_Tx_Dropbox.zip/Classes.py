'''
This file is used to implement classes to support an algorithm for the covering tour 
problem using the Steiner tree problem and the TSP problem.
@author: Adam Schmidt
'''
from networkx.classes.function import path_weight
import numpy as np
from collections import defaultdict
import networkx as nx
import os,csv
import numpy as np
from gurobipy import *
from itertools import combinations, chain
import matplotlib.pyplot as plt
from networkx.algorithms.shortest_paths.weighted import single_source_dijkstra
from networkx.algorithms.traversal.breadth_first_search import bfs_successors
from networkx.algorithms.shortest_paths.generic import has_path    
import heapq
     
class CTPGraph:
    '''
    An undirected graph structure for the CTP given the sets V, W, and E and a
    weight on the edges on E
    '''
    def __init__(self):
        self.nx_graph = nx.Graph() # Easier to do some of the functionality
        self.V = set() # IDs of all nodes related to the tour
        self.T = set() # IDs related to nodes that must be included in the tour
        self.W = set() # IDs related to the nodes that must be covered
        self.E = set() # This will store the edges 
        self.c = {} # This stores the cost of various arcs
        self.neighbors =  defaultdict(set) # This will store neighbors of arcs
        self.coverageVtoW = defaultdict(set) # This will store the nodes of W that a node v in V covers
        self.coverageWtoV = {} # This will store the nodes of V that covers a node w in W
        self.first_warning = False # Set this to true when we want warning to show
        self.max_edge_cost = -np.inf
        self.neighboring_edges = defaultdict(set) # This will store arcs connected to a node
        
    def _get_neighbors(self,E):
        neighbors = defaultdict(list)
        for e in E:
            neighbors[e[0]].append(e[1])
            neighbors[e[1]].append(e[0])
        return neighbors
    def get_neighbors(self, node):
        '''
        This will return the nodes that [node] is connected to by an
        arc in the form of a list
        '''
        return self.neighbors[node]
    
    def get_cost(self,edges):
        '''
        [arcs] is an iterable of edges to find the cost for
        '''
        sum = 0
        for e in edges:
            sum += self.c[e]

    def add_V(self,n):
        self.V.add(n)
        self.nx_graph.add_node(n)
        
    def add_T(self,n):
        self.V.add(n)
        self.T.add(n)
        self.nx_graph.add_node(n)
        
    def add_W(self,w):
        self.W.add(w)
        self.nx_graph.add_node(w)
          
    def add_edge(self,e,cost):
        if e[0] == e[1]:
            if self.first_warning:
                self.first_warning = False
                print(f'Skipping edge {e}. All future edges between the same node will be ignored.')
            return
        if e[0] > e[1]: # Flipping so we always have arcs that have a lower number first
            e = e[1],e[0] # This is ok since we assume symmetry
        self.E.add(e)
        self.c[e] = cost
        self.neighbors[e[0]].add(e[1])
        self.neighbors[e[1]].add(e[0])
        if cost > self.max_edge_cost:
            self.max_edge_cost = cost
        self.nx_graph.add_edge(e[0],e[1],weight=self.c[e[0],e[1]])
        self.neighboring_edges[e[0]].add(e)
        self.neighboring_edges[e[1]].add(e)
        
    def add_coverage(self,w,V_subset):
        '''
        Takes a node w in W to be covered and a subset of V that covers it
        '''
        self.coverageWtoV[w] = V_subset
        for v in V_subset: # Adding w to the nodes the v covers
            self.coverageVtoW[v].add(w)
            
    def get_coverage(self,n):
        '''
        Returns the nodes that cover/are covered by node n
        
        Will return dynamically based on if n in W or V
        '''
        if n in self.W:
            return self.coverageWtoV[n]
        return self.coverageVtoW[n]
        
    def get_edge_cost(self,e):
        '''
        [arcs] is an iterable of edges to find the cost for
        '''
        if e[0] == e[1]:
            return 0
        if e in self.c:
            return self.c[e]
        return self.c[e[1],e[0]]
        
    def get_edges_cost(self,edges):
        '''
        [arcs] is an iterable of edges to find the cost for
        '''
        sum = 0
        for e in edges:
            sum += self.c[e]
        return sum
    
    def get_connected_edges(self,n):
        '''
        Returns the edges that are connected to node n
        '''
        return self.neighboring_edges[n]
    
    def get_edge(self,i,j):
        '''
        Given the two nodes i and j, returning the edge that is between them
        '''
        if (i,j) in self.E:
            return i,j
        return j,i
            
    
    def get_tour_cost(self,path):
        '''
        [arcs] is an iterable of edges to find the cost for
        '''
        sum = 0
        for i in range(1,len(path)):
            sum += self.c[self.get_edge(path[i-1],path[i])]
        return sum
        
    def get_TSP(self, nodes, flag = 'exact'):
        '''
        This finds the subgraph defined by [nodes] and computes the TSP
        over those nodes
        '''
        if flag == 'exact':
            return self.get_optimal_tour(nodes)
        if flag == 'christofides':
            return self.get_approx_tour(nodes)
    def get_approx_tour(self,nodes):
        # https://networkx.org/documentation/latest/reference/algorithms/generated/networkx.algorithms.approximation.traveling_salesman.traveling_salesman_problem.html#networkx.algorithms.approximation.traveling_salesman.traveling_salesman_problem
        tour = nx.algorithms.approximation.traveling_salesman.traveling_salesman_problem(self.nx_graph,nodes=nodes)
        return tour, nx.classes.function.path_weight(self.nx_graph,tour,weight = 'weight')
    
    def get_optimal_tour(self,nodes):
#         https://www.gurobi.com/documentation/9.1/examples/tsp_py.html
        if len(nodes) == 1:
            return list(nodes), 0
        if len(nodes) == 2:
            tmp = list(nodes)
            t = tmp + [tmp[0]]
            return t, self.get_tour_cost(t)
        # Callback - use lazy constraints to eliminate sub-tours
        def subtourelim(model, where):
            if where == GRB.Callback.MIPSOL:
                # make a list of edges selected in the solution
                vals = model.cbGetSolution(model._vars)
                selected = tuplelist((i, j) for i, j in model._vars.keys()
                                        if vals[i, j] > 0.5)
                # find the shortest cycle in the selected edge list
                tours = subtour(selected)
                for tour in tours:
                    if len(tour) < len(nodes):
                        # add subtour elimination constr. for every pair of cities in tour
                        model.cbLazy(quicksum(model._vars[i, j]
                                                 for i, j in combinations(tour, 2))
                                     <= len(tour)-1)
        
        
        # Given a tuplelist of edges, find the shortest subtour
        
        def subtour(edges):
            print(edges)
            cycles = []
            unvisited = set(nodes)
#             cycle = nodes  
#             print('Starting subtour search')
            while unvisited:  # true if list is non-empty
#                 print('New subtour')
                thiscycle = []
                neighbors = list(unvisited)
                print(thiscycle,neighbors,unvisited)
                while neighbors:
                    current = neighbors[0]
                    thiscycle.append(current)
                    unvisited.remove(current)
#                     print('edges',current,[j for i,j in edges if i == current],[j for i,j in edges if i == current and j in unvisited])
                    neighbors = [j for i,j in edges if i == current and j in unvisited]
                    print(thiscycle,neighbors,unvisited)
                cycles.append(thiscycle)
#                 if len(cycle) > len(thiscycle):
#                     cycle = thiscycle
            return cycles

        
        
        m = Model()
        m.Params.OutputFlag = 0
        # Create variables
        vars = {}
        for i in nodes:
            for j in self.get_neighbors(i):
                if j in nodes:
                    vars[i,j] = vars[j,i]= m.addVar(obj=self.c[self.get_edge(i, j)], vtype=GRB.BINARY, name='x')
        print(len(vars))
        print(len(nodes))
        print(len(vars)==len(nodes)*(len(nodes)-1))
        # Add degree-2 constraint
        for i in nodes:
            m.addConstr(sum(vars[i,j] for j in nodes if i != j) == 2)

        # Solving 
        m._vars = vars
        m.Params.lazyConstraints = 1
        m.update()
        m.optimize(subtourelim) #
        vals = m.getAttr('x', vars)
        selected = tuplelist((i, j) for i, j in m._vars if vals[i, j] > 0.5)
        tour = subtour(selected)[0]
        tour += [tour[0]]
#         print()
#         print('Solution found',tour)
        if len(tour) != len(nodes)+1:
            print(nodes)
            print(tour)
            print(subtour(selected))
            print(selected)
            raise Exception(f'Error finding tour, nodes {set(nodes).difference(tour)} not included')
        return tour,m.objVal 
    
#     def get_optimal_tour(self,nodes):
# #         https://www.gurobi.com/documentation/9.1/examples/tsp_py.html
#         print('Nodes',nodes)
#         if len(nodes) == 1:
#             return list(nodes), 0
#         if len(nodes) == 2:
#             tmp = list(nodes)
#             t = tmp + [tmp[0]]
#             return t, self.get_tour_cost(t)
#         # Callback - use lazy constraints to eliminate sub-tours
#         def subtourelim(model, where):
#             if where == GRB.Callback.MIPSOL:
#                 # make a list of edges selected in the solution
#                 vals = model.cbGetSolution(model._vars)
#                 selected = tuplelist((i, j) for i, j in model._vars.keys()
#                                         if vals[i, j] > 0.5)
#                 # find the shortest cycle in the selected edge list
#                 tours = subtour(selected)
#                 for tour in tours:
#                     if len(tour) < len(nodes):
#                         # add subtour elimination constr. for every pair of cities in tour
#                         model.cbLazy(quicksum(model._vars[i, j] 
#                                                  for i, j in combinations(tour, 2))
#                                      <= len(tour)-1)
#         
# #                     if len(tour) < len(nodes):
# #                         # add a subtour elimination constraint
# #                         expr = 0
# #                         curval = 0.0
# #                         for i in tour:
# #                             for j in self.get_neighbors(i):
# #                                 if j in tour:
# #                                     expr += model._vars[i,j]
# #                                     curval += vals[i,j]
# #                                 if (curval > len(tour)-1+0.0001):
# #                                    model.cbLazy(expr <= len(tour)-1)
#         
#         # Given a tuplelist of edges, find the shortest subtour
#         
#         def subtour(edges):
#             cycles = []
#             unvisited = list(nodes)
# #             cycle = nodes  
#             while unvisited:  # true if list is non-empty
#                 thiscycle = []
#                 neighbors = unvisited
#                 while neighbors:
#                     current = neighbors[0]
#                     thiscycle.append(current)
#                     unvisited.remove(current)
#                     neighbors = [j for i, j in edges.select(current, '*')
#                                  if j in unvisited]
#                 cycles.append(thiscycle)
#             return cycles
# 
#         
#         
#         m = Model()
#         m.Params.OutputFlag = 0
#         # Create variables
#         vars = {}
#         for i in nodes:
#             for j in nodes.intersection(self.get_neighbors(i)):
#                     vars[i,j] = vars[j,i]= m.addVar(obj=self.c[self.get_edge(i, j)], vtype=GRB.BINARY, name='x')
#         # Add degree-2 constraint
#         for i in nodes:
#             m.addConstr(sum(vars[i,j] for j in nodes if i != j) == 2)
# 
#         # Solving 
#         m._vars = vars
#         m.Params.lazyConstraints = 1
#         m.update()
#         m.optimize(subtourelim) #
#         print(m.status)
#         vals = m.getAttr('x', vars)
#         selected = tuplelist((i, j) for i, j in vals.keys() if vals[i, j] > 0.5)
#         tour = subtour(selected)[0]
#         tour += [tour[0]]
#         return tour,m.objVal 
#     
class AuxiliaryGraph:
    '''
    An undirected graph structure for the auxiliary graph used within the algorithm
    '''
    def __init__(self):
        self.nx_graph = nx.Graph()
        self.first_warning = False
        return
    
    def load(self, ctp_graph):  
        self.ctp_graph = ctp_graph
        self.R = ctp_graph.T.union(ctp_graph.W) # These are the required nodes
        self.S = ctp_graph.V - ctp_graph.T # These are the Steiner (not required) nodes
        self.E = ctp_graph.E # Undirected
        self.N = self.R.union(self.S)
        self.c = ctp_graph.c # Assumed to be metric
        self.neighbors = ctp_graph.neighbors
        # This will upate costs and 
        self._add_W_edges(ctp_graph) # Need to take the coverage
        self.nx_graph.add_nodes_from(self.R.union(self.S))
        self.nx_graph.add_edges_from([(e1,e2,{'weight': self.c[e1,e2]}) for e1, e2 in self.c])
        
    def _add_W_edges(self,ctp_graph):
        for w in ctp_graph.W:
            for v in ctp_graph.get_coverage(w):
#                 self.add_edge((v,w),ctp_graph.max_edge_cost+10)
                self.add_edge((v,w),ctp_graph.max_edge_cost*len(ctp_graph.V)/(len(ctp_graph.V)+len(ctp_graph.W)-1))
    
    def removeNodes(self,N):
        '''
        Removes the nodes in N from the auxiliary graph
        '''
        for n in N:
            if n in self.R.difference(self.ctp_graph.W):
                raise Exception(f'Attempting to remove {n} which is a required node')
            if n in self.S:
                self.S.remove(n)
            else:
                self.R.remove(n)
            self.N.remove(n)
            self.nx_graph.remove_node(n)
        self.removeEdges(N)
        
    def removeEdgesToW(self,N):
        '''
        Over the set of nodes N subset V, removing the arcs between 
        v \in N and w \in W
        '''
        for v in N:
            for w in self.R.intersection(self.ctp_graph.W):
                if (v,w) in self.E or (w,v) in self.E:
                    self.remove_edge((v,w))
                    
    
    def removeEdges(self,N):
        '''
        Over the set of nodes N, removing the arcs between 
        v and its neighbors
        '''
        for v in N:
            for n in self.neighbors[v].copy():
                self.remove_edge((v,n))
                
    def get_neighbors(self, node):
        '''
        This will return the nodes that [node] is connected to by an
        arc in the form of a list
        '''
        return self.neighbors[node]

    def add_edge(self,e,cost):
        if e[0] == e[1]:
            if self.first_warning:
                self.first_warning = False
                print(f'Skipping edge {e}. All future edges between the same node will be ignored.')
            return
        self.E.add(e)
        self.c[e] = cost
        self.neighbors[e[0]].add(e[1])
        self.neighbors[e[1]].add(e[0])
    
    def addNtoR(self,N):
        '''
        Adds nodes N to the set R
        '''
        self.R = self.R.union(N)
        self.S = self.S.difference(N)
        
    def remove_edge(self,e):
        if e not in self.E:
            e = e[1],e[0]
        self.E.remove(e)
        del self.c[e]
        self.neighbors[e[0]].remove(e[1])
        self.neighbors[e[1]].remove(e[0])
        if e in self.nx_graph.edges:
            self.nx_graph.remove_edge(e[0],e[1])
        
    def get_edge_cost(self,e):
        '''
        [arcs] is an iterable of edges to find the cost for
        '''
        
        if e in self.c:
            return self.c[e]
        return self.c[e[1],e[0]]
        
    def get_edges_cost(self,edges):
        '''
        [arcs] is an iterable of edges to find the cost for
        '''
        sum = 0
        for e in edges:
            sum += self.c[e]
        return sum
    
    def get_steiner_nodes(self, flag = 'approx'):
        
        
        if flag == 'approx':
            return self.approximate_steiner()
        if flag =='best approx':
            return self.best_steiner_approx()
        if flag == 'sketch_heuristic':
            return self.steiner_heuristic_sketch()
        if flag == 'sketchls_heuristic':
            return self.steiner_heuristic_sketchls()
        if flag == 'sketchls_pq_heuristic':
            return self.steiner_heuristic_sketchls_pq()
        return self.optimal_steiner()
    
    def steiner_heuristic_sketchls_pq(self):
        '''
        Similar to the sketchls implementation to generate steiner tree solutions,
        just use priority queue search rather than a breadth first search
        '''
               # Implementing the heuristic in:
        # file:///C:/Users/apschmidt/AppData/Local/Microsoft/Windows/INetCache/Content.Outlook/PK2VL095/CIKM_Steiner.pdf
        # Adjusting to account for weights on edges
        # Sketch index
        # Step 1) Seed sampling:Sample uniformly at random the
        # sets of seed nodes S1, S2, . . . Sm of sizes 1, 2, . . . , 2^m−1
        #where m = log |N|.
        
        m = np.log(len(self.N))
        S = {} # Seed sampling
        SPT = {} # Shortest path tree
        dijkstras = {} #Stores the tree for a source node so we don't recompute
        for i in range(1, max(math.ceil(m-1),2)):
            S[i] = np.random.choice(a = list(self.N),size= i,replace=False)
            # Step 2) Shortest path tree: For every seed set Si perform
            # the Dijkstra’s algorithm expansion from it and compute
            # the complete shortest path tree SPTi.
            
            # First, for each seed, we run Dijkstras to find the shortest path
            SPT[i] = defaultdict(lambda: (np.inf,None)) # Will store the shortest path for each v
            for s in S[i]:
                # Finding shortest path from a given node to all others
                if s not in dijkstras:
                    # A tuple of two dictionaries keyed by node. The first dictionary 
                    # stores distance from the source. The second stores the path from 
                    # the source to that node.
                    dijkstras[s] = single_source_dijkstra(self.nx_graph, source = s, weight = 'weight')
                    SPT[i][s] = (0, [s],[])
                # We iterate over all nodes V and find the shortest path among all seeds
                # S[i]
                for v in self.N:
                    if dijkstras[s][0][v] < SPT[i][v][0]:
                        # Stores the distance and the path
                        SPT[i][v] = dijkstras[s][0][v], dijkstras[s][1][v]
                        SPT[i][v][1].reverse()
        
        # step 3) Sketch
        Trees = {}
        shortest_subpaths = {}
        for v in self.R: # Want to find landmarks in each set
            shortest_subpaths[v] = {}
            Trees[v] = nx.Graph()
            for i in S:
                # Creating trees from landmarks
                cost = 0
                Trees[v].add_node(v)
                shortest_subpaths[v][v] = (0,[v])
                if SPT[i][v][1][0] != v:
                    SPT[i][v][1].reverse()
                for j in range(1,len(SPT[i][v][1])):
                    e1, e2 = SPT[i][v][1][j-1],SPT[i][v][1][j]
                    this_cost = self.nx_graph.edges[e1,e2]['weight']
                    cost += this_cost
                    shortest_subpaths[v][e2] = (cost, shortest_subpaths[v][e1][1]+[e2])
                    Trees[v].add_edge(e1,e2,weight = this_cost)
        
        ####
        # This is the 'meat' of the algorithm
        ####
        BFS= {} # vector of the BFS processes
        BFS_active = defaultdict(list) # Stores the last visited node in the BFS
        F = defaultdict(set) # Frontiers of the processes
        Scover = nx.Graph() # set of covered nodes connected pairs
        nodes = set()
        
        for r in self.R: # Initializing breadth first search
            BFS[r] = dict(bfs_successors(Trees[r], r))
            # Now adding each successor to a heapq so we explore the closest
            # ones first
            for success in BFS[r][r]:
                distance = shortest_subpaths[r][success][0]
                heapq.heappush(BFS_active[r], (distance,success)) # Need distance and then node
        
        # Round-robin interation
        run = True
        while run:
            for i in BFS:
                if len(BFS_active[i]) > 0:
                    v = heapq.heappop(BFS_active[i])[1] # This is the actual node
                    if v in BFS[i]: # If the node v has successors, add them
                        for success in BFS[i][v]: # Adding next layer of nodes to explore
                            distance = shortest_subpaths[i][success][0]
                            heapq.heappush(BFS_active[i], (cost, success)) 
                    F[i].add(v)
                    for j in F:
                        if j != i:
                            if v in F[j]: # This wasn't in original algorithm, but should be
                                          # If v is a neighbor of both i and j
                                          # The we add a path connecting i, v, j
                                if i in Scover and j in Scover and has_path(Scover,i,j):
                                    continue
                                second_component = shortest_subpaths[j][v][1][:-1]
                                second_component.reverse()
                                p = shortest_subpaths[i][v][1] + second_component # To avoid duplication of v
                                nodes = nodes.union(p)
                                Scover.add_edge(i,j)
                            else:
                                Fj_intersect_Nv = F[j].intersection(self.nx_graph.neighbors(v))
                                if len(Fj_intersect_Nv) > 0:
                                    if i in Scover and j in Scover and has_path(Scover,i,j):
                                        continue
                                    # Finding the node n in Fj_intersect_Nv that
                                    # is closest to the node v
                                    closest_dist = np.inf
                                    n = None
                                    for neigh in Fj_intersect_Nv:
                                        dist = self.nx_graph.get_edge_data(v,neigh)['weight']+shortest_subpaths[j][neigh][0]
                                        if dist < closest_dist:
                                            n = neigh
                                            closest_dist = dist
                                    second_component = shortest_subpaths[j][n][1]
                                    second_component.reverse()
                                    p = shortest_subpaths[i][v][1] + second_component
                                    nodes = nodes.union(p)
                                    Scover.add_edge(i,j)
                    if len(Scover.nodes) == len(self.R):
                        return nodes
                    
    def steiner_heuristic_sketchls(self):
        # Implementing the heuristic in:
        # file:///C:/Users/apschmidt/AppData/Local/Microsoft/Windows/INetCache/Content.Outlook/PK2VL095/CIKM_Steiner.pdf
        # Adjusting to account for weights on edges
        # Sketch index
        # Step 1) Seed sampling:Sample uniformly at random the
        # sets of seed nodes S1, S2, . . . Sm of sizes 1, 2, . . . , 2^m−1
        #where m = log |N|.
#         print('Starting heuristic')
#         print("N",self.N)
#         print("S",self.S)
#         print("R",self.R)
        
        m = np.log(len(self.N))
        S = {} # Seed sampling
        SPT = {} # Shortest path tree
        dijkstras = {} #Stores the tree for a source node so we don't recompute
        for i in range(1, max(math.ceil(m-1),2)):
            S[i] = np.random.choice(a = list(self.N),size= i,replace=False)
            # Step 2) Shortest path tree: For every seed set Si perform
            # the Dijkstra’s algorithm expansion from it and compute
            # the complete shortest path tree SPTi.
            
            # First, for each seed, we run Dijkstras to find the shortest path
            SPT[i] = defaultdict(lambda: (np.inf,None)) # Will store the shortest path for each v
            for s in S[i]:
                # Finding shortest path from a given node to all others
                if s not in dijkstras:
                    # A tuple of two dictionaries keyed by node. The first dictionary 
                    # stores distance from the source. The second stores the path from 
                    # the source to that node.
                    dijkstras[s] = single_source_dijkstra(self.nx_graph, source = s, weight = 'weight')
                    SPT[i][s] = (0, [s],[])
                # We iterate over all nodes V and find the shortest path among all seeds
                # S[i]
                for v in self.N:
                    if dijkstras[s][0][v] < SPT[i][v][0]:
                        # Stores the distance and the path
                        SPT[i][v] = dijkstras[s][0][v], dijkstras[s][1][v]
                        SPT[i][v][1].reverse()

        # step 3) Sketch
        Trees = {}
        shortest_subpaths = {}
        for v in self.R: # Want to find landmarks in each set
            shortest_subpaths[v] = {}
            Trees[v] = nx.Graph()
            for i in S:
                # Creating trees from landmarks
                cost = 0
                Trees[v].add_node(v)
                shortest_subpaths[v][v] = (0,[v])
                if SPT[i][v][1][0] != v:
                    SPT[i][v][1].reverse()
                for j in range(1,len(SPT[i][v][1])):
                    e1, e2 = SPT[i][v][1][j-1],SPT[i][v][1][j]
                    this_cost = self.nx_graph.edges[e1,e2]['weight']
                    cost += this_cost
                    shortest_subpaths[v][e2] = (cost, shortest_subpaths[v][e1][1]+[e2])
                    Trees[v].add_edge(e1,e2,weight = this_cost)
        
        ####
        # This is the 'meat' of the algorithm
        ####
        BFS= {} # vector of the BFS processes
        BFS_active = {} # Stores the last visited node in the BFS
        F = defaultdict(set) # Frontiers of the processes
        Scover = nx.Graph() # set of covered nodes connected pairs
        nodes = set()
        
        for r in self.R: # Initializing breadth first search
            BFS[r] = dict(bfs_successors(Trees[r], r))
            BFS_active[r] = BFS[r][r]
        
        # Round-robin interation
        run = True
        while run:
            for i in BFS:
                if len(BFS_active[i]) > 0:
                    v = BFS_active[i].pop(0)
                    if v in BFS[i]: # If the node v has successors, add them
                        BFS_active[i] += BFS[i][v] # Adding next layer of nodes to explore
                    F[i].add(v)
                    for j in F:
                        if j != i:
                            if v in F[j]: # This wasn't in original algorithm, but should be
                                          # If v is a neighbor of both i and j
                                          # The we add a path connecting i, v, j
                                if i in Scover and j in Scover and has_path(Scover,i,j):
                                    continue
                                second_component = shortest_subpaths[j][v][1][:-1]
                                second_component.reverse()
                                p = shortest_subpaths[i][v][1] + second_component # To avoid duplication of v
                                nodes = nodes.union(p)
                                Scover.add_edge(i,j)
                            else:
                                Fj_intersect_Nv = F[j].intersection(self.nx_graph.neighbors(v))
                                if len(Fj_intersect_Nv) > 0:
                                    if i in Scover and j in Scover and has_path(Scover,i,j):
                                        continue
                                    n = Fj_intersect_Nv.pop()
                                    second_component = shortest_subpaths[j][n][1]
                                    second_component.reverse()
                                    p = shortest_subpaths[i][v][1] + second_component
                                    nodes = nodes.union(p)
                                    Scover.add_edge(i,j)
                    if len(Scover.nodes) == len(self.R):
                        return nodes
                                   
    def steiner_heuristic_sketch(self):
        
        # Implementing the heuristic in:
        # file:///C:/Users/apschmidt/AppData/Local/Microsoft/Windows/INetCache/Content.Outlook/PK2VL095/CIKM_Steiner.pdf
        # Adjusting to account for weights on edges
        # Sketch index
        # Step 1) Seed sampling:Sample uniformly at random the
        # sets of seed nodes S1, S2, . . . Sm of sizes 1, 2, . . . , 2^m−1
        #where m = log |N|.
        
        m = np.log(len(self.N))
        S = {} # Seed sampling
        SPT = {} # Shortest path tree
        dijkstras = {} #Stores the tree for a source node so we don't recompute
        for i in range(1, max(math.ceil(m-1),2)):
            S[i] = np.random.choice(a = list(self.N),size= i,replace=False)
            # Step 2) Shortest path tree: For every seed set Si perform
            # the Dijkstra’s algorithm expansion from it and compute
            # the complete shortest path tree SPTi.
            
            # First, for each seed, we run Dijkstras to find the shortest path
            SPT[i] = defaultdict(lambda: (np.inf,None)) # Will store the shortest path for each v
            for s in S[i]:
                # Finding shortest path from a given node to all others
                if s not in dijkstras:
                    # A tuple of two dictionaries keyed by node. The first dictionary 
                    # stores distance from the source. The second stores the path from 
                    # the source to that node.
                    dijkstras[s] = single_source_dijkstra(self.nx_graph, source = s, weight = 'weight')
                    SPT[i][s] = (0, [s])
                # We iterate over all nodes V and find the shortest path among all seeds
                # S[i]
                for v in self.N:
                    if dijkstras[s][0][v] < SPT[i][v][0]:
                        # Stores the distance and the path
                        SPT[i][v] = dijkstras[s][0][v], dijkstras[s][1][v]
        
        # step 3) Sketch
        landmarks = {}
        for v in self.R: # Want to find landmarks in each set
            landmarks[v] = {}
            for i in S:
                # Getting the seed that was the closest in the tree
                landmarks[v][i] = SPT[i][v][1][0] 
        
        common_landmarks = set(landmarks[v].values()) # Just initializing the common landmarks
        ## Sketch Algorithm
        for r in self.R: # For each terminal, finding the common landmarks
            common_landmarks = common_landmarks.intersection(landmarks[r].values())
        
        
        # Iterate through all common landmarks to then find the smallest tree connected
        # to it
        best_nodes = set()
        best_cost = np.inf
        for l in common_landmarks:
            nodes = set() #adding the nodes from the connecting paths
            cost = 0
            edges = set()
            for r in self.R:  
                # Finding unique edges in resulting tree
                edges = edges.union([(dijkstras[l][1][r][i-1], dijkstras[l][1][r][i]) for i in range(1,len(dijkstras[l][1][r]))])
                nodes = nodes.union(dijkstras[l][1][r]) # Adding nodes from path 
                
            # Find cost of resulting tree
            cost = sum([self.nx_graph.edges[i,j]['weight'] for i,j in edges])
                              
            if cost < best_cost:
                best_cost = cost
                best_nodes = nodes
        return best_nodes
    
    def approximate_steiner(self):
        # https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.approximation.steinertree.steiner_tree.html
        # https://networkx.org/documentation/stable/tutorial.html#accessing-edges-and-neighbors
        return nx.algorithms.approximation.steinertree.steiner_tree(self.nx_graph,self.R).nodes
    
    def optimal_steiner(self):
        '''
        This will solve the steiner tree problem to optimality
        '''
        model = Model() # The optimization model
        r = 0
        Rminusr = self.R.difference([r]) # We know that zero will be in this
        
        #######
        # Adding the variables
        #######
        X = model.addVars(self.E, obj = self.c,vtype = GRB.BINARY) # Indicates which edges are selected
        f = {} # Will store the 
        for i,j in self.E:
            for k in Rminusr:
                f[i,j,k] = model.addVar()
                f[j,i,k] = model.addVar()
        
        #######
        # Adding the constraints
        #######
        
        # 1) Flow constraints
        for k in Rminusr:
            for i in self.R.union(self.S):
                lhs = 0
                if i == r:
                    lhs = 1
                elif i == k:
                    lhs = -1
                
                model.addConstr(quicksum(f[i,j,k] for j in self.get_neighbors(i)) - quicksum(f[j,i,k] for j in self.get_neighbors(i)) == lhs)
        
            
            for i,j in self.E:
                # 2) Send flow if edge selected
                model.addConstr(f[i,j,k] <= X[i,j])
                model.addConstr(f[j,i,k] <= X[i,j])
        
                # 3) Directional constraint
                for h in Rminusr:
                    model.addConstr(f[i,j,k]+f[j,i,h] <= X[i,j])
        
        ######
        # Solving
        ######
        model.update()
        model.optimize()
        if model.status == GRB.OPTIMAL:
            nodes = set()
            solution_x = model.getAttr('x',X)
        
            for i,j in solution_x:
                if solution_x[i,j] > 0.5:
                    nodes = nodes.union([i,j])
            
            return nodes
        
        raise Exception('No optimal solution found')
        
    
    def best_steiner_approx(self):
        '''
        This implements thw ~1.39 approximation algorithm for the steiner
        tree problem
        '''
        epsilon = 0.01
        k = 3 #2**(math.ceil(1/epsilon))
        
        def find_directed_components(k,graph, Y):
            '''
            k is the max number of terminals in a component
            graph is the current (condensed) graph
            Y is the current set of terminal nodes
            
            returns a dictionary where keys are directed components (networkx
            DiGraph) and keys are tuples 
            0: the cost of the tree
            1: the root of the tree
            '''
            def powerset(iterable):
                #https://stackoverflow.com/questions/1482308/how-to-get-all-subsets-of-a-set-powerset
                "powerset([1,2,3]) --> () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)"
                s = list(iterable)
                return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))
            
            def find_steiner(graph,Y):
                '''
                Will take in a graph and the terminal nodes. 
                Will find the optimal Steiner tree and then return its cost and
                a graph holding the tree structure
                '''
                if len(Y) == 0:
                    return 0, nx.Graph() 
                if len(Y) == 1:
                    new_graph = nx.Graph()  
                    new_graph.add_nodes_from(Y)  
                    return 0, new_graph
                if len(Y) <= 2:
                    Y = list(Y)
                    new_graph = nx.Graph()  
                    nodes = nx.algorithms.shortest_paths.generic.shortest_path(graph,
                                                                               source = Y[0],
                                                                               target = Y[1],
                                                                               weight = 'weight')
                    new_graph.add_nodes_from(nodes) 
                    cost = 0 
                    for i in range(1,len(nodes)):
                        cost_this = graph.get_edge_data(nodes[i-1],nodes[i])['weight']
                        cost += cost_this
                        new_graph.add_edge(nodes[i-1],nodes[i],weight =  cost_this) 
                    return cost, new_graph      
                
                
                # Find the optimal steiner tree (can be done in polynomial time)
                # https://onlinelibrary-wiley-com.ezproxy.library.wisc.edu/doi/pdfdirect/10.1002/net.3230010302
                Y= set(Y)
                q = list(Y)[0] # Just getting a random element
                C = Y.difference([q])
                N = graph.nodes
                cost = 0
                distances = {}
                shortest_paths = {}
                for i in N:
                    for j in N:
                        short_path = nx.algorithms.shortest_paths.generic.shortest_path(graph,source = i, target = j, weight = 'weight')
                        distances[i,j] = path_weight(graph, short_path, weight="weight")
                        shortest_paths[i,j] = short_path
                
                S = {} # Stores the cost of the tree components
                S_arg = {} # Stores the data so we can rebuild the tree
                           # Key is [m,D] and value is (k,E,F) where k is the node
                           # that minimized d_mk + S_k(D) and E/F are the sets 
                           # that generated S_k(D)
                for t in C:
                    for j in N:
                        S[(t,),j] = distances[t,j]
                        S_arg[j,(t,)] = t, set(),set()
                        
                for m in range(2,len(C)):
                    for D in combinations(C,m): # Find subsets of C of size m
                        D = set(D)
                        D_tup = tuple(D)
            #             print("D=",D)
                        for i in N:
                            S[D_tup,i] = np.inf
            #                 S_arg[i,tuple(D)] = (None,None,None)
                        for j in N:
                            u = np.inf
                            E_set = list(powerset(D))[:-1] # Needs to be proper subset
                            E_set = [e for e in E_set if D_tup[0] in e]
                            argmin_E = set()
                            armin_F = set()
                            for E in E_set: 
                                E_tup = tuple(E)
                                DmE = D.difference(E)
                                DmE_tup = tuple(DmE)
                                if S[E_tup,j]+S[DmE_tup,j] < u:
                                    u = S[E_tup,j]+S[DmE_tup,j]
                                    argmin_E = E
                                    argmin_F = DmE
                            for i in N: # here, j is equal to k
                                if u + distances[i,j] < S[D_tup,i]:
                                    S[D_tup,i] = u + distances[i,j]
                                    S_arg[i,D_tup] = j,argmin_E,argmin_F
                
                v = np.inf
                E_set = list(powerset(C))[:-1] # Proper subset
                E_set = [set(e) for e in E_set if list(C)[0] in e]
                
                for j in N: # j is equivalent to k
                    u = np.inf
                    argmin_E = set()
                    armin_F = set()
                    for E in E_set:
                        E_tup = tuple(E)
                        CmE = C.difference(E)
                        CmE_tup = tuple(CmE)
                        if S[E_tup,j]+S[CmE_tup,j] < u:
                            u = S[E_tup,j]+S[CmE_tup,j]
                            argmin_E = E
                            armin_F = CmE
            
                    if u + distances[q,j] < v:
                        v = u + distances[q,j]
                        argmin = j
                        S_arg[q,tuple(C)] = j,argmin_E,armin_F
                        
                ### Here we are reconstructing the solution
                edges = set()
                # First, we add the shortest path from q to the argmin
                tmp = []
                to_visit = [(q,C)]
                while len(to_visit) > 0:
                    m,D = to_visit[0]
                    k, E, F = S_arg[m,tuple(D)]
                    to_visit = to_visit[1:]
                    
                    # We add the shortest path from m to k
                    sp = shortest_paths[m,k]
                    for indexnum in range(1, len(sp)):
                        tmp.append((sp[indexnum-1],sp[indexnum]))
                    edges = edges.union(tmp) # Adding the first arc
                    
                    # Now we add the sub steiner trees
                    # Checking E and F set; if needed adding them to visit in future
                    for s in [E,F]:
                        if len(s) > 0: # There exists a subtree to add
                            to_visit.append((k,s))
                
                new_graph = nx.Graph()  
                nodes = set()
                for i,j in edges:
                    nodes.add(i)
                    nodes.add(j)
                new_graph.add_nodes_from(nodes)  
                new_graph.add_edges_from([(i,j,{'weight': graph.get_edge_data(i,j)['weight']}) for i,j in edges])                  
                return v,  new_graph                   
            #####
            # Creating a steiner tree

            
            Ck = {} # stores the components and the cost
            
            Rprime_set = set()
            for i in range(1,k+1): # Find all combinations of at most k nodes of Y
                Rprime_set = Rprime_set.union(combinations(Y,i))
            
            for Rprime in Rprime_set:
                if len(Rprime) ==0:
                    pass # To ensure a feasible model, we must have two terminals
                elif len(Rprime) == 1:
                    C = nx.DiGraph()
                    C.add_node(Rprime[0])
                    Ck[C] = (0, Rprime[0])
                else:
                    subgraph = graph.copy()
                    
                    # UNCLEAR IF THIS NEEDS TO BE DONE
#                     for r in Y.difference(Rprime): # REMOVE NODES NOT IN Rprime THAT ARE IN Y
#                        subgraph.remove_node(r)
                    
                    # Find the optimal steiner tree (can be done in polynomial time)
                    # https://onlinelibrary-wiley-com.ezproxy.library.wisc.edu/doi/pdfdirect/10.1002/net.3230010302
                    cost, tree = find_steiner(subgraph,Rprime)
                    ####    
                    # Now for each node, make the steiner tree directed towards an
                    # rprime in Rprime
                    ####
                    for rprime in Rprime:
                        C = nx.DiGraph() # the directed component, will store as graph
                        to_visit = [rprime]
                        while to_visit: # will stop when empty
                            next = to_visit[0]
                            to_visit = to_visit[1:]
                            for n in set(tree.neighbors(next)).difference(C.nodes):
                                C.add_node(n)
                                to_visit.append(n) 
                                C.add_edge(n, next)  
                                             
                        Ck[C] = cost, rprime
            
            return Ck
       
        graph =self.nx_graph.copy()
        
        # In case we need to use the metric closure
#         # We want to find the metric closure
#         graph = nx.algorithms.approximation.steinertree.metric_closure(graph)
#         # We want to set the weight to the min distance between nodes
#         for i,j in graph.edges:
#             graph.edges[i,j]['weight'] = graph.get_edge_data(i,j)['distance']
                
        temp_terminal = self.R.copy() # Stores the terminals in the current version of the graph.
        Ct = [] # A copy of each component
        while len(temp_terminal) > 1: # for t = 0,1,2,...
            ######
            # Compute a (1+epsilon/2)-approximation solution
            ######
            Ck = find_directed_components(k,graph,temp_terminal) # Dictionary of directed components with at most k terminals (and cost)
            r = list(temp_terminal)[0] # Getting our root/sink node
            
            Vprime = set(Ck.keys()).union(temp_terminal)
            Eprime = set()
            eC = {} # eC = (vC,sink(C))
            delta_in = defaultdict(set)
            delta_out = defaultdict(set)
            
            for C in Ck:
                # Add edge (u, vc) for any u \in sources(C)
                # Sources are all terminals not equal to the sink
                for u in set(C.nodes).intersection(temp_terminal).difference([Ck[C][1]]): 
                    a = (u,C)
                    Eprime.add(a)
                    delta_in[C].add(a)
                    delta_out[u].add(a)
                    
                # Add edge eC = (vc,sink(C))
                a = (C,Ck[C][1])
                Eprime.add(a)
                eC[C] = a
                delta_in[Ck[C][1]].add(a)
                delta_out[C].add(a)

            ## Optimization model (LP)
            model = Model() # The optimization model
            model.Params.OutputFlag = 0
            # Variable 1
            X = {}
            for C in Ck:
                X[C] = model.addVar(obj = Ck[C][0],vtype = GRB.CONTINUOUS)
            f = {}
            for s in set(temp_terminal).difference([r]):
                for e in Eprime:
                    # Variable 2
                    if type(e[1]) == type(1):
                        if type(e[0]) == type(1):
                            e_name = e
                        else:
                            e_name = list(e[0].nodes),e[1]
                    else:
                        if type(e[0]) == type(1):
                            e_name = e[0],list(e[1].nodes)
                        else:
                            e_name = list(e[0].nodes),list(e[1].nodes)
                        
                    if type(s) == type(1):
                        s_name = s
                    else:
                        s_name = list(s.nodes)
                    f[s,e] = model.addVar(vtype = GRB.CONTINUOUS, name = f'f[{s_name},{e_name}]')
                    
                # Constraint 1: flow-balance
                # This loop was missing in formulation...assuming this is what
                # was meant to be included
                for v in Vprime:
                    rhs = 0
                    if v == s:
                        rhs = 1
                    elif v == r:
                        rhs = -1
                        
                    lhs1 = quicksum(f[s,e] for e in delta_in[v])  
                    lhs2 = quicksum(f[s,e] for e in delta_out[v])
                    model.addConstr(lhs2 - lhs1 == rhs) # Flow balance
                    
                # Constraint 2: cap
                for C in Ck:
                    model.addConstr(f[s,eC[C]] <= X[C])
            
            model.update()
            model.optimize()
            
            ######
            # Sample component C with probability x/sum(x)
            ######
            solution_x = model.getAttr('x', X) # equals solution values
            components = list(Ck.keys())
            total = sum([solution_x[C] for C in components])
            selected_C = np.random.choice(components, p=[solution_x[C]/total for C in components],replace=False)
            Ct.append(selected_C)
            ######
            # Contract C into its sink
            ######
            best_edge_cost = defaultdict(lambda: np.inf) # Need to store for each node not in component
            rprime = Ck[selected_C][1]
            # We are to collapse all terminals in the component onto rprime and 
            # rprime inherits the edges
            for n in set(selected_C.nodes).difference([rprime]):
                # First we check edge costs incident to the component
                # Excluding edges fully contained within component
                for i in set(graph.neighbors(n)).difference(selected_C.nodes):
                    cost = graph.get_edge_data(i,n)['weight']
                    if cost < best_edge_cost[i]:
                        best_edge_cost[i] = cost
                # We want to remove nodes that are not rprime
                graph.remove_node(n) # CHECK : DO WE REMOVE ALL OR JUST TERMINALS??
            # Updating the best cost on each edge (adding edge if necessary)
            for i in best_edge_cost:
                if not graph.has_edge(i,rprime):
                    graph.add_edge(i,rprime, weight=best_edge_cost[i])
                else:
                    graph.edges[i,rprime]['weight'] = min(best_edge_cost[i],graph.edges[i,rprime]['weight'])

            temp_terminal = set(graph.nodes).intersection(self.R)

#             temp_terminal.difference(set(selected_C.nodes).intersection(self.R).difference([rprime])) # terminals after contract
        
        # Now we have finished and we simply return the union of the components
        nodes = set()
        for C in Ct:
            nodes = nodes.union(C.nodes)
        
        return nodes
            
    
class Algorithm:
    def __init__(self):
        self.data_loaded = False
        self.solutionFound = False
        self.graph = CTPGraph() # Creating an inital graph
        self.solution_time = np.inf
        self.tour = None
        self.tour_cost = np.inf
        self.fixed_cost = {}
        self.name = 'Algorithm'
    def __str__(self):
        return f'{self.name}'

    def __repr__(self):
        return f'{self.name}'
    
    def load(self, data_folder):
        '''
        This will take a folderpath and create a graph given the data
        '''
        if self.data_loaded:
            print("Warning: Data has already been loaded. Overwritting old data.")
            
        # Reading the data and creating the graph object
        self.read_N(os.path.join(data_folder,"data_N.csv"))
        self.read_C(os.path.join( data_folder,"data_C.csv"))
        self.read_baseCoverage(os.path.join(data_folder,"data_W.csv"))
        self.data_loaded = True   
    
    def solve(self):
        '''
        The solve method will run the algorithm and return a feasible solution.
        '''
        if not self.data_loaded:
            raise Exception("Data must be loaded before running solve.")
        return None
    
    def read_N(self, filepath):   
        with open(filepath, "r") as csvfile:
            reader = csv.reader(csvfile)
            count = 0
            for row in reader:
                if count == 0: # header row
                    count = 1
                else:
                    self.fixed_cost['v'+row[0]] = float(row[2])
                    if row[1] == "s": # Special required node
                        self.graph.add_T('v'+row[0])
                    elif row[1] == "P": # Can be visited
                        self.graph.add_V('v'+row[0])
                    elif row[1] == "V": # Must be visited
                        self.graph.add_T('v'+row[0])
                    else:
                        raise Exception(f"Unknown location type in N: {row[1]}")
        
    def read_C(self, filepath): 
        with open(filepath, "r") as csvfile:
            reader = csv.reader(csvfile)
            count = 0
            for row in reader:
                if count == 0: # header row
                    row_keys = row[1:]
                    count = 1
                else:
                    for col in range(len(row)-1):
                        if float(row[col+1]) < 0: # We couldn't get a distance/duration
                            edge = ('v'+row[0],'v'+row_keys[col])
                            self.graph.add_edge(edge, np.inf) # Want the cost to be really high
                        else:
                            edge = ('v'+row[0],'v'+row_keys[col])
                            self.graph.add_edge(edge, float(row[col+1])+self.fixed_cost['v'+row[0]]/2 + self.fixed_cost['v'+row_keys[col]]/2)
    
    def read_coverage(self, filepath):
        with open(filepath, "r") as csvfile:
            reader = csv.reader(csvfile)
            count = 0
            for row in reader:
                if count == 0: # header row
                    count = 1
                else:
                    self.graph.add_W('w'+row[0])
                    if len(row[3]) > 0: # This is the desired coverage
                        self.graph.add_coverage('w'+row[0],['v'+i for i in row[3].split("-")])
    
    def read_baseCoverage(self, filepath):
        with open(filepath, "r") as csvfile:
            reader = csv.reader(csvfile)
            count = 0
            for row in reader:
                if count == 0: # header row
                    count = 1
                else:
                    self.graph.add_W('w'+row[0])
                    if len(row[4]) < 2: # This is the desired coverage
                        raise Exception(f'Location {w} is not covered by two dropbox locations')
                    else:
                        self.graph.add_coverage('w'+row[0],['v'+i for i in row[4].split("-")])
    
    def check_feasibility(self):
        '''
        This will check feasibility of the tour
        
        1) Includes all nodes of T
        2) Covers all nodes of W
        '''
        if len(self.graph.T.difference(self.tour)) > 0:
            return False
    
        cov = set()
        for v in self.tour:
            cov = cov.union(self.graph.get_coverage(v))
        
        return len(cov) == len(self.graph.W)
    
        
        