'''
This implements the robus participation covering tour problem 
formulation of the dropbox problem (heuristic formulation)

@author: Adam Schmidt, apschmidt2@wisc.edu
'''
from itertools import combinations
import numpy as np
from timeit import default_timer as timer
from gurobipy import *
from collections import defaultdict
import heapq
from CTPish import SchmidtAlgorithm1 as SchmidtAlgorithm4
import csv

class RPCTP_heuristic_lagrangian:
    def __init__(self,instance,data):
        self.folder = data
        self.instance = instance
        self.solution_time = np.inf
        self.optimal_tour = None

    def build_CTP_double(self):
        '''
        This solve the double CTP problem to optimality
       
        lambdas is a dictionary that includes the weights on the participation
        
        '''
        if self.instance is None:
            raise Exception('The RPCTP instance is not loaded')

        self.model = Model()
        self.model.Params.OutputFlag = 0
        self.model.Params.lazyConstraints = 1
#         self.model.Params.TimeLimit = 3600*4
        self.model.update()
        
        ######## DECISION VARIABLES #############
        X = {}
        for i,j in self.instance.get_arcs():
            X[i,j] = X[j,i]= self.model.addVar(vtype=GRB.BINARY, name='x')# Tour variables
        
#         X = self.model.addVars(self.instance.get_arcs(), name="x", vtype = GRB.BINARY) # Tour variables
        Y = self.model.addVars(self.instance.get_N(), name="y", vtype = GRB.BINARY) # Coverage Variables
        self.model._Xvars = X
        self.model._Yvars = Y
        
        ######## CONSTRAINTS #############
        # Must visit nodes in T
        for i in self.instance.get_T():
            self.model.addConstr(Y[i] == 1)
        
        # Flow in = Flow out
        for j in self.instance.get_N():
            # Note that instance.get_arcs(j) returns all edges (i,k) such that 
            # either i = j or k = j (this avoids double counting)
#             self.model.addConstr(quicksum(X[i,k] for i,k in self.instance.get_arcs(j)) == 2*Y[j])
            self.model.addConstr(quicksum(X[i,j] for i in self.instance.get_N() if i != j) == 2*Y[j])
        
        # Subtour elimination constraints
        # Added with lazy constraints
        
        for k in self.instance.get_W():
            self.model.addConstr(quicksum(Y[i] for i in self.instance.get_baseCoverage(k)) >= 2)
            
        
        self.model.update()
        self.model.Params.OutputFlag = 0
        self.model.Params.lazyConstraints = 1
#         self.model.Params.TimeLimit = 3600*4
        self.model.update()
        
    def subtour(self,arcs):
        '''
        This function will find subtours within the given arcs. Will return the 
        nodes in the order in which they are visited within the subtour (ignoring 
        return to starting node).
        '''
        visited = {}
        visited_nodes = list(set([i for i,j in arcs]).union(set([j for i,j in arcs])))
        openset = set()
        for i in self.instance.get_N():
            visited[i]=False
            if i in visited_nodes: # Need this as we may not visit all
                openset.add(i)
        cycles = []
        lengths = []
        neighbors = defaultdict(lambda: [])
        for a,b in arcs:
            neighbors[a].append(b)
            neighbors[b].append(a)
        while True:
            current = openset.pop()
            # start BFS for a cycle at the node current
            thiscycle = [current]
            while True:
                visited[current] = True
                curneighbors = [a for a in neighbors[current] if not visited[a]]
                if len(curneighbors) == 0:
                    break
                current = curneighbors[0]
                openset.remove(current)
                thiscycle.append(current)
            cycles.append(thiscycle)
            lengths.append(len(thiscycle))
            if len(openset) < 1:
                break
        return cycles
    
               
    def solve(self,pareto = 'complete', parteo_param = 0.01):
        '''
        This will enumerate the approximate the frontier
        '''
        
        def mycallback(model,where):
            if where == GRB.callback.SIMPLEX:
                # maybe query something
                pass
            if where == GRB.callback.MIP:
                # maybe query something
                pass
            if where == GRB.callback.MIPNODE:
                # maybe add user cuts, or set a heuristic solution
                pass
            if where == GRB.callback.MIPSOL:
                # ADDING LAZY CUTS
                
                # We are finding subtours and removing all combinations of that subset
                # https://www.math.unipd.it/~luigi/courses/metmodoc1819/m08.01.TSPexact.en.pdf
                
                # make a list of edges selected in the solution
                vals = self.model.cbGetSolution(self.model._Xvars)
                selected = tuplelist((i, j) for i, j in model._Xvars.keys() # These are the arcs
                                        if vals[i, j] > 0.5)
                # find a cycle in the selected edge list
                tours = self.subtour(selected)
                
                l = 0
                for tour in tours:
                    # First we must check if the tour contains all nodes of T
                    if len(tour) > 1 and len(self.instance.get_T().difference(tour)) > 0:
                        VminusS = self.instance.get_N().difference(tour)
                        
                        # This is the first formulation for the constraints
                        expr = 0 # Adds the variables
                        for vi in tour:
                            for vj in VminusS:
                                expr += model._Xvars[self.instance.get_edge(vi,vj)]
                                
                        for vt in tour:
                            model.cbLazy(expr >= 2*model._Yvars[vt]) # Adding the cut
    
        
        start = timer()
        rmax = max( [(sum([self.instance.get_participationComponent(w,i) for i in self.instance.get_N()]) + self.instance.get_participationComponent(w,'vOther'))/( self.instance.get_participationComponent(w,'vNone')+self.instance.get_participationComponent(w,'vOther')+sum([self.instance.get_participationComponent(w,i) for i in self.instance.get_N()]))  for w in self.instance.get_Wpart()] )
        r = 0.63
        self.build_CTP_double()
        
        lambdas = defaultdict(lambda:0)
        total_fixed_cost = sum([self.instance.get_fixedcost(n) for n in self.instance.get_N()])
        # Running K iterations
        K = 50
        for k in range(K):
            print(r)
            self.model.setObjective(quicksum((self.instance.get_cost(i,j)+(r-1)*sum([lambdas[w]*self.instance.get_participationComponent(w,i) for w in self.instance.get_Wpart()])/2)*self.model._Xvars[i,j] for i,j in self.model._Xvars))
            self.model.update()
            self.model.optimize(mycallback) # Solving the optimization model
            
            # Getting the selected nodes
            solution_y = self.model.getAttr('x', self.model._Yvars)
            selected_y = set([n for n in solution_y if solution_y[n] > 0.5])
            
            tour,cost = self.get_tour()
#             p  =self.get_participation(tour[:-1])
#             if p != p_last and cost != c_last:
            self.print_solution(tour)
#                 p_last = p
#                 c_last = cost
            # Updating the lambdas
#             if k == 0:
#                 r = 1-self.get_participation(tour[:-1])
#             r = r+(rmax-r)/(K-k)
            for w in self.instance.get_Wpart():
                s = sum(self.instance.get_participationComponent(w,n) for n in selected_y)
                Aw = (self.instance.get_participationComponent(w,'vOther')+ s) / (self.instance.get_participationComponent(w,'vNone') + 
                        self.instance.get_participationComponent(w,'vOther')+s)
                
#                 if r-Aw > 0:
#                     print(w,r,Aw, lambdas[w], max(0,lambdas[w] + total_fixed_cost*(1/(k+1))*(r-Aw)))
                
                lambdas[w] = max(0,lambdas[w] + total_fixed_cost*(1/(k+1))*(r-Aw))
                
        print(start-timer())
    def get_tour(self):
        '''
        This will take a solved model and find the solution. Will check to 
        ensure that an optimal solution have been found. If not, returns best
        incumbent solution
        '''
        try:
            solution_x = self.model.getAttr('x', self.model._Xvars)
        except:
            self.optimal = False
            return [], np.inf
        
        selected = [(i,j) for (i,j) in self.model._Xvars if solution_x[i,j] > 0.5]      
        
        sol = self.subtour(selected)[0]
        sol+=[sol[0]]
        self.optimal_cost = self.tour_cost(sol)
        if self.model.status == GRB.OPTIMAL:
            self.optimal = True
            return sol, self.optimal_cost
        print('Optimal solution not found', self.model.status)
        self.optimal = False
    
        return sol, self.optimal_cost
    
    def tour_cost(self,tour):
        if len(tour) == 0:
            return 0
        if len(tour) <= 2:
            return self.instance.get_fixedcost(tour[0])
        cost = 0
        for i in range(1,len(tour)):
            cost +=  self.instance.get_cost(tour[i-1],tour[i])
        
        return cost
    
    
    def get_fixedcost(self,nodes):
        '''
        Given the tour nodes, calculated the fixed cost of the nodes
        '''
        c = 0
        for n in nodes:
            c += self.instance.get_fixedcost(n)
        return c  
                
    def get_participation(self,selected,type = 'worstcase'):
        '''
        Calculates the estimated participation of each node W
        
        type:
           a) 'worstcase' find the worst case participation
           b) 'all' find the participation of each node W
        '''
        selected = set(selected) # Making sure no duplicates
        if type == 'worstcase':
            p = 0
            for k in self.instance.get_Wpart():
                phat = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
                if phat > p:
                    p= phat
        elif type == 'all':
            p = {}
            for k in self.instance.get_Wpart():
                p[k] = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
        return p      

    def print_solution(self,tour):
        print(1-self.get_participation(tour[:-1]),",", self.optimal_cost,",",tour,",",len(tour)-1)
     
