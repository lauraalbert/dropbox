from RPCTP import RPCTP
from RPCTP2 import RPCTP2
from RPCTP_heuristic import RPCTP_heuristic
from RPCTP_heuristic_backwards import RPCTP_heuristic2
from read_data import DropboxInstance
from SetCover import SetCover
from RPCTP_heuristic_value import RPCTP_heuristic_value
from RPCTP_heuristic_value2 import RPCTP_heuristic_value2
from RPCTP_heuristic_lagrangian import RPCTP_heuristic_lagrangian
from RPCTP_heuristic_montecarlo import RPCTP_heuristic_montecarlo


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# This is for the exact method
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#####
# TEST 1
#####      
# x = DropboxInstance('Data/Test1')
# y = RPCTP(x) 
# z = y.solve(pareto = 'complete', parteo_param = (1,0.01))

#####
# TEST 2a
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP(x) 
# z = y.solve(pareto = 'one', parteo_param = 0.5)

#####
# TEST 2b
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP(x) 
# z = y.solve(pareto = 'complete', parteo_param =  (1,0.001))

#####
# TEST 3b
#####      
# x = DropboxInstance('Data/Test3')
# y = RPCTP(x) 
# z = y.solve(pareto = 'complete', parteo_param =  (1,0.001))

#####
# TEST MILWAUKEE
#####      
# x = DropboxInstance('Data/Milwaukee')
# y = RPCTP(x) 
# z = y.solve(pareto = 'complete', parteo_param =  (1,0.008))

#####
# TEST MILWAUKEE - EQUALITY
#####      
# for i in ['0.9','1.0','1.1','1.2','1.3','1.4']:
#     x = DropboxInstance(f'Data/Milwaukee - Equality ({i})')
#     y = RPCTP(x) 
#     z = y.solve(pareto = 'complete', parteo_param =  (1,0.008))


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# This is for the heuristic value method
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#####
# TEST 1
#####      
# x = DropboxInstance('Data/Test1')
# y = RPCTP_heuristic_value(x,'Data/Test1') 
# z = y.solve(pareto = 'complete', parteo_param = 0.0001)

#####
# TEST 2a
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic_value(x) 
# z = y.solve(pareto = 'one', parteo_param = 0.5)

#####
# TEST 2b
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic_value(x,'Data/Test2') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST 3b
#####      
# x = DropboxInstance('Data/Test3')
# y = RPCTP_heuristic_value(x,'Data/Test3') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST MILWAUKEE
#####      
# x = DropboxInstance('Data/Milwaukee')
# y = RPCTP_heuristic_value(x,'Data/Milwaukee') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

# #####
# # TEST MILWAUKEE - EQUALITY
# ##### 
soln_times = []     
for i in ['0.9','1.0','1.1','1.2','1.3','1.4']:
    x = DropboxInstance(f'Data/Milwaukee - Equality ({i})')
    y = RPCTP_heuristic_value(x,f'Data/Milwaukee - Equality ({i})') 
    z = y.solve(pareto = 'complete', parteo_param =  0.001)
    soln_times.append(z)
print(soln_times)
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# This is for the heuristic value 2 method
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#####
# TEST 1
#####      
# x = DropboxInstance('Data/Test1')
# y = RPCTP_heuristic_value2(x,'Data/Test1') 
# z = y.solve(pareto = 'complete', parteo_param = 0.00001)

#####
# TEST 2a
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic_value2(x) 
# z = y.solve(pareto = 'one', parteo_param = 0.5)

#####
# TEST 2b
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic_value2(x,'Data/Test2') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST 3b
#####      
# x = DropboxInstance('Data/Test3')
# y = RPCTP_heuristic_value2(x,'Data/Test3') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST MILWAUKEE
#####      
# x = DropboxInstance('Data/Milwaukee')
# y = RPCTP_heuristic_value2(x,'Data/Milwaukee') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

# #####
# # TEST MILWAUKEE - EQUALITY
# #####      
# for i in ['0.9','1.0','1.1','1.2','1.3','1.4']:
#     x = DropboxInstance(f'Data/Milwaukee - Equality ({i})')
#     y = RPCTP_heuristic_value2(x,f'Data/Milwaukee - Equality ({i})') 
#     z = y.solve(pareto = 'complete', parteo_param =  0.001)



# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# This is for the heuristic_montecarlo method
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#####
# TEST 1
#####      
# x = DropboxInstance('Data/Test1')
# y = RPCTP_heuristic_montecarlo(x,'Data/Test1') 
# z = y.solve(pareto = 'complete', parteo_param = 0.001)

#####
# TEST 2a
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic_montecarlo(x) 
# z = y.solve(pareto = 'one', parteo_param = 0.5)

#####
# TEST 2b
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic_montecarlo(x,'Data/Test2') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST 3b
#####      
# x = DropboxInstance('Data/Test3')
# y = RPCTP_heuristic_montecarlo(x,'Data/Test3') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST MILWAUKEE
#####      
# x = DropboxInstance('Data/Milwaukee')
# y = RPCTP_heuristic_montecarlo(x,'Data/Milwaukee') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

# #####
# # TEST MILWAUKEE - EQUALITY
# #####      
# for i in ['0.9','1.0','1.1','1.2','1.3','1.4']:
#     x = DropboxInstance(f'Data/Milwaukee - Equality ({i})')
#     y = RPCTP_heuristic_montecarlo(x,f'Data/Milwaukee - Equality ({i})') 
#     z = y.solve(pareto = 'complete', parteo_param =  0.001)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# This is for the heuristic_lagrangian method
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#####
# TEST 1
#####      
# x = DropboxInstance('Data/Test1')
# y = RPCTP_heuristic_lagrangian(x,'Data/Test1') 
# z = y.solve(pareto = 'complete', parteo_param = 0.001)

#####
# TEST 2a
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic_lagrangian(x) 
# z = y.solve(pareto = 'one', parteo_param = 0.5)

#####
# TEST 2b
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic_lagrangian(x,'Data/Test2') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST 3b
#####      
# x = DropboxInstance('Data/Test3')
# y = RPCTP_heuristic_lagrangian(x,'Data/Test3') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST MILWAUKEE
#####      
# x = DropboxInstance('Data/Milwaukee')
# y = RPCTP_heuristic_lagrangian(x,'Data/Milwaukee') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

# #####
# # TEST MILWAUKEE - EQUALITY
# #####      
# for i in ['0.9','1.0','1.1','1.2','1.3','1.4']:
#     x = DropboxInstance(f'Data/Milwaukee - Equality ({i})')
#     y = RPCTP_heuristic_lagrangian(x,f'Data/Milwaukee - Equality ({i})') 
#     z = y.solve(pareto = 'complete', parteo_param =  0.001)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# This is for the heuristic method
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#####
# TEST 1
#####      
# x = DropboxInstance('Data/Test1')
# y = RPCTP_heuristic(x,'Data/Test1') 
# z = y.solve(pareto = 'complete', parteo_param = 0.001)

#####
# TEST 2a
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic(x) 
# z = y.solve(pareto = 'one', parteo_param = 0.5)

#####
# TEST 2b
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic(x,'Data/Test2') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST 3b
#####      
# x = DropboxInstance('Data/Test3')
# y = RPCTP_heuristic(x,'Data/Test3') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST MILWAUKEE
#####      
# x = DropboxInstance('Data/Milwaukee')
# y = RPCTP_heuristic(x,'Data/Milwaukee') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)




# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# This is for the heuristic2 method
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#####
# TEST 1
#####      
# x = DropboxInstance('Data/Test1')
# y = RPCTP_heuristic2(x,'Data/Test1') 
# z = y.solve(pareto = 'complete', parteo_param = 0.001)

#####
# TEST 2a
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic2(x) 
# z = y.solve(pareto = 'one', parteo_param = 0.5)

#####
# TEST 2b
#####      
# x = DropboxInstance('Data/Test2')
# y = RPCTP_heuristic2(x,'Data/Test2') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST 3b
#####      
# x = DropboxInstance('Data/Test3')
# y = RPCTP_heuristic2(x,'Data/Test3') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST MILWAUKEE
#####      
# x = DropboxInstance('Data/Milwaukee')
# y = RPCTP_heuristic2(x,'Data/Milwaukee') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Set cover method
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#####
# TEST 1
#####      
# x = DropboxInstance('Data/Test1')
# y = SetCover(x,'Data/Test1') 
# z = y.solve(pareto = 'complete', parteo_param = 0.001)

#####
# TEST 2a
#####      
# x = DropboxInstance('Data/Test2')
# y = SetCover(x) 
# z = y.solve(pareto = 'one', parteo_param = 0.5)

#####
# TEST 2b
#####      
# x = DropboxInstance('Data/Test2')
# y = SetCover(x,'Data/Test2') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST 3b
#####      
# x = DropboxInstance('Data/Test3')
# y = SetCover(x,'Data/Test3') 
# z = y.solve(pareto = 'complete', parteo_param =  0.001)

#####
# TEST MILWAUKEE
#####      
# x = DropboxInstance('Data/Milwaukee')
# y = SetCover(x) 
# z = y.solve(pareto = 'complete', parteo_param =  (1,0.001))

# #####
# # TEST MILWAUKEE - EQUALITY
# #####      
# for i in ['1.4']:
#     x = DropboxInstance(f'Data/Milwaukee - Equality ({i})')
#     y = SetCover(x) 
#     z = y.solve(pareto = 'complete', parteo_param = (1,0.001))


