'''
This implements the robust participation covering tour problem 
formulation of the dropbox problem (heuristic formulation)

This differs from Heuristic 1 in the following ways:
1) Instead of adding least cost sway, we add the one with the least cost/value

@author: Adam Schmidt, apschmidt2@wisc.edu
'''
from itertools import combinations
import numpy as np
from timeit import default_timer as timer
from gurobipy import *
from collections import defaultdict
import heapq
from CTPish import SchmidtAlgorithm1 as SchmidtAlgorithm4
import csv
import random

class RPCTP_heuristic_montecarlo:
    def __init__(self,instance,data):
        self.folder = data
        self.instance = instance
        self.solution_time = np.inf
        self.optimal_tour = None


    def get_tour_length(self):
        '''
        Expects an ordered list where the final element is the first element
        '''
        tour = self.optimal_tour
        if len(tour) == 0:
            return 0
        if len(tour) <= 2:
            return self.instance.get_fixedcost(tour[0])
        cost = 0
        for i in range(1,len(tour)):
            cost +=  self.instance.get_cost(tour[i-1],tour[i])
        
        return cost
    
    def get_optimal_tour(self,nodes):
#           https://www.gurobi.com/documentation/9.1/examples/tsp_py.html
        if len(nodes) == 1:
            n = nodes.pop()
            return [n,n]
        if len(nodes) == 2:
            tmp = list(nodes)
            t = tmp + [tmp[0]]
            return t
        
        # Callback - use lazy constraints to eliminate sub-tours
        def subtourelim(model, where):
            if where == GRB.Callback.MIPSOL:
                # make a list of edges selected in the solution
                vals = model.cbGetSolution(model._vars)
                selected = tuplelist((i, j) for i, j in model._vars.keys()
                                        if vals[i, j] > 0.5)
                # find the shortest cycle in the selected edge list
                tours = subtour(selected)
                for tour in tours:
                    if len(tour) < len(nodes):
                        # add subtour elimination constr. for every pair of cities in tour
                        model.cbLazy(quicksum(model._vars[i, j]
                                                 for i, j in combinations(tour, 2))
                                     <= len(tour)-1)
        
        
        # Given a tuplelist of edges, find the shortest subtour
        def subtour(edges):
            cycles = []
            unvisited = set(nodes)
            while unvisited:  # true if list is non-empty
                thiscycle = []
                neighbors = list(unvisited)
                while neighbors:
                    current = neighbors[0]
                    thiscycle.append(current)
                    unvisited.remove(current)
                    neighbors = [j for i,j in edges if i == current and j in unvisited]
                cycles.append(thiscycle)
            return cycles

        m = Model()
        m.Params.OutputFlag = 0
        # Create variables
        vars = {}
        for i in nodes:
            for j in nodes:
                if j in nodes and i < j:
                    vars[i,j] = vars[j,i]= m.addVar(obj=self.instance.get_cost(i,j)-self.instance.get_fixedcost(i)/2-self.instance.get_fixedcost(j)/2, vtype=GRB.BINARY, name='x')
        
        # Add degree-2 constraint
        for i in nodes:
            m.addConstr(sum(vars[i,j] for j in nodes if i != j) == 2)

        # Solving 
        m._vars = vars
        m.Params.lazyConstraints = 1
        m.update()
        m.optimize(subtourelim) #
        vals = m.getAttr('x', vars)
        selected = tuplelist((i, j) for i, j in m._vars if vals[i, j] > 0.5)
        tour = subtour(selected)[0]
        tour += [tour[0]]
#         print()
#         print('Solution found',tour)
        if len(tour) != len(nodes)+1:
            print(nodes)
            print(tour)
            print(subtour(selected))
            print(selected)
            raise Exception(f'Error finding tour, nodes {set(nodes).difference(tour)} not included')
        
        return tour

         
    
    def feasible(self,rprime):
        # Check if participation feasible
        if self.get_participation()> rprime  and abs(self.get_participation()-rprime) > 0.00001:
            print(f"Participation of {self.get_participation()} is not smaller than {rprime}")
            return False
            
        # Check if double coverage feasbile
        nodes = set(self.optimal_tour)
        for k in self.instance.get_W():
            if len(nodes.intersection(self.instance.get_baseCoverage(k)))<2:
                print(f"Node {k} not double covered for rprime {rprime}")
                print(nodes)
                print(self.instance.get_baseCoverage(k))
                print(nodes.intersection(self.instance.get_baseCoverage(k)))
                return False
        
        return True
    
    def get_fixedcost(self,nodes):
        '''
        Given the tour nodes, calculated the fixed cost of the nodes
        '''
        c = 0
        for n in nodes:
            c += self.instance.get_fixedcost(n)
        return c  
                
    def get_participation(self,selected,type = 'worstcase'):
        '''
        Calculates the estimated participation of each node W
        
        type:
           a) 'worstcase' find the worst case participation
           b) 'all' find the participation of each node W
        '''
        selected = set(selected) # Making sure no duplicates
        if type == 'worstcase':
            p = 0
            for k in self.instance.get_Wpart():
                phat = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
                if phat > p:
                    p= phat
        elif type == 'all':
            p = {}
            for k in self.instance.get_Wpart():
                p[k] = self.instance.get_participationComponent(k,'vNone')/(self.instance.get_participationComponent(k,'vNone') + 
                                    self.instance.get_participationComponent(k,'vOther')+
                                    sum(self.instance.get_participationComponent(k,n) for n in selected))
        return p   
    
    def solve(self,pareto = 'complete', parteo_param = -1):
        '''
        We randomize subsets of drop boxes and then find the optimal tour
        over the nodes
        '''
        
        K = 1000
        
        for k in range(K):
            number = random.sample(range(3,len(self.instance.get_N())+1), 1)[0]
            sample = set(random.sample(self.instance.get_N(), number) )
            valid = True
            ## Checking if feasible - Must meet double coverage
            for w in self.instance.get_W():
                if len(sample.intersection(self.instance.get_baseCoverage(w))) < 2:
                    valid = False
                    break # Sample is not feasible
            if valid:
                # It is now feasible and we want to find the solution
                ## Finding cost
                self.optimal_tour = self.get_optimal_tour(sample)
                self.optimal_cost = self.get_tour_length()
                self.print_solution(self.optimal_tour)
           
    
    
    def print_solution(self,tour):
#         print(1-self.get_participation(tour[:-1]),",", self.optimal_cost,",",tour,",",len(tour)-1)
        print(1-self.get_participation(tour[:-1]),",", self.optimal_cost)
     

