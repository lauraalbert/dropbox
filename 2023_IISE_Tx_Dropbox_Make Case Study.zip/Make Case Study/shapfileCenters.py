# import shapefile
# 
# shape = shapefile.Reader('../../Milwaukee Case Study Raw Data/ward2012/ward.shp')
# 
# print(shape)

# ------------------------------
# Milwaukee
# ------------------------------

# # Census tracts
# import geopandas as gpd
# shapefile = gpd.read_file('../../Milwaukee Case Study Raw Data/Census_Tracts/Census_Tracts.shp')
# # shapefile = shapefile.to_crs(epsg=4326)
# print(shapefile)
#  
# shapefile['center'] = shapefile['geometry'].centroid.to_crs(epsg=4326) #.coords
# shapefile['lat'] = shapefile['center'].y
# shapefile['long'] = shapefile['center'].x
# print(shapefile[['lat','long']] )
#  
# shapefile.to_csv('../../Milwaukee Case Study Raw Data/tractCenters.csv')


# Census block groups
import geopandas as gpd
shapefile = gpd.read_file('../../Milwaukee Case Study Raw Data/Block Group shapefile/Census_Block_groups.shp')
# shapefile = shapefile.to_crs(epsg=4326)
print(shapefile)
 
shapefile['center'] = shapefile['geometry'].centroid.to_crs(epsg=4326) #.coords
shapefile['lat'] = shapefile['center'].y
shapefile['long'] = shapefile['center'].x
print(shapefile[['lat','long']] )
 
shapefile.to_csv('../../Milwaukee Case Study Raw Data/blockgroupCenters.csv')

# Voter wards

# import geopandas as gpd
# shapefile = gpd.read_file('../../Milwaukee Case Study Raw Data/ward2012/ward.shp')
# # shapefile = shapefile.to_crs(epsg=4326)
# print(shapefile)
# 
# shapefile['center'] = shapefile['geometry'].centroid.to_crs(epsg=4326) #.coords
# shapefile['lat'] = shapefile['center'].y
# shapefile['long'] = shapefile['center'].x
# print(shapefile[['lat','long']] )
# 
# shapefile.to_csv('../../Milwaukee Case Study Raw Data/votingWardCenters.csv')


# ------------------------------
# Mequon
# ------------------------------

# 
# import geopandas as gpd
# shapefile = gpd.read_file('../../Mequon Case Study Raw Data/Mequon Voting Wards/Wards.shp')
# # shapefile = shapefile.to_crs(epsg=4326)
# print(shapefile)
# 
# shapefile['center'] = shapefile['geometry'].centroid.to_crs(epsg=4326) #.coords
# shapefile['lat'] = shapefile['center'].y
# shapefile['long'] = shapefile['center'].x
# print(shapefile[['lat','long']] )
# 
# shapefile[['JVTD2','lat','long']].to_csv('../../Mequon Case Study Raw Data/votingWardCenters.csv')

