import requests
import pandas as pd
import csv
import math
import json
# Which location are we making it for?
loc = 'Mequon' # 'Milwaukee' #

# travelMode can be either driving, walking, or transit
travelMode = 'driving'
  
# timeUnit can be minute or second
timeUnit = 'minute'
    
# HTTP POST Request URL
url = 'https://dev.virtualearth.net/REST/v1/Routes/DistanceMatrix?key=AtWNtrHV5F1mwktqPg7LB8iV1On-Qt8YLhjdqHbI_Qlm4AG-UM_7-qwz7b0n812Q'
 
    
# -----------------------------------------------
# Building the origins and destinations table
# -----------------------------------------------

# Reading in all the locations

locations = {}
ids = []
with open(f'../../{loc} Case Study Raw Data/potential_db_locations.csv', 'r', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
    count = 0
    for row in spamreader:
        if count > 0:
            row[1] = float(row[1])
            row[2] = float(row[2])
            locations[(row[1],row[2])] = row[0]
            ids.append(row[0])
        else: 
            count = 1

locations_latlong = list(locations.keys())
# -----------------------------------------------
# Requesting the distance
# -----------------------------------------------
distance_matrix = {}
duration_matrix = {}

# Need to split into quarters as to not exceed limit

for h1 in range(math.ceil(len(ids)/50)): # Which half for the origins
    for h2 in range(math.ceil(len(ids)/50)): # Which half for the destinations
        # Creating the POST body
        bod = {
        "origins": [{'latitude': x[0], "longitude": x[1]} for x in locations_latlong[50*h1:50*(h1+1)]],
        "destinations": [{'latitude': x[0], "longitude": x[1]} for x in locations_latlong[50*h2:50*(h2+1)]],
        "travelMode": travelMode,
        "timeUnit": timeUnit,
        'distanceUnit': 'mile' 
        }
        
        
        r = requests.post(url, data=json.dumps(bod))
        travels = r.json()['resourceSets'][0]['resources'][0]['results']
        origins =  r.json()['resourceSets'][0]['resources'][0]['origins']
        destinations =  r.json()['resourceSets'][0]['resources'][0]['destinations']
        
        # Adding to the distance matrix
        for diction in travels:
            o = origins[diction['originIndex']]
            d = destinations[diction['destinationIndex']]
            o_ID = locations[o['latitude'],o['longitude']]
            d_ID = locations[d['latitude'],d['longitude']]
            distance_matrix[o_ID,d_ID] = diction['travelDistance']
            duration_matrix[o_ID,d_ID] = diction['travelDuration']
            
with open(f'dropbox_{travelMode}_distance_matrix.csv', 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    spamwriter.writerow(["ID (From\To)"] + ids)
    for i in ids:
        spamwriter.writerow([i]+[distance_matrix[i,j] for j in ids])

with open(f'dropbox_{travelMode}_duration_matrix.csv', 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    spamwriter.writerow(["ID (From\To)"] + ids)
    for i in ids:
        spamwriter.writerow([i]+[duration_matrix[i,j] for j in ids])