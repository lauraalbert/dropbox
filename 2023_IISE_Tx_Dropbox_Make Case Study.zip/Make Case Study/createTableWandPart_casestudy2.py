'''
This will create the data_W table for the case study.

@author: apschmidt2
'''
import csv, os
import pandas as pd
from collections import defaultdict
import numpy as np

# Which location are we making it for?
loc = 'Milwaukee' # 'Milwaukee' #


'''
The logic used is as follows:

Base Coverage:
A dropbox location covers an individual if at least one of the following is true
    a) The dropbox is within 15 minutes driving
    b) The dropbox is within 30 minutes transit
    c) The dropbox is within 15 minutes walking
    d) The dropbox is within 4 miles (road distance) to account for data quality
    issues and biking

Desired Coverage: 1/2 the values used within the base coverage

Each of these times are computed from the center of the block group or census
track considered.
'''
  
# These are the potential dropbox locations
db_locations = []
with open("C:/Users/apschmidt/Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/potential_db_locations.csv",'r') as csvfile:
    reader = csv.reader(csvfile, delimiter=',', quotechar='|')
    count = 0
    for row in reader:
        if count == 0:
            count += 1
        else:
            db_locations.append(row[0])

# -----------------------------------------------
# We first read in the locations and store the travel times
# -----------------------------------------------
BG_traveltimes = defaultdict(lambda: defaultdict(dict)) # Will store the travel times for each block group to each dropbox location
Tract_traveltimes = defaultdict(lambda: defaultdict(dict)) # Will store the travel times for each census tract to each dropbox location
BG_traveldistances =  defaultdict(lambda: defaultdict(dict)) # Will store the travel distance for each block group to each dropbox location
center_directory = 'C:/Users/apschmidt/Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/Census Data' 
duration_directory = 'C:/Users/apschmidt/Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/Distance Tables'


# First, we deal with the block groups. This reads in the block groups that are
# within the city limits and within milwaukee county
with open(os.path.join(center_directory, 'milwaukee_block_group_list.txt'), 'r') as f:
    output = f.readlines()
    list_of_blockgroups = [line.rstrip() for line in output]
    
# Now, reading in the file to get the FIPS code
df = pd.read_csv(os.path.join(center_directory, 'blockgroupCenters.csv'))
# key = OBJECTID, value = FIPS code
FIPS_codes = pd.Series(df.FIPS_BLKGR.values,index=df.OBJECTID).to_dict()


# Now, we read in the distance between each drop box location
for tm in ['driving','walking','transit']:
    with open(os.path.join(duration_directory,f'voterblockgroup_{tm}_duration_matrix.csv'), 'r', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
        count = 0
        for row in spamreader:
            if count == 0:
                count += 1
                dbs = row # Stores the dropboxes (plus the 0th index)
            else:
                vl = int(row[0])# Voter location
                for i in range(1,len(row)):
                    if float(row[i]) < 0:
                        row[i] = 9999
                    BG_traveltimes[FIPS_codes[vl]][dbs[i]][tm] = float(row[i])
    
# Reading in the road distance
with open(os.path.join(duration_directory,f'voterblockgroup_driving_distance_matrix.csv'), 'r', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
        count = 0
        for row in spamreader:
            if count == 0:
                count += 1
                dbs = row # Stores the dropboxes (plus the 0th index)
            else:
                vl = int(row[0])# Voter location
                for i in range(1,len(row)):
                    if float(row[i]) < 0:
                        row[i] = 9999
                    BG_traveldistances[FIPS_codes[vl]][dbs[i]] = float(row[i])

# We now repeat for the census tracts.

# Now, reading in the file to get the FIPS code
df = pd.read_csv(os.path.join(center_directory, 'tractCenters.csv'))
# key = OBJECTID, value = FIPS code
FIPS_codes = pd.Series(df.FIPS_TRACT.values,index=df.OBJECTID).to_dict()


# Now, we read in the distance between each drop box location
for tm in ['driving','walking','transit']:
    with open(os.path.join(duration_directory,f'votertract_{tm}_duration_matrix.csv'), 'r', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
        count = 0
        for row in spamreader:
            if count == 0:
                count += 1
                dbs = row # Stores the dropboxes (plus the 0th index)
            else:
                vl = int(row[0])# Voter location
                for i in range(1,len(row)):
                    if float(row[i]) < 0:
                        row[i] = 9999
                    Tract_traveltimes[FIPS_codes[vl]][dbs[i]][tm] = float(row[i])



#########
# Coverage
########
'''
We define coverage sets for each block group locations. Each location should
be covered equally.
'''
                    
def find_basecoverage(FIPS_BLOCK_GROUP):
    '''
    This takes in a row of our data frame and determines which of the 
    drop box locations will provide the base coverage
    '''
    covering_locations = []
    
    
    # Can only look at transit and walking times
    for db in db_locations:
        count = 0
        # Residence
        if BG_traveltimes[FIPS_BLOCK_GROUP][db]['walking'] <= 15:
            count += 1
        # Residence
        if BG_traveltimes[FIPS_BLOCK_GROUP][db]['transit'] <= 30:
            count += 1
        # We can check the drive time
        if BG_traveltimes[FIPS_BLOCK_GROUP][db]['driving'] <= 15:
            count += 1
        # Other
        if BG_traveldistances[FIPS_BLOCK_GROUP][db] <= 4:
            count += 1
        if count >= 2:
            covering_locations.append(db)
    if len(covering_locations) < 2:
        print(FIPS_BLOCK_GROUP)
        print(BG_traveltimes[FIPS_BLOCK_GROUP])
        print(BG_traveldistances[FIPS_BLOCK_GROUP])
        print(covering_locations)
        raise Exception('Issue')
    return '-'.join(covering_locations)
        
def find_coverage(FIPS_BLOCK_GROUP):
    '''
    This takes in a row of our data frame and determines which of the 
    drop box locations will provide the desired coverage
    '''
    covering_locations = []
    
    # Can only look at transit and walking times
    for db in db_locations:
        # Residence
        if BG_traveltimes[FIPS_BLOCK_GROUP][db]['walking'] <= 15/2:
            covering_locations.append(db)
        # Residence
        elif BG_traveltimes[FIPS_BLOCK_GROUP][db]['transit'] <= 30/2:
            covering_locations.append(db)
        # We can check the drive time
        elif BG_traveltimes[FIPS_BLOCK_GROUP][db]['driving'] <= 15/2:
            covering_locations.append(db)
        # Work location
        elif BG_traveldistances[FIPS_BLOCK_GROUP][db] <= 4/2:
            covering_locations.append(db)
            
    return '-'.join(covering_locations)

df = pd.read_csv(os.path.join(center_directory,'consolidated_blockgroup_data.csv'))
# df = df[df['18+ Population 2020'] > 0]

map_bg_pop = pd.Series(df['18+ Population 2020'].values,index=df.FIPS_BLOCK_GROUP).to_dict()

# Now writing coverage to file
with open(f'../MCTP/Data/{loc}/data_W.csv', 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    spamwriter.writerow(['ID','w','p','Ni','Nprime'])
    for bg in map_bg_pop:
#         if map_bg_pop[bg] > 0:
        spamwriter.writerow([bg,1,map_bg_pop[bg],find_coverage(bg),find_basecoverage(bg)])
    


##########
# Now, we construct an intermediary data set and save it. This will be used for
# The participation
##########


# Reading in the population, voting rate and vehicle ownership for locations
df = pd.read_csv(os.path.join(center_directory,'consolidated_blockgroup_data.csv'))
# df = df[df['18+ Population 2020'] > 0]
df = df[['FIPS_BLOCK_GROUP','18+ Population 2020', 'Nov 2020 Turnout Rate (Est)','No vehicle available']]
# df['Nov 2020 Turnout Rate (Est)'] = df['Nov 2020 Turnout Rate (Est)'].clip(lower = 50)

df = df.rename(columns = {'No vehicle available':'Vehicle Percent'})
df_someno = df[df['Vehicle Percent'] > 0].reset_index()
df['Vehicle Percent'] = 1-df['Vehicle Percent']
df['Vehicle Status'] = 'Available'
df_someno['Vehicle Status'] = 'NoneAvailable'
df = df.append(df_someno, ignore_index = True).drop(columns = ['index']).sort_values('FIPS_BLOCK_GROUP').reset_index(drop = True)

df_copy = df.copy() # We need a copy for non-workers/work outside MKE
df_copy['Work Location'] = 'No work/Outside MKE'
df_copy['FIPS_TRACT'] = 'NA'
df['Work Location'] = 'In MKE'


# Now reading in the worker location data
# First, adding column to our dataframe to store the percent of people working
# need to do this so percentages work out correctly later
df_workrate = pd.read_csv(os.path.join(center_directory,f'Residence to Workplace/flow_table.csv'))
df_workrate = df_workrate.rename(columns = {'v FIPS_BLOCK_GROUP - FIPS_TRACT ->':'FIPS_BLOCK_GROUP'})


df_workrate_mke = df_workrate.copy()
df_workrate_mke['Non MKE Worker'] = df_workrate['Total']- df_workrate[[str(i) for i in Tract_traveltimes if str(i) in df_workrate.columns]].sum(axis = 1)
df_workrate_mke = df_workrate_mke[['FIPS_BLOCK_GROUP','Non MKE Worker']]
df_copy = df_copy.merge(df_workrate_mke, on = 'FIPS_BLOCK_GROUP', how = 'left')
df_copy['Work Percent'] = df_copy['Non MKE Worker']/df['18+ Population 2020']
df_copy['Work Percent'] = df_copy['Work Percent'].clip(upper = 1)
df_copy['Percent Work Location'] = 1
df_copy = df_copy.drop(columns  = ['Non MKE Worker'])

df_workrate = df_workrate[['FIPS_BLOCK_GROUP','Total']]
df = df.merge(df_workrate, on = 'FIPS_BLOCK_GROUP', how = 'left') 
df['Work Percent'] = df['Total']/df['18+ Population 2020']    
df['Work Percent'] = df['Work Percent'].clip(upper = 1)    


# Now reading in the data from the flow table
df_flow = pd.read_csv(os.path.join(center_directory,f'Residence to Workplace/flow_table.csv'))
df_flow = df_flow.drop(columns = ['Total','Out of State'])
df_flow = df_flow.rename(columns = {'v FIPS_BLOCK_GROUP - FIPS_TRACT ->':'FIPS_BLOCK_GROUP'})
df_flow = df_flow.melt(id_vars=["FIPS_BLOCK_GROUP"], 
        var_name="FIPS_TRACT", 
        value_name="Number Workers")
df_flow["FIPS_TRACT"] = df_flow["FIPS_TRACT"].astype(np.int64)

# Only consider work location within milwaukee for simplicity
df_flow = df_flow[df_flow['FIPS_TRACT'].isin(list(Tract_traveltimes.keys()))]
df_flow = df_flow[df_flow['Number Workers']>0]

df = df.merge(df_flow, on = 'FIPS_BLOCK_GROUP', how = 'left') 
df['Percent Work Location'] = df["Number Workers"]/df['Total']
df['Percent Work Location'] = df['Percent Work Location'].clip(upper = 1)
df = df.drop(columns = ['Total'])
df = df.drop(columns = ['Number Workers'])

### Now cleaning everything up

df = df.append(df_copy,ignore_index = True)
df['Percent of BG Population'] = df['Vehicle Percent']*df['Work Percent']*df['Percent Work Location']
df['Estimated Population'] = df['Percent of BG Population']*df['18+ Population 2020']

df = df[['FIPS_BLOCK_GROUP', 'FIPS_TRACT', 'Vehicle Status', 
       'Nov 2020 Turnout Rate (Est)', 'Estimated Population']]

# df = df[df['Estimated Population'] > 0]


################################
# Now for each BG residence - Tract POW - vehicle availability pairing, 
# determining which drop boxes cover the location
################################

# First, merge the distance tables for each pairing

def find_dropboxduration(row,dropbox):
    '''
    This will create a string to represent the 
    driving/transit/walking/work-walking duration to the dropbox location
    '''
    
    s = ""
    if row['Vehicle Status'] != 'NoneAvailable':
        s += str(BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['driving'])
        s+='-'
    else:
        s+='9999-'
    s += str(BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['transit'])+'-'
    s += str(BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['walking'])+'-'
    s += str(BG_traveldistances[row['FIPS_BLOCK_GROUP']][db])+'-'
    
    if row['FIPS_TRACT'] != 'NA':
        s += str(Tract_traveltimes[row['FIPS_TRACT']][db]['walking'])
    else:
        s += '9999'
    
    
    return s
        
df['coverage_base'] = df.apply(lambda x: find_basecoverage(x['FIPS_BLOCK_GROUP']), axis=1)
df['coverage'] = df.apply(lambda x: find_coverage(x['FIPS_BLOCK_GROUP']), axis=1)
for db in db_locations:
    df[db] = df.apply(lambda x: find_dropboxduration(x,db), axis=1)

print(df)

df.to_csv('C:/Users/apschmidt/Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/Clean Data Set/20211118_data.csv',index = False)
print("Wrote intermediate file")

# Now, we are figuring out the participation parameters
def participation_params(row):
    '''
    This makes a new dataframe row that will have the necessary parameters
    for the choice model
    '''
    row_new = row.copy()
    turnout = row['Nov 2020 Turnout Rate (Est)']
    row_new['Location_ID'] = str(row['FIPS_BLOCK_GROUP'])+"-"+str(row['Vehicle Status'])+"-"+str(row['FIPS_TRACT'])
    
    num = 1
    for i,v in row_new.items():
        if i not in ['Location_ID','FIPS_BLOCK_GROUP','FIPS_TRACT','Vehicle Status','Estimated Population','coverage_base','coverage','Nov 2020 Turnout Rate (Est)']:
            drive, transit, walking, road_distance, work = v.split('-')
            row_new[i] = num/float(transit)**4+num/float(walking)**4+num/(float(road_distance)/15*60)**4
            if row['Vehicle Status'] == 'Available':
                row_new[i] = row_new[i] + num/float(drive)**4
            
            if row['FIPS_TRACT'] != 'NA':
                row_new[i] = row_new[i]+num/float(work)**4
            row_new[i] = 5*row_new[i]**(1/4)
            row_new[i] = row_new[i]*(100/float(turnout))**2
    row_new['None'] = max(100-turnout,0.0001)
    row_new['Other'] = min(turnout,100)
    return row_new

df_new = df.apply(lambda x: participation_params(x), axis=1)
db_locations = ['Court1',
 'Court2',
 'Court3',
 'Court4',
 'Elect1',
 'Elect2',
 'Fire1',
 'Fire2',
 'Fire4',
 'Fire6',
 'Fire7',
 'Fire8',
 'Fire9',
 'Fire10',
 'Fire11',
 'Fire12',
 'Fire13',
 'Fire14',
 'Fire16',
 'Fire18',
 'Fire21',
 'Fire22',
 'Fire23',
 'Fire24',
 'Fire26',
 'Fire27',
 'Fire29',
 'Fire30',
 'Fire32',
 'Fire33',
 'Fire34',
 'Fire35',
 'Fire36',
 'Fire37',
 'Fire38',
 'Fire39',
 'Library1',
 'Library2',
 'Library3',
 'Library4',
 'Library5',
 'Library6',
 'Library7',
 'Library8',
 'Library9',
 'Library10',
 'Library11',
 'Library12',
 'Library13',
 'Library14',
 'Police1',
 'Police2',
 'Police3',
 'Police4',
 'Police5',
 'Police6',
 'Police7',
 'CVS1',
 'CVS2',
 'CVS3',
 'CVS4',
 'CVS5',
 'CVS6',
 'CVS7',
 'Walgreens1',
 'Walgreens2',
 'Walgreens3',
 'Walgreens4',
 'Walgreens5',
 'Walgreens6',
 'Walgreens7',
 'Walgreens8',
 'Walgreens9',
 'Walgreens10',
 'Walgreens11',
 'Walgreens12',
 'Walgreens13',
 'Walgreens14',
 'Walgreens15',
 'Walgreens16',
 'Walgreens17',
 'Walgreens18',
 'Walgreens19',
 'Walgreens20',
 'Walgreens21',
 'Walgreens22',
 'Walgreens23',
 'Walgreens24',
 'Walgreens25',
 'Walgreens26',
 'Walgreens27',
 'Walgreens28',
 'Walgreens29']

####
# Removing 'dominated' locations
####

df_new = df_new.sort_values(by = ['FIPS_BLOCK_GROUP']+db_locations,ascending= True)

locations = df_new['Location_ID'].unique()

# Note that each BG location must have at least one, so we can compare within blockgroups
block_groups_dict = dict(zip(df_new['Location_ID'], df_new['FIPS_BLOCK_GROUP']))
vNone = dict(zip(df_new['Location_ID'], df_new['None']))
vDB = {}
for db in db_locations:
    vDB[db] = dict(zip(df_new['Location_ID'], df_new[db]))



keep_rows = []
remove_rows = {}
for i in locations:
    if i not in remove_rows:
        keep_rows.append(i)
        # Checking to see if i dominates any j
        for j in np.unique(df_new[df_new['FIPS_BLOCK_GROUP'] == block_groups_dict[i]]['Location_ID']):
            # Note that each block group location will have the same non-voter rate, so we don't need to check
            dominated = True
            for db in vDB:
                if vDB[db][i] > vDB[db][j]:
                    dominated = False
                    break
            if dominated:
                remove_rows[j] = True

df_new2 = df_new.drop(columns = ['FIPS_BLOCK_GROUP','FIPS_TRACT','Vehicle Status','Estimated Population','coverage_base','coverage','Nov 2020 Turnout Rate (Est)']) 
df_new2 = df_new2[df_new2['Location_ID'].isin(keep_rows)]
df_new2= df_new2.set_index('Location_ID')
df_new2.to_csv('C:/Users/apschmidt/Box/Research/Elections/Dropbox/Code/MCTP/Data/Milwaukee/data_participation.csv')
print("Wrote participation file")





quit()



def find_basecoverage(row):
    '''
    This takes in a row of our data frame and determines which of the 
    drop box locations will provide the base coverage
    '''
    covering_locations = []
    
    
    # Can only look at transit and walking times
    for db in db_locations:
        # Residence
        if BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['walking'] <= 30:
            covering_locations.append(db)
        # Residence
        elif BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['transit'] <= 40:
            covering_locations.append(db)
        # We can check the drive time
        elif row['Vehicle Status'] != 'NoneAvailable':
            if BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['driving'] <= 30:
                covering_locations.append(db)
        # Work location
        elif row['FIPS_TRACT'] != 'NA':
            if Tract_traveltimes[row['FIPS_TRACT']][db]['walking'] <= 15:
                covering_locations.append(db)
    if len(covering_locations) < 1:
        print(row)
        raise Exception('Issue')
    return '-'.join(covering_locations)
        
def find_coverage(row):
    '''
    This takes in a row of our data frame and determines which of the 
    drop box locations will provide the desired coverage
    '''
    covering_locations = []
    
    
    # Can only look at transit and walking times
    for db in db_locations:
        # Residence
        if BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['walking'] <= 15:
            covering_locations.append(db)
        # Residence
        elif BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['transit'] <= 20:
            covering_locations.append(db)
        # We can check the drive time
        elif row['Vehicle Status'] != 'NoneAvailable':
            if BG_traveltimes[row['FIPS_BLOCK_GROUP']][db]['driving'] <= 15:
                covering_locations.append(db)
        # Work location
        elif row['FIPS_TRACT'] != 'NA':
            if Tract_traveltimes[row['FIPS_TRACT']][db]['walking'] <= 7.5:
                covering_locations.append(db)
    return '-'.join(covering_locations)












travelModes = ['driving','walking','transit']
N = defaultdict(lambda:[]) 
Nprime = defaultdict(lambda:[])
 
for tm in travelModes:
    with open(f'../../{loc} Case Study Raw Data/Distance Tables/voter_{tm}_duration_matrix.csv', 'r', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
        count = 0
        for row in spamreader:
            if count == 0:
                count += 1
                dbs = row # Stores the dropboxes
            else:
                vl = row[0]# Voter location
                for i in range(1,len(row)):
                    if float(row[i]) < 0: # Couldn't get a distance
                        pass # Don't want to add to anything
                    else:
                        if float(row[i]) <= N_limits[tm]:
                            if dbs[i] not in N[vl]:
                                N[vl].append(dbs[i])
                        if float(row[i]) <= Nprime_limits[tm]:
                            if dbs[i] not in Nprime[vl]:
                                Nprime[vl].append(dbs[i])
                
# -----------------------------------------------
# Append to file data_N.csv
# -----------------------------------------------

data = []
# First we read in the file
with open(f'../MCTP/Data/{loc}/data_W.csv', 'r', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
    count = 0
    for row in spamreader:
        if count == 0:
            count += 1
            header = row # Stores the dropboxes
        else:
            data.append(row)
            row[3] = "-".join(N[row[0]])
            row[4] = "-".join(Nprime[row[0]])

# Now writing
with open(f'../MCTP/Data/{loc}/data_W.csv', 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    spamwriter.writerow(header)
    for d in data:
        spamwriter.writerow(d)

# -----------------------------------------------
# Writing the README file
# -----------------------------------------------


myfile = open(f'../MCTP/Data/{loc}/README.txt','w')

myfile.writelines(f'''We create the N and N' using the following logic

N: driving within {N_limits['driving']} minutes, transit within {N_limits['transit']} minutes, and walking within {N_limits['walking']} minutes
N': driving within {Nprime_limits['driving']} minutes, transit within {Nprime_limits['transit']} minutes, and walking within {Nprime_limits['walking']} minutes''')

# close the file
myfile.close()

