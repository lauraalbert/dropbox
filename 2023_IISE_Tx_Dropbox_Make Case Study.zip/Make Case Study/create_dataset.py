'''
This will create the data set for the case study

@author: apschmidt2
'''
import csv, os
import pandas as pd
from collections import defaultdict
import numpy as np