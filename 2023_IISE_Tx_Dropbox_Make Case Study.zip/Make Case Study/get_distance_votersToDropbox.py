import requests
import pandas as pd
import csv
import json
import math

# Which location are we making it for?
loc = 'Milwaukee' #'Mequon' # 

# travelMode can be either driving, walking, or transit
travelMode = 'walking'
  
# timeUnit can be minute or second
timeUnit = 'minute'
    
# HTTP POST Request URL
url = 'https://dev.virtualearth.net/REST/v1/Routes/DistanceMatrix?key=AtWNtrHV5F1mwktqPg7LB8iV1On-Qt8YLhjdqHbI_Qlm4AG-UM_7-qwz7b0n812Q'
 
# voter types
vtype = 'blockgroup'#'tract'

# people_locations
# ppl_locations = f'../../{loc} Case Study Raw Data/votingWardCenters.csv'
ppl_locations = f'../../{loc} Case Study Raw Data/Census Data/{vtype}Centers.csv'
# -----------------------------------------------
# Building the origins of voter locations
# -----------------------------------------------

# Reading in all the locations

voter_locations = {}
voter_ids = []
voters_latlong = []
with open(ppl_locations, 'r', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
    count = 0
    for row in spamreader:
        if count > 0:
            row[-2] = float(row[-2]) # lat
            row[-1] = float(row[-1]) # long
            voter_locations[(row[-2],row[-1])] = row[1] # ward
            voter_ids.append(row[1])
            voters_latlong.append((row[-2],row[-1]))
        else: 
            count = 1

# -----------------------------------------------
# Building the destinations (drop box locations)
# -----------------------------------------------
db_locations = {}
db_ids = []
db_latlong = []
with open(f'../../{loc} Case Study Raw Data/potential_db_locations.csv', 'r', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
    count = 0
    for row in spamreader:
        if count > 0:
            row[1] = float(row[1]) # lat
            row[2] = float(row[2]) # long
            db_locations[(row[1],row[2])] = row[0] # ward
            db_ids.append(row[0])
            db_latlong.append((row[1],row[2]))
        else: 
            count = 1

# -----------------------------------------------
# Requesting the distance
# -----------------------------------------------
distance_matrix = {}
duration_matrix = {}

# Need to split into quarters as to not exceed limit
if travelMode == 'driving': # Up to 50,000 pairs per call
    h1_mult = 50
    h2_mult = 50
    h1_list = range(math.ceil(len(voter_ids)/h1_mult))
    h2_list = range(math.ceil(len(db_ids)/h2_mult))
    
    
else: # Up to 675 pairs per call
    h1_mult = 15
    h2_mult = 25
    h1_list = range(math.ceil(len(voter_ids)/h1_mult))
    h2_list = range(math.ceil(len(db_ids)/h2_mult))
    
    
for h1 in h1_list: # Which 7th of the voter locations
    for h2 in h2_list: # Which half for the destinations
        
        # Creating the POST body
        bod = {
        "origins": [{'latitude': x[0], "longitude": x[1]} for x in voters_latlong[h1_mult*h1:h1_mult*(h1+1)]],
        "destinations": [{'latitude': x[0], "longitude": x[1]} for x in db_latlong[h2_mult*h2:h2_mult*(h2+1)]],
        "travelMode": travelMode,
        "timeUnit": timeUnit,
        'distanceUnit': 'mile' 
        }
        
        
        r = requests.post(url, data=json.dumps(bod))
        print(r.json())
        travels = r.json()['resourceSets'][0]['resources'][0]['results']
        origins =  r.json()['resourceSets'][0]['resources'][0]['origins']
        destinations =  r.json()['resourceSets'][0]['resources'][0]['destinations']
        
        # Adding to the distance matrix
        for diction in travels:
            o = origins[diction['originIndex']]
            d = destinations[diction['destinationIndex']]
            o_ID = voter_locations[o['latitude'],o['longitude']]
            d_ID = db_locations[d['latitude'],d['longitude']]
            distance_matrix[o_ID,d_ID] = diction['travelDistance']
            duration_matrix[o_ID,d_ID] = diction['travelDuration']
            
with open(f'voter{vtype}_{travelMode}_distance_matrix.csv', 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    spamwriter.writerow(["ID (From\To)"] + db_ids)
    for i in voter_ids:
        spamwriter.writerow([i]+[distance_matrix[i,j] for j in db_ids])

with open(f'voter{vtype}_{travelMode}_duration_matrix.csv', 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    spamwriter.writerow(["ID (From\To)"] + db_ids)
    for i in voter_ids:
        spamwriter.writerow([i]+[duration_matrix[i,j] for j in db_ids])

