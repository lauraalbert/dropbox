'''
This will create the data_W table for the case study.

@author: apschmidt2
'''
import csv, os
import pandas as pd
from collections import defaultdict
import numpy as np

# Which location are we making it for?
loc = 'Milwaukee' # 'Milwaukee' #


'''
The logic used is as follows:

Base Coverage:
A dropbox location covers an individual if at least one of the following is true
    a) The dropbox is within 15 minutes driving
    b) The dropbox is within 30 minutes transit
    c) The dropbox is within 15 minutes walking
    d) The dropbox is within 4 miles (road distance) to account for data quality
    issues and biking

Desired Coverage: 1/2 the values used within the base coverage

Each of these times are computed from the center of the block group or census
track considered.
'''
  
# These are the potential dropbox locations
db_locations = []
with open("C:/Users/apschmidt/Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/potential_db_locations.csv",'r') as csvfile:
    reader = csv.reader(csvfile, delimiter=',', quotechar='|')
    count = 0
    for row in reader:
        if count == 0:
            count += 1
        else:
            db_locations.append(row[0])

# -----------------------------------------------
# We first read in the locations and store the travel times
# -----------------------------------------------
BG_traveltimes = defaultdict(lambda: defaultdict(dict)) # Will store the travel times for each block group to each dropbox location
Tract_traveltimes = defaultdict(lambda: defaultdict(dict)) # Will store the travel times for each census tract to each dropbox location
BG_traveldistances =  defaultdict(lambda: defaultdict(dict)) # Will store the travel distance for each block group to each dropbox location
center_directory = 'C:/Users/apschmidt/Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/Census Data' 
duration_directory = 'C:/Users/apschmidt/Box/Research/Elections/Dropbox/Milwaukee Case Study Raw Data/Distance Tables'


# First, we deal with the block groups. This reads in the block groups that are
# within the city limits and within milwaukee county
with open(os.path.join(center_directory, 'milwaukee_block_group_list.txt'), 'r') as f:
    output = f.readlines()
    list_of_blockgroups = [line.rstrip() for line in output]
    
# Now, reading in the file to get the FIPS code
df = pd.read_csv(os.path.join(center_directory, 'blockgroupCenters.csv'))
# key = OBJECTID, value = FIPS code
FIPS_codes = pd.Series(df.FIPS_BLKGR.values,index=df.OBJECTID).to_dict()


# Now, we read in the distance between each drop box location
for tm in ['driving','walking','transit']:
    with open(os.path.join(duration_directory,f'voterblockgroup_{tm}_duration_matrix.csv'), 'r', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
        count = 0
        for row in spamreader:
            if count == 0:
                count += 1
                dbs = row # Stores the dropboxes (plus the 0th index)
            else:
                vl = int(row[0])# Voter location
                for i in range(1,len(row)):
                    if float(row[i]) < 0:
                        row[i] = 9999
                    BG_traveltimes[FIPS_codes[vl]][dbs[i]][tm] = float(row[i])
    
# Reading in the road distance
with open(os.path.join(duration_directory,f'voterblockgroup_driving_distance_matrix.csv'), 'r', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
        count = 0
        for row in spamreader:
            if count == 0:
                count += 1
                dbs = row # Stores the dropboxes (plus the 0th index)
            else:
                vl = int(row[0])# Voter location
                for i in range(1,len(row)):
                    if float(row[i]) < 0:
                        row[i] = 9999
                    BG_traveldistances[FIPS_codes[vl]][dbs[i]] = float(row[i])

# We now repeat for the census tracts.

# Now, reading in the file to get the FIPS code
df = pd.read_csv(os.path.join(center_directory, 'tractCenters.csv'))
# key = OBJECTID, value = FIPS code
FIPS_codes = pd.Series(df.FIPS_TRACT.values,index=df.OBJECTID).to_dict()


# Now, we read in the distance between each drop box location
for tm in ['driving','walking','transit']:
    with open(os.path.join(duration_directory,f'votertract_{tm}_duration_matrix.csv'), 'r', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
        count = 0
        for row in spamreader:
            if count == 0:
                count += 1
                dbs = row # Stores the dropboxes (plus the 0th index)
            else:
                vl = int(row[0])# Voter location
                for i in range(1,len(row)):
                    if float(row[i]) < 0:
                        row[i] = 9999
                    Tract_traveltimes[FIPS_codes[vl]][dbs[i]][tm] = float(row[i])



#########
# Coverage
########
'''
We define coverage sets for each block group locations. Each location should
be covered equally.
'''
         
def find_basecoverage(FIPS_BLOCK_GROUP,factor):
    '''
    This takes in a row of our data frame and determines which of the 
    drop box locations will provide the base coverage
    '''
    covering_locations = []
    
    
    # Can only look at transit and walking times
    for db in db_locations:
        count = 0
        # Residence
        if BG_traveltimes[FIPS_BLOCK_GROUP][db]['walking'] <= 15*factor:
            count += 1
        # Residence
        if BG_traveltimes[FIPS_BLOCK_GROUP][db]['transit'] <= 30*factor:
            count += 1
        # We can check the drive time
        if BG_traveltimes[FIPS_BLOCK_GROUP][db]['driving'] <= 15*factor:
            count += 1
        # Work location
        if BG_traveldistances[FIPS_BLOCK_GROUP][db] <= 4*factor:
            count += 1
        if count >= 2:
            covering_locations.append(db)
    if len(covering_locations) < 2:
        print(FIPS_BLOCK_GROUP)
        print(BG_traveltimes[FIPS_BLOCK_GROUP])
        print(BG_traveldistances[FIPS_BLOCK_GROUP])
        print(covering_locations)
        raise Exception('Issue')
    return '-'.join(covering_locations)
      
        
def find_coverage(FIPS_BLOCK_GROUP,factor):
    '''
    This takes in a row of our data frame and determines which of the 
    drop box locations will provide the desired coverage
    '''
    covering_locations = []
    
    # Can only look at transit and walking times
    for db in db_locations:
        # Residence
        if BG_traveltimes[FIPS_BLOCK_GROUP][db]['walking'] <= 15/2*factor:
            covering_locations.append(db)
        # Residence
        elif BG_traveltimes[FIPS_BLOCK_GROUP][db]['transit'] <= 30/2*factor:
            covering_locations.append(db)
        # We can check the drive time
        elif BG_traveltimes[FIPS_BLOCK_GROUP][db]['driving'] <= 15/2*factor:
            covering_locations.append(db)
        # Work location
        elif BG_traveldistances[FIPS_BLOCK_GROUP][db] <= 4/2*factor:
            covering_locations.append(db)
            
    return '-'.join(covering_locations)


factor = 1.4


df = pd.read_csv(os.path.join(center_directory,'consolidated_blockgroup_data.csv'))
# df = df[df['18+ Population 2020'] > 0]

map_bg_pop = pd.Series(df['18+ Population 2020'].values,index=df.FIPS_BLOCK_GROUP).to_dict()

# Now writing coverage to file
with open(f'../MCTP/Data/{loc} - Equality ({factor})/data_W.csv', 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    spamwriter.writerow(['ID','w','p','Ni','Nprime'])
    for bg in map_bg_pop:
#         if map_bg_pop[bg] > 0:
        spamwriter.writerow([bg,1,map_bg_pop[bg],find_coverage(bg,factor),find_basecoverage(bg,factor)])
    

