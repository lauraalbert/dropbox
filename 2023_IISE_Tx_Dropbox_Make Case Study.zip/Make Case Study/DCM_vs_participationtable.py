'''
This will create the data_W table for the case study.

@author: apschmidt2
'''
import csv, os
import pandas as pd
from collections import defaultdict
import numpy as np

# Which location are we making it for?
loc = 'Milwaukee' # 'Milwaukee' #

################################################################################
# Some functions to use
################################################################################

def utility(benefit,cost):
    return benefit - cost

def calculateV(utility):
    return np.exp(utility)

def cost(walk, transit, drive, vehicle, other, work)
    '''
    walk: (float) duration to walk. lower bound of 1
    transit: (float) duration to talk transit. lower bound of 1
    drive: (float) duration to drive with personal vehicle. lower bound of 1
    vehicle: (float) the percent of individuals who have a vehicle available
    other: (float) the duration of using other methods. lower bound of 1
    work: (dict) the various work locations as keys and a tuple as value with
                index 0 storing the duration (lower bound of 1) and index 1 storing the percent
                of individuals working there
    '''
    return (drive/60)**2
#     return 1/5*( (1-1/max(1,walk)) +
#                  (1-1/max(1,transit)) +
#                  (1-1/max(1,drive)) +
#                  (1-1/max(1,walk)) +
#                  (1-) )


################################################################################
################################################################################
# We start be estimating the 'benefit' from voting. To do so, we need to 
# calculate the cost to polling locations and compare this to the turnout in
# 2016 (when there were no drop boxes in use)
################################################################################
################################################################################




################################################################################
################################################################################
# We next calculate the utility provided by the drop boxes
################################################################################
################################################################################





